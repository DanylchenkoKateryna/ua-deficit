## A: major strikes (current setup)

events: {'events': 17, 'major': 17, 'derived': 0, 'censored': 0}

### vs persistence

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| baseline28 | depth | 17 | 272.6 | 184.8 | 87.84 | 16.73 | 196 | 0.2941 | 0.03513 |
| baseline28 | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 11 | 208.5 | 170.5 | 38 | 3.897 | 76.24 | 0.4545 | 0.2402 |
| event_median_A | duration | 11 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 16 | 161.7 | 196.3 | -34.62 | -113.7 | 61.36 | 0.375 | 0.5997 |
| event_median_B | duration | 16 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 17 | 232 | 184.8 | 47.17 | -62.46 | 141.9 | 0.4706 | 0.4307 |
| xgb_direct|orig | depth | 17 | 291.5 | 184.8 | 106.8 | -33.22 | 203 | 0.3529 | 0.08865 |
| xgb_direct|orig | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 17 | 232 | 184.8 | 47.17 | -62.46 | 141.9 | 0.4706 | 0.4307 |
| xgb_direct|ext | depth | 17 | 288.3 | 184.8 | 103.5 | -30.87 | 178.6 | 0.2941 | 0.08865 |
| xgb_direct|ext | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 7 | 363.5 | 238 | 125.5 | 25.31 | 125.5 | 0.2857 |  |
| xgb_direct|ev | depth | 7 | 431.1 | 238 | 193.1 | 20.47 | 193.1 | 0.4286 |  |
| xgb_direct|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |

### vs baseline28

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| persistence | depth | 17 | 184.8 | 272.6 | -87.84 | -196 | -16.73 | 0.7059 | 0.03513 |
| persistence | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 11 | 208.5 | 205.3 | 3.125 | -1.899 | 29.09 | 0.4545 | 0.8311 |
| event_median_A | duration | 11 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 16 | 161.7 | 289.3 | -127.5 | -285.4 | 21.74 | 0.5625 | 0.3484 |
| event_median_B | duration | 16 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 17 | 232 | 272.6 | -40.67 | -118.5 | -4.375 | 0.5882 | 0.3778 |
| xgb_direct|orig | depth | 17 | 291.5 | 272.6 | 18.92 | -103 | 90.91 | 0.4118 | 0.6441 |
| xgb_direct|orig | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 17 | 232 | 272.6 | -40.67 | -118.5 | -4.375 | 0.5882 | 0.3778 |
| xgb_direct|ext | depth | 17 | 288.3 | 272.6 | 15.69 | -96.23 | 57.4 | 0.3529 | 0.6777 |
| xgb_direct|ext | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 17 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 7 | 363.5 | 292.7 | 70.79 | -13.3 | 70.79 | 0.2857 |  |
| xgb_direct|ev | depth | 7 | 431.1 | 292.7 | 138.4 | -18.14 | 138.4 | 0.5714 |  |
| xgb_direct|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |

## B(gap=7): extended events

events: {'events': 70, 'major': 17, 'derived': 53, 'censored': 0}

### vs persistence

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| baseline28 | depth | 70 | 228.8 | 189.4 | 39.4 | -6.355 | 96.3 | 0.4286 | 0.06919 |
| baseline28 | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 54 | 197.9 | 209.3 | -11.41 | -66.6 | 47.6 | 0.6111 | 0.2198 |
| event_median_A | duration | 54 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 67 | 175.9 | 197.9 | -21.99 | -85.77 | 30.16 | 0.5224 | 0.271 |
| event_median_B | duration | 67 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 70 | 158.3 | 189.4 | -31.14 | -109 | 41.65 | 0.5571 | 0.09247 |
| xgb_direct|orig | depth | 70 | 206.6 | 189.4 | 17.23 | -89.76 | 110.5 | 0.5 | 0.8446 |
| xgb_direct|orig | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 70 | 158.3 | 189.4 | -31.14 | -109 | 41.65 | 0.5571 | 0.09247 |
| xgb_direct|ext | depth | 70 | 205.5 | 189.4 | 16.15 | -84.28 | 104.7 | 0.4857 | 0.8217 |
| xgb_direct|ext | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 47 | 186.1 | 233.3 | -47.18 | -138.4 | 54.94 | 0.617 | 0.03482 |
| xgb_direct|ev | depth | 47 | 249 | 233.3 | 15.68 | -91.98 | 168.7 | 0.5745 | 0.7019 |
| xgb_direct|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |

### vs baseline28

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| persistence | depth | 70 | 189.4 | 228.8 | -39.4 | -96.3 | 6.355 | 0.5714 | 0.06919 |
| persistence | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 54 | 197.9 | 224.4 | -26.51 | -68.77 | 11.46 | 0.537 | 0.1696 |
| event_median_A | duration | 54 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 67 | 175.9 | 237.5 | -61.64 | -145.3 | -8.825 | 0.597 | 0.02336 |
| event_median_B | duration | 67 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 70 | 158.3 | 228.8 | -70.53 | -134.1 | -15.9 | 0.6429 | 0.0007105 |
| xgb_direct|orig | depth | 70 | 206.6 | 228.8 | -22.17 | -117.4 | 62.92 | 0.4714 | 0.2725 |
| xgb_direct|orig | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 70 | 158.3 | 228.8 | -70.53 | -134.1 | -15.9 | 0.6429 | 0.0007105 |
| xgb_direct|ext | depth | 70 | 205.5 | 228.8 | -23.25 | -104.7 | 49.36 | 0.4714 | 0.2246 |
| xgb_direct|ext | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 70 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 47 | 186.1 | 250.6 | -64.51 | -135.6 | 22.44 | 0.6383 | 0.007694 |
| xgb_direct|ev | depth | 47 | 249 | 250.6 | -1.653 | -96.63 | 143.1 | 0.6809 | 0.5674 |
| xgb_direct|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |

## B(gap=3): extended events

events: {'events': 132, 'major': 17, 'derived': 115, 'censored': 0}

### vs persistence

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| baseline28 | depth | 132 | 229.5 | 189.8 | 39.78 | 3.736 | 79.7 | 0.4394 | 0.00315 |
| baseline28 | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 110 | 204.7 | 209.8 | -5.074 | -52.28 | 44.01 | 0.6273 | 0.1083 |
| event_median_A | duration | 110 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 127 | 186.1 | 197.2 | -11.16 | -61.72 | 32.37 | 0.5512 | 0.1455 |
| event_median_B | duration | 127 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 132 | 150.2 | 189.8 | -39.52 | -97.03 | 14.75 | 0.5758 | 0.005211 |
| xgb_direct|orig | depth | 132 | 201.7 | 189.8 | 11.97 | -67.51 | 91.38 | 0.5 | 0.9384 |
| xgb_direct|orig | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 132 | 150.2 | 189.8 | -39.52 | -97.03 | 14.75 | 0.5758 | 0.005211 |
| xgb_direct|ext | depth | 132 | 209 | 189.8 | 19.23 | -60.95 | 92.99 | 0.5152 | 0.7385 |
| xgb_direct|ext | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 97 | 190.5 | 231 | -40.47 | -108.3 | 40.15 | 0.6392 | 0.007308 |
| xgb_direct|ev | depth | 97 | 254.6 | 231 | 23.67 | -61.71 | 138.6 | 0.5464 | 0.8361 |
| xgb_direct|ev | duration | 97 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 97 | 0 | 0 | 0 | 0 | 0 | 0 |  |

### vs baseline28

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| persistence | depth | 132 | 189.8 | 229.5 | -39.78 | -79.7 | -3.736 | 0.5606 | 0.00315 |
| persistence | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 110 | 204.7 | 230.7 | -26.02 | -61.77 | 6.764 | 0.5727 | 0.01616 |
| event_median_A | duration | 110 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 127 | 186.1 | 237.2 | -51.08 | -109.7 | -8.18 | 0.5906 | 0.00276 |
| event_median_B | duration | 127 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 132 | 150.2 | 229.5 | -79.3 | -129.4 | -33.76 | 0.6515 | 7.516e-08 |
| xgb_direct|orig | depth | 132 | 201.7 | 229.5 | -27.81 | -102.3 | 42.57 | 0.5 | 0.06481 |
| xgb_direct|orig | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 132 | 150.2 | 229.5 | -79.3 | -129.4 | -33.76 | 0.6515 | 7.516e-08 |
| xgb_direct|ext | depth | 132 | 209 | 229.5 | -20.55 | -91.79 | 44.68 | 0.5076 | 0.09106 |
| xgb_direct|ext | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 132 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 97 | 190.5 | 254.7 | -64.21 | -122.7 | 1.136 | 0.6392 | 0.0002441 |
| xgb_direct|ev | depth | 97 | 254.6 | 254.7 | -0.0728 | -78.63 | 101.4 | 0.6701 | 0.3598 |
| xgb_direct|ev | duration | 97 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 97 | 0 | 0 | 0 | 0 | 0 | 0 |  |

## B(gap=14): extended events

events: {'events': 41, 'major': 17, 'derived': 24, 'censored': 0}

### vs persistence

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| baseline28 | depth | 41 | 229.3 | 189.1 | 40.2 | -4.669 | 103 | 0.4146 | 0.1522 |
| baseline28 | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 30 | 190.6 | 193.6 | -2.957 | -64.48 | 76.52 | 0.5667 | 0.612 |
| event_median_A | duration | 30 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 39 | 177.2 | 198.8 | -21.59 | -108.1 | 47.34 | 0.4615 | 0.7414 |
| event_median_B | duration | 39 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 41 | 172.1 | 189.1 | -16.93 | -100.3 | 62.87 | 0.561 | 0.4962 |
| xgb_direct|orig | depth | 41 | 231.2 | 189.1 | 42.16 | -64.98 | 143.3 | 0.4878 | 0.4257 |
| xgb_direct|orig | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 41 | 172.1 | 189.1 | -16.93 | -100.3 | 62.87 | 0.561 | 0.4962 |
| xgb_direct|ext | depth | 41 | 230.9 | 189.1 | 41.78 | -57.91 | 143.3 | 0.4634 | 0.5379 |
| xgb_direct|ext | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 26 | 185.9 | 215.3 | -29.43 | -124.7 | 116.4 | 0.6538 | 0.1731 |
| xgb_direct|ev | depth | 26 | 260.6 | 215.3 | 45.28 | -99.5 | 280.2 | 0.5 | 0.6528 |
| xgb_direct|ev | duration | 26 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 26 | 0 | 0 | 0 | 0 | 0 | 0 |  |

### vs baseline28

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| persistence | depth | 41 | 189.1 | 229.3 | -40.2 | -103 | 4.669 | 0.5854 | 0.1522 |
| persistence | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 30 | 190.6 | 208.6 | -17.95 | -58.88 | 32.57 | 0.5667 | 0.3285 |
| event_median_A | duration | 30 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 39 | 177.2 | 240.3 | -63.11 | -187.5 | 3.83 | 0.5128 | 0.2706 |
| event_median_B | duration | 39 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 41 | 172.1 | 229.3 | -57.14 | -125.1 | 2.125 | 0.6341 | 0.03147 |
| xgb_direct|orig | depth | 41 | 231.2 | 229.3 | 1.957 | -97.74 | 87.69 | 0.4634 | 0.8076 |
| xgb_direct|orig | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 41 | 172.1 | 229.3 | -57.14 | -125.1 | 2.125 | 0.6341 | 0.03147 |
| xgb_direct|ext | depth | 41 | 230.9 | 229.3 | 1.576 | -88.86 | 85.19 | 0.4146 | 0.898 |
| xgb_direct|ext | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 41 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 26 | 185.9 | 232.6 | -46.7 | -125 | 67.45 | 0.6154 | 0.1499 |
| xgb_direct|ev | depth | 26 | 260.6 | 232.6 | 28.01 | -84.89 | 230.9 | 0.5769 | 0.9801 |
| xgb_direct|ev | duration | 26 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 26 | 0 | 0 | 0 | 0 | 0 | 0 |  |

## B(gap=7) common support: events where the event-trained variant has >= 40 known strike days

events: {'events': 47, 'major': 7, 'derived': 40, 'censored': 0}

### vs persistence

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| baseline28 | depth | 47 | 250.6 | 233.3 | 17.33 | -26.87 | 64.36 | 0.5106 | 0.6183 |
| baseline28 | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 47 | 220.3 | 233.3 | -13.03 | -79.32 | 54.2 | 0.617 | 0.2401 |
| event_median_A | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 47 | 207.5 | 233.3 | -25.84 | -90.81 | 48.2 | 0.5957 | 0.1223 |
| event_median_B | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 47 | 133 | 233.3 | -100.3 | -160.6 | -25.98 | 0.7021 | 1.331e-05 |
| xgb_direct|orig | depth | 47 | 163.1 | 233.3 | -70.26 | -166.5 | 54.56 | 0.6809 | 0.02954 |
| xgb_direct|orig | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 47 | 133 | 233.3 | -100.3 | -160.6 | -25.98 | 0.7021 | 1.331e-05 |
| xgb_direct|ext | depth | 47 | 177.3 | 233.3 | -56.05 | -148.4 | 63.02 | 0.6596 | 0.06928 |
| xgb_direct|ext | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 47 | 186.1 | 233.3 | -47.18 | -138.4 | 54.94 | 0.617 | 0.03482 |
| xgb_direct|ev | depth | 47 | 249 | 233.3 | 15.68 | -91.98 | 168.7 | 0.5745 | 0.7019 |
| xgb_direct|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |

### vs baseline28

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| persistence | depth | 47 | 233.3 | 250.6 | -17.33 | -64.36 | 26.87 | 0.4894 | 0.6183 |
| persistence | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 47 | 220.3 | 250.6 | -30.36 | -74.92 | 11.56 | 0.5319 | 0.1357 |
| event_median_A | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 47 | 207.5 | 250.6 | -43.17 | -86.6 | 0.7216 | 0.5532 | 0.03675 |
| event_median_B | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 47 | 133 | 250.6 | -117.7 | -172.6 | -50.27 | 0.766 | 1.406e-06 |
| xgb_direct|orig | depth | 47 | 163.1 | 250.6 | -87.59 | -174.8 | 20.75 | 0.5957 | 0.008502 |
| xgb_direct|orig | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 47 | 133 | 250.6 | -117.7 | -172.6 | -50.27 | 0.766 | 1.406e-06 |
| xgb_direct|ext | depth | 47 | 177.3 | 250.6 | -73.38 | -154.1 | 32.58 | 0.5957 | 0.01001 |
| xgb_direct|ext | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 47 | 186.1 | 250.6 | -64.51 | -135.6 | 22.44 | 0.6383 | 0.007694 |
| xgb_direct|ev | depth | 47 | 249 | 250.6 | -1.653 | -96.63 | 143.1 | 0.6809 | 0.5674 |
| xgb_direct|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 47 | 0 | 0 | 0 | 0 | 0 | 0 |  |

## B(gap=7) common support, major strikes only

events: {'events': 7, 'major': 7, 'derived': 0, 'censored': 0}

### vs persistence

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| baseline28 | depth | 7 | 292.7 | 238 | 54.72 | 28.3 | 69.56 | 0.2857 |  |
| baseline28 | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 7 | 297.5 | 238 | 59.49 | 58.28 | 81.48 | 0.4286 |  |
| event_median_A | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 7 | 305.5 | 238 | 67.48 | 65.88 | 83.56 | 0.2857 |  |
| event_median_B | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 7 | 246.4 | 238 | 8.402 | -87.32 | 8.402 | 0.5714 |  |
| xgb_direct|orig | depth | 7 | 271.6 | 238 | 33.54 | -85.9 | 33.54 | 0.5714 |  |
| xgb_direct|orig | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 7 | 246.4 | 238 | 8.402 | -87.32 | 8.402 | 0.5714 |  |
| xgb_direct|ext | depth | 7 | 308.5 | 238 | 70.52 | -74.21 | 70.52 | 0.4286 |  |
| xgb_direct|ext | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 7 | 363.5 | 238 | 125.5 | 25.31 | 125.5 | 0.2857 |  |
| xgb_direct|ev | depth | 7 | 431.1 | 238 | 193.1 | 20.47 | 193.1 | 0.4286 |  |
| xgb_direct|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |

### vs baseline28

| method | metric | n | MAE | MAE_ref | mean_diff | ci_lo | ci_hi | share_better | p_wilcoxon |
|---|---|---|---|---|---|---|---|---|---|
| persistence | depth | 7 | 238 | 292.7 | -54.72 | -69.56 | -28.3 | 0.7143 |  |
| persistence | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_A | depth | 7 | 297.5 | 292.7 | 4.765 | 4.765 | 42.86 | 0.4286 |  |
| event_median_A | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| event_median_B | depth | 7 | 305.5 | 292.7 | 12.76 | 8.787 | 44.95 | 0.1429 |  |
| event_median_B | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|orig | depth | 7 | 246.4 | 292.7 | -46.32 | -125.9 | -46.32 | 0.5714 |  |
| xgb_direct|orig | depth | 7 | 271.6 | 292.7 | -21.19 | -123.8 | -21.19 | 0.5714 |  |
| xgb_direct|orig | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|orig | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ext | depth | 7 | 246.4 | 292.7 | -46.32 | -125.9 | -46.32 | 0.5714 |  |
| xgb_direct|ext | depth | 7 | 308.5 | 292.7 | 15.8 | -112.8 | 15.8 | 0.4286 |  |
| xgb_direct|ext | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ext | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| ridge_depth|ev | depth | 7 | 363.5 | 292.7 | 70.79 | -13.3 | 70.79 | 0.2857 |  |
| xgb_direct|ev | depth | 7 | 431.1 | 292.7 | 138.4 | -18.14 | 138.4 | 0.5714 |  |
| xgb_direct|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
| xgb_aft|ev | duration | 7 | 0 | 0 | 0 | 0 | 0 | 0 |  |
