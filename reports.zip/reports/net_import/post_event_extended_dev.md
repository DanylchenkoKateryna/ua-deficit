# Post-event depth and duration on the extended strike list: development run (train + validation only)

Command: `docker compose run --rm deficit-offline events-dev --config config/net_import_extended.yaml` (outages: `config/outages_extended.yaml`,
numbers in `reports/outages/`). Code: `src/deficit/evaluation/post_event_dev.py`. Full tables: `post_event_extended_dev_tables.md`,
`_tests.csv`, `_folds.csv`, `_events.csv` in this folder.

**The test period was not evaluated, printed or loaded.** The daily table is cut at `split.validation_end` (net_import 2023-12-31; outages 2025-06-30)
before anything is built, and an event is kept only if its whole 30-day window also lies inside the cut (so the last net-import event is
2023-12-01, not 2023-12-31). The test split of the extended list is untouched; `deficit events` refuses to run when `post_event.strike_list` is set.

## What is compared

* Events: **A** = the major strikes of `attacks.csv` (current setup, without the BOCPD alarms); **B** = A plus derived strikes of
  `attacks_extended.csv`, chronologically, a derived strike only if >= 7 days after every earlier kept event (gap 3 and 14 as sensitivity).
  Event time = strike time (derived: first attack-report post), issue day = that UTC day, as in `post_event.py`.
* Strike features of the "ext" variant: `since_attack`, `n_attack_30` over all rows; `through7/30` from major rows only (NaN when the window
  holds only derived strikes) plus indicators `derived7/30`. `n_channels` / `n_attack_posts` (whole-day counts) are never read.
* Variants of the same direct models (`ridge_depth`, `xgb_direct`, `xgb_aft`): **orig** (all days as training rows, `attacks.csv` features,
  the current model), **ext** (all days, extended-list features), **ev** (trained only on strike days of the extended list, needs >= 40 known).
  Baselines: persistence (reference), baseline28, median of past event depths / durations.
* Every event is forecast by models fitted on examples known at its issue day, so the pooled errors are an expanding-window rolling-origin
  evaluation; `_folds.csv` splits them into 5 consecutive blocks of events. Per-event paired Wilcoxon vs persistence, 95% moving-block bootstrap
  CI (blocks of 5 events, 2000 resamples) of the mean difference of absolute errors (negative = better than persistence). Events overlap in
  time, so the p-values are optimistic.
* Not tuned: all hyper-parameters are those of `post_event.py`; no choice was made on these results.

## Event counts

| scenario | A (major) | B gap 7 (major + derived) | gap 3 | gap 14 | observed durations > 0 / censored in B |
|---|---|---|---|---|---|
| net_import (window inside 2022-2023) | 17 | 70 (17 + 53) | 132 | 41 | 0 / 0 |
| outages (window inside 2023-2025-06) | 14 | 52 (14 + 38) | 86 | 31 | 22 of 52 events > 0, 7 censored |

The existing validation split has 20 events (major + alarms, windows partly in 2024); with complete windows the major-strike set is 17.

## net_import, depth (MAE in MW; persistence is the reference)

| event set | n | persistence | ridge_depth (orig = ext) | p | CI of diff | xgb_direct orig / ext | p (ext) |
|---|---|---|---|---|---|---|---|
| A: major strikes (current) | 17 | 184.8 | 232.0 | 0.43 | -62 to +142 | 291.5 / 288.3 | 0.089 |
| B gap 7 | 70 | 189.4 | 158.3 | 0.092 | -109 to +42 | 206.6 / 205.5 | 0.82 |
| B gap 3 | 132 | 189.8 | 150.2 | 0.005 | -97 to +15 | 201.7 / 209.0 | 0.74 |
| B gap 14 | 41 | 189.1 | 172.2 | 0.50 | -100 to +63 | 230.9 / 230.9 | 0.54 |
| B gap 7, events with >= 40 known strike days (2022-10 onward) | 47 | 233.3 | 133.0 | < 0.001 | -161 to -26 | 163.1 / 177.3 | 0.069 |

* Rolling-origin blocks of B (gap 7), ridge_depth vs persistence: block 1 (2022-02 to 2022-10) 299 vs 139 MW (worse), blocks 2 to 5 better
  (157 vs 165, 128 vs 134, 96 vs 260, 112 vs 248). All the gain is in the second half of 2023, where persistence is bad; in the first months of
  the war the ridge, trained on the peace years, is much worse than persistence. `xgb_direct` is better than persistence only in blocks 4 and 5.
* Like-for-like on the ORIGINAL major-strike events (set A): extended features change nothing (ridge identical, xgb_direct 291.5 -> 288.3 MW,
  not meaningful). The direct models already train on every day, so the extended list adds only two features, not training examples. The
  event-trained variant (ev) is trained on strike days only: it is available for just 7 of the 17 major events and is worse there than
  persistence (ridge 364 vs 238 MW); on B it is not better than the all-days model (186 vs 133 MW ridge on the common 47 events).
* No model beats persistence on the 17 original events (the 20-event validation split is the same story), and the median of past event
  depths is not better than persistence either (p 0.27 on B).

## net_import, duration

Not testable. In 2022-2023 the daily mean net import never stayed above the episode threshold (800 MW) in any of the 149 evaluated events (union of all gaps),
so the actual duration is 0 for every event; persistence and the models all predict 0, errors are identical, the Wilcoxon test is undefined.
Duration of the net-import deficit has no variation in train + validation; the 61 test events cannot be pre-judged from here.

## outages (index 0 to 1; depth in index units, duration in days)

| event set | n | depth: persistence | ridge | xgb_direct (ext) | duration: persistence | xgb_direct (ext) | xgb_aft (ext) |
|---|---|---|---|---|---|---|---|
| A (14, 4 censored) | 14 | 0.250 | 0.270 (p 0.36) | 0.241 (p 0.90) | 8.2 d | 8.6 (p 0.59) | 5.9 (p 0.65) |
| B gap 7 (7 censored) | 52 | 0.270 | 0.318 (p 0.022, worse) | 0.326 (p 0.12) | 6.9 d | 7.0 (p 0.87) | 7.5 (p 0.78) |
| B gap 3 | 86 | 0.251 | 0.294 (p 0.013, worse) | 0.319 (p 0.010, worse) | 7.7 d | 7.2 (p 0.84) | 7.9 (p 0.80) |

Persistence is better than every model for depth and not distinguishable for duration (all bootstrap CIs contain 0; the median of past
durations 6.7 d vs persistence 6.9 d, p 0.92). The AFT model looks better on set A (5.9 vs 8.2 d) but with 14 events and a CI of -16 to +6 d;
it is worse on the larger sets. Observed MAE favours short forecasts when long episodes are censored, so none of this is evidence of skill.

## Verdict

* **Depth (net_import):** ridge_depth on the extended events beats persistence on the pooled 70 events only weakly (-31 MW, p 0.09, CI
  includes 0). The clear advantage (-100 MW, p < 0.001, CI -161 to -26) exists only on the 47 later events (2022-10 onward, mostly 2023), and is
  absent or reversed on the original 17 major strikes and in the first months of the war. The extended list therefore does make the
  comparison less noisy (n = 17 to 70 and 132) but does not change the conclusion on the original events; it adds events, not information
  for the models. `xgb_direct` never beats persistence on validation. Training on strike days only (ev) does not help. Conclusion for the thesis:
  depth gain over persistence is plausible but time-dependent; whether it holds on the test period is a separate, untouched question.
* **Depth (outages):** nothing beats persistence; ridge and xgb_direct are significantly worse on the larger sets.
* **Duration:** no evidence of skill on either target. Net import has no variation to forecast on train + validation; outages show no model
  better than persistence or the median of past durations.
* **Caveats:** derived strikes are separated by only 3 to 14 days, so windows overlap heavily (effective sample size far below n);
  the derived list is built from Telegram attack-report posts of whole days (event existence is known at the first post, features never use the
  counts); persistence is a strong baseline when the deficit level is stable; no multiple-comparison correction across the many rows; the ridge
  gain was found by looking at subsets (events with enough known strike days), which is a post-hoc slice and should be treated as hypothesis only.
