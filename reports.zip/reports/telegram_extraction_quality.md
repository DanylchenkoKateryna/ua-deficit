# Telegram extraction quality

Generated from `data/raw/telegram/*.parquet` (42178 posts, channels: Lvivoblenergo, cherkasyoblenergo, chernihivoblenergo, dnipropetrovskaoda, dtek_odesa, dtek_ua, dtek_ua_kyiv, energoatom_ua, kharkivoda, khersonskaoda, khmelnytskaoda, khmelnytskoblenergo, kirovogradoblenergo, kyivoda, mykolaivoblenergo, odeskaoda, poltavskaoda, rivneoblenergo, sumyoblenergo, synegubov, ukrenergo, vinnytsiaoda, volynoblenergo, zoda_gov_ua, ztoe_ua). Rule-based extractor: `src/deficit/ingestion/telegram_extract.py`; every extracted value keeps its matched span in the `spans` column.

## Precision / recall against hand labels

Gold sample: 186 posts (enriched: 65, random: 49, targeted_K: 24, targeted_eta: 16, targeted_E: 14, targeted_R: 10, targeted_W: 8); channels {'ukrenergo': 53, 'dtek_ua': 44, 'Lvivoblenergo': 31, 'ztoe_ua': 29, 'sumyoblenergo': 21, 'energoatom_ua': 8}. Labels were written by reading each post, before looking at extractor output (see notes). Sets (objects, regions, hours, MW) are scored per element; numbers must match exactly (0.1 %); `gold_n` is the number of true items. **These numbers are optimistic**: the extractor was tuned on the main sample (enriched + random) after a first blind pass whose scores are listed below, and only the targeted posts were partly held out; fields with few positives (eta_h, lifted, consumers) are anecdotal.

| field | posts | tp | fp | fn | gold_n | precision | recall |
|---|---|---|---|---|---|---|---|
| attack | 114 | 26 | 0 | 2 | 28 | 1.00 | 0.93 |
| objects | 114 | 19 | 3 | 8 | 27 | 0.86 | 0.70 |
| regions | 114 | 149 | 10 | 1 | 150 | 0.94 | 0.99 |
| regions_affected | 114 | 113 | 6 | 16 | 129 | 0.95 | 0.88 |
| consumers | 170 | 8 | 1 | 2 | 10 | 0.89 | 0.80 |
| consumers_restored | 170 | 18 | 0 | 1 | 19 | 1.00 | 0.95 |
| settlements | 170 | 14 | 0 | 0 | 14 | 1.00 | 1.00 |
| schedules | 114 | 37 | 0 | 2 | 39 | 1.00 | 0.95 |
| hours | 114 | 20 | 1 | 1 | 21 | 0.95 | 0.95 |
| queues_max | 114 | 10 | 1 | 1 | 11 | 0.91 | 0.91 |
| emergency | 114 | 16 | 0 | 0 | 16 | 1.00 | 1.00 |
| lifted | 114 | 3 | 1 | 0 | 3 | 0.75 | 1.00 |
| mw | 170 | 19 | 0 | 2 | 21 | 1.00 | 0.90 |
| restored_any | 170 | 23 | 0 | 5 | 28 | 1.00 | 0.82 |
| restored_full | 170 | 8 | 1 | 1 | 9 | 0.89 | 0.89 |
| repairs | 170 | 9 | 1 | 5 | 14 | 0.90 | 0.64 |
| cons_pct | 114 | 12 | 0 | 0 | 12 | 1.00 | 1.00 |
| eta_h | 186 | 1 | 0 | 0 | 1 | 1.00 | 1.00 |

## Coverage per channel and year

Number of posts in which each field was extracted (a post can be counted in several columns).

| channel | year | posts | attack_report | schedules | emergency | lifted | consumers | restored | region | MW | cons_change | eta |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Lvivoblenergo | 2022 | 470 | 22 | 25 | 44 | 3 | 2 | 23 | 177 | 0 | 1 | 0 |
| Lvivoblenergo | 2023 | 507 | 16 | 38 | 17 | 6 | 0 | 16 | 210 | 19 | 6 | 0 |
| Lvivoblenergo | 2024 | 803 | 32 | 142 | 16 | 18 | 2 | 7 | 182 | 11 | 7 | 0 |
| Lvivoblenergo | 2025 | 204 | 5 | 21 | 21 | 0 | 0 | 6 | 50 | 0 | 4 | 0 |
| Lvivoblenergo | 2026 | 211 | 0 | 10 | 7 | 1 | 1 | 0 | 23 | 0 | 0 | 0 |
| cherkasyoblenergo | 2022 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| chernihivoblenergo | 2026 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| dnipropetrovskaoda | 2022 | 17 | 4 | 1 | 2 | 0 | 0 | 5 | 14 | 0 | 0 | 0 |
| dnipropetrovskaoda | 2023 | 3 | 0 | 0 | 0 | 0 | 0 | 1 | 2 | 0 | 0 | 0 |
| dnipropetrovskaoda | 2024 | 288 | 9 | 0 | 1 | 0 | 3 | 8 | 195 | 0 | 0 | 0 |
| dnipropetrovskaoda | 2025 | 2058 | 32 | 0 | 1 | 0 | 1 | 10 | 1428 | 0 | 0 | 0 |
| dnipropetrovskaoda | 2026 | 2355 | 22 | 4 | 0 | 0 | 6 | 18 | 1731 | 0 | 0 | 1 |
| dtek_odesa | 2025 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| dtek_ua | 2022 | 99 | 14 | 6 | 18 | 0 | 2 | 12 | 56 | 0 | 0 | 0 |
| dtek_ua | 2023 | 786 | 79 | 69 | 33 | 15 | 11 | 181 | 496 | 4 | 4 | 0 |
| dtek_ua | 2024 | 765 | 81 | 231 | 41 | 30 | 12 | 100 | 423 | 2 | 1 | 1 |
| dtek_ua | 2025 | 780 | 88 | 324 | 62 | 22 | 16 | 98 | 597 | 0 | 0 | 0 |
| dtek_ua | 2026 | 696 | 103 | 199 | 116 | 15 | 39 | 105 | 500 | 0 | 0 | 2 |
| dtek_ua_kyiv | 2024 | 10 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| energoatom_ua | 2022 | 8311 | 151 | 6 | 11 | 11 | 77 | 136 | 2802 | 38 | 21 | 0 |
| energoatom_ua | 2023 | 3887 | 49 | 1 | 3 | 2 | 3 | 59 | 1234 | 11 | 0 | 0 |
| energoatom_ua | 2024 | 3120 | 20 | 0 | 1 | 2 | 0 | 65 | 848 | 7 | 4 | 0 |
| energoatom_ua | 2025 | 2780 | 20 | 3 | 0 | 0 | 0 | 58 | 743 | 4 | 1 | 0 |
| energoatom_ua | 2026 | 2021 | 8 | 1 | 1 | 1 | 2 | 42 | 471 | 2 | 0 | 0 |
| kharkivoda | 2022 | 24 | 5 | 1 | 1 | 1 | 2 | 17 | 21 | 0 | 0 | 0 |
| kharkivoda | 2023 | 23 | 2 | 1 | 0 | 0 | 2 | 17 | 14 | 0 | 0 | 0 |
| kharkivoda | 2024 | 13 | 3 | 1 | 0 | 0 | 3 | 3 | 12 | 0 | 0 | 0 |
| kharkivoda | 2025 | 35 | 10 | 2 | 2 | 0 | 4 | 8 | 31 | 0 | 0 | 0 |
| kharkivoda | 2026 | 66 | 11 | 7 | 7 | 0 | 5 | 3 | 54 | 0 | 0 | 1 |
| khersonskaoda | 2022 | 7 | 0 | 0 | 0 | 0 | 0 | 7 | 6 | 0 | 0 | 0 |
| khersonskaoda | 2023 | 20 | 1 | 0 | 0 | 0 | 2 | 17 | 18 | 0 | 0 | 0 |
| khersonskaoda | 2024 | 16 | 0 | 2 | 0 | 0 | 4 | 2 | 11 | 0 | 0 | 0 |
| khersonskaoda | 2025 | 23 | 1 | 0 | 0 | 0 | 0 | 2 | 17 | 0 | 0 | 0 |
| khersonskaoda | 2026 | 67 | 3 | 0 | 0 | 0 | 2 | 2 | 40 | 0 | 0 | 0 |
| khmelnytskaoda | 2022 | 22 | 4 | 3 | 3 | 0 | 3 | 10 | 15 | 0 | 0 | 0 |
| khmelnytskaoda | 2023 | 25 | 2 | 1 | 1 | 0 | 2 | 3 | 18 | 0 | 0 | 0 |
| khmelnytskaoda | 2024 | 31 | 3 | 2 | 2 | 1 | 1 | 6 | 12 | 0 | 0 | 0 |
| khmelnytskaoda | 2025 | 13 | 1 | 0 | 0 | 0 | 1 | 0 | 6 | 0 | 0 | 0 |
| khmelnytskaoda | 2026 | 31 | 4 | 2 | 3 | 0 | 1 | 2 | 19 | 0 | 0 | 0 |
| khmelnytskoblenergo | 2023 | 220 | 6 | 14 | 14 | 20 | 0 | 8 | 109 | 0 | 1 | 0 |
| khmelnytskoblenergo | 2024 | 402 | 9 | 111 | 18 | 45 | 1 | 6 | 135 | 0 | 0 | 0 |
| khmelnytskoblenergo | 2025 | 273 | 6 | 77 | 15 | 4 | 0 | 5 | 137 | 0 | 0 | 0 |
| khmelnytskoblenergo | 2026 | 536 | 9 | 133 | 38 | 3 | 2 | 20 | 265 | 1 | 0 | 0 |
| kirovogradoblenergo | 2026 | 6 | 0 | 3 | 3 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| kyivoda | 2023 | 2 | 0 | 0 | 1 | 0 | 0 | 2 | 2 | 0 | 0 | 0 |
| kyivoda | 2024 | 9 | 1 | 0 | 0 | 0 | 1 | 9 | 8 | 0 | 0 | 0 |
| kyivoda | 2025 | 21 | 12 | 2 | 5 | 0 | 10 | 10 | 16 | 0 | 0 | 0 |
| kyivoda | 2026 | 576 | 41 | 33 | 44 | 1 | 8 | 20 | 112 | 0 | 0 | 0 |
| mykolaivoblenergo | 2025 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| mykolaivoblenergo | 2026 | 6 | 1 | 2 | 1 | 0 | 0 | 0 | 2 | 0 | 0 | 0 |
| odeskaoda | 2022 | 2 | 0 | 0 | 0 | 0 | 0 | 1 | 2 | 0 | 0 | 0 |
| odeskaoda | 2023 | 10 | 0 | 0 | 0 | 0 | 0 | 4 | 10 | 0 | 0 | 0 |
| odeskaoda | 2024 | 12 | 4 | 2 | 0 | 2 | 3 | 1 | 11 | 0 | 0 | 0 |
| odeskaoda | 2025 | 26 | 2 | 1 | 1 | 0 | 1 | 16 | 19 | 0 | 0 | 0 |
| odeskaoda | 2026 | 64 | 14 | 2 | 5 | 0 | 8 | 7 | 52 | 0 | 0 | 0 |
| poltavskaoda | 2023 | 2 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| poltavskaoda | 2024 | 5 | 0 | 0 | 0 | 1 | 2 | 0 | 3 | 0 | 0 | 0 |
| poltavskaoda | 2025 | 15 | 4 | 6 | 7 | 0 | 5 | 4 | 10 | 0 | 0 | 0 |
| poltavskaoda | 2026 | 123 | 31 | 24 | 29 | 0 | 6 | 18 | 70 | 0 | 0 | 0 |
| rivneoblenergo | 2022 | 3 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| sumyoblenergo | 2022 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| sumyoblenergo | 2023 | 273 | 24 | 38 | 13 | 33 | 11 | 1 | 137 | 1 | 0 | 0 |
| sumyoblenergo | 2024 | 1299 | 62 | 325 | 131 | 15 | 20 | 10 | 286 | 2 | 0 | 0 |
| sumyoblenergo | 2025 | 1085 | 36 | 346 | 157 | 2 | 4 | 8 | 286 | 0 | 0 | 0 |
| sumyoblenergo | 2026 | 910 | 27 | 441 | 133 | 3 | 2 | 7 | 196 | 0 | 1 | 0 |
| synegubov | 2022 | 5 | 0 | 0 | 0 | 0 | 0 | 2 | 4 | 0 | 0 | 0 |
| synegubov | 2023 | 13 | 4 | 0 | 0 | 0 | 1 | 9 | 11 | 0 | 0 | 0 |
| synegubov | 2024 | 19 | 3 | 1 | 0 | 0 | 11 | 5 | 19 | 0 | 0 | 0 |
| synegubov | 2025 | 37 | 13 | 2 | 3 | 0 | 9 | 7 | 34 | 0 | 0 | 0 |
| synegubov | 2026 | 68 | 12 | 7 | 7 | 0 | 3 | 5 | 57 | 0 | 0 | 1 |
| ukrenergo | 2022 | 802 | 70 | 83 | 53 | 31 | 2 | 123 | 230 | 36 | 45 | 0 |
| ukrenergo | 2023 | 625 | 241 | 56 | 40 | 55 | 17 | 104 | 317 | 146 | 114 | 1 |
| ukrenergo | 2024 | 920 | 235 | 302 | 43 | 88 | 48 | 96 | 344 | 251 | 190 | 1 |
| ukrenergo | 2025 | 627 | 129 | 187 | 71 | 3 | 2 | 13 | 132 | 7 | 267 | 0 |
| ukrenergo | 2026 | 738 | 238 | 193 | 55 | 6 | 0 | 8 | 257 | 6 | 208 | 0 |
| vinnytsiaoda | 2022 | 7 | 3 | 2 | 1 | 0 | 0 | 4 | 4 | 0 | 0 | 0 |
| vinnytsiaoda | 2023 | 3 | 1 | 0 | 0 | 0 | 0 | 2 | 2 | 0 | 0 | 0 |
| vinnytsiaoda | 2024 | 14 | 0 | 2 | 0 | 0 | 0 | 1 | 5 | 2 | 0 | 0 |
| vinnytsiaoda | 2025 | 29 | 12 | 11 | 2 | 0 | 1 | 1 | 18 | 0 | 8 | 0 |
| vinnytsiaoda | 2026 | 73 | 9 | 4 | 4 | 1 | 1 | 4 | 56 | 0 | 0 | 0 |
| volynoblenergo | 2022 | 28 | 0 | 20 | 1 | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| volynoblenergo | 2023 | 68 | 0 | 52 | 0 | 3 | 0 | 0 | 30 | 0 | 0 | 0 |
| zoda_gov_ua | 2024 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| zoda_gov_ua | 2025 | 34 | 12 | 1 | 0 | 0 | 10 | 14 | 19 | 0 | 0 | 0 |
| zoda_gov_ua | 2026 | 116 | 28 | 3 | 0 | 7 | 21 | 37 | 84 | 0 | 0 | 0 |
| ztoe_ua | 2023 | 156 | 10 | 6 | 10 | 3 | 2 | 5 | 68 | 0 | 0 | 0 |
| ztoe_ua | 2024 | 449 | 21 | 178 | 23 | 86 | 0 | 4 | 204 | 1 | 1 | 0 |
| ztoe_ua | 2025 | 320 | 22 | 138 | 34 | 43 | 5 | 8 | 216 | 1 | 4 | 0 |
| ztoe_ua | 2026 | 553 | 36 | 220 | 56 | 14 | 4 | 6 | 235 | 0 | 3 | 1 |

## Strike impact episodes

Strikes in attacks.csv: 77 (77 flagged major). A restriction regime (schedules or emergency outages) was announced in the posts after 72. An **observed restoration duration** (first post after the first restriction post saying restrictions are not applied / cancelled; if no restrictions were announced, first "all consumers have power" post after the first outage post) exists for **34 of 77 strikes** ({'restrictions_lifted': 29, 'power_restored': 5}); 18 of them ended before the next strike in the list, the others overlap a chain of strikes and share one lifting post. `sustained_3d` counts lifting posts not followed by new restrictions within 3 days (the stricter definition). Windows: strike day 00:00 UTC to +30 days (right-censored afterwards). Columns of `telegram_episodes.parquet` are listed in the module docstring; every `*_at` column is the publication time of the post that determined the value.

| year | strikes | restrictions | lifted_observed | sustained_3d | duration_observed | resolved_before_next_strike | median_days |
|---|---|---|---|---|---|---|---|
| 2022 | 12 | 11 | 7 | 0 | 8 | 3 | 7.2 |
| 2023 | 5 | 5 | 5 | 3 | 5 | 4 | 5.1 |
| 2024 | 13 | 13 | 8 | 3 | 8 | 6 | 6.5 |
| 2025 | 24 | 20 | 3 | 2 | 7 | 4 | 4.1 |
| 2026 | 23 | 23 | 6 | 0 | 6 | 1 | 16.7 |
| all | 77 | 72 | 29 | 8 | 34 | 18 | 6.5 |

## Oblast-level dataset (`telegram_region_episodes.parquet`)

1925 (strike, oblast) rows = 77 strikes x 25 oblasts. Impact (consumers cut off, emergency outages or schedules in a post of that oblast) is reported for **632** of them; an **observed restoration duration** exists for **215** (144 from posts about the oblast, 71 from the national lifting post), 417 are right-censored. Rows with `coverage = text_only` have no channel of their own (impact only from mentions in other channels; 'no impact' is weak evidence there).

| oblast | strikes_with_own_channel | impact | observed | censored | median_hours |
|---|---|---|---|---|---|
| Cherkasy | 3 | 16.0 | 3.0 | 13.0 | 155.9 |
| Chernihiv | 6 | 16.0 | 2.0 | 14.0 | 126.8 |
| Chernivtsi | 0 | 4.0 | 2.0 | 2.0 | 126.8 |
| Dnipropetrovsk | 75 | 54.0 | 20.0 | 34.0 | 67.0 |
| Donetsk | 0 | 21.0 | 10.0 | 11.0 | 31.3 |
| Ivano-Frankivsk | 0 | 2.0 | 2.0 | 0.0 | 193.9 |
| Kharkiv | 74 | 46.0 | 13.0 | 33.0 | 97.8 |
| Kherson | 67 | 10.0 | 2.0 | 8.0 | 126.8 |
| Khmelnytskyi | 75 | 48.0 | 20.0 | 28.0 | 79.3 |
| Kirovohrad | 5 | 18.0 | 5.0 | 13.0 | 97.8 |
| Kyiv | 52 | 51.0 | 17.0 | 34.0 | 82.0 |
| Kyiv_city | 1 | 48.0 | 18.0 | 30.0 | 78.1 |
| Luhansk | 0 | 0.0 | 0.0 | 0.0 |  |
| Lviv | 77 | 37.0 | 12.0 | 25.0 | 139.4 |
| Mykolaiv | 5 | 5.0 | 2.0 | 3.0 | 126.8 |
| Odesa | 65 | 47.0 | 14.0 | 33.0 | 75.0 |
| Poltava | 52 | 25.0 | 7.0 | 18.0 | 52.5 |
| Rivne | 0 | 3.0 | 3.0 | 0.0 | 195.0 |
| Sumy | 71 | 59.0 | 19.0 | 40.0 | 50.5 |
| Ternopil | 0 | 3.0 | 1.0 | 2.0 | 266.5 |
| Vinnytsia | 72 | 12.0 | 1.0 | 11.0 | 273.2 |
| Volyn | 8 | 9.0 | 5.0 | 4.0 | 53.5 |
| Zakarpattia | 0 | 2.0 | 1.0 | 1.0 | 266.5 |
| Zaporizhzhia | 49 | 38.0 | 13.0 | 25.0 | 74.9 |
| Zhytomyr | 63 | 58.0 | 23.0 | 35.0 | 52.5 |

### Precision / recall on hand-labelled regional posts

112 posts ({'national_text_facts': 24, 'own_with_facts': 22, 'own_no_facts': 16, 'national_region_no_fact': 14, 'keyword_no_fact': 12, 'ext_lifted': 8, 'ext_restored_full': 8, 'ext_consumers': 8}; channels {'dtek_ua': 32, 'ukrenergo': 22, 'sumyoblenergo': 22, 'khmelnytskoblenergo': 10, 'dnipropetrovskaoda': 9, 'Lvivoblenergo': 8, 'ztoe_ua': 8, 'volynoblenergo': 1}), labelled by reading the text before looking at extractor output (`tests/fixtures/telegram_region_gold.csv`). Items are (oblast) sets per post; `consumers` items are `oblast:value` and must match exactly. The strata are enriched (see the notes below), so these are not population precision / recall; fields with few positives are anecdotal.

| field | tp | fp | fn | gold_n | precision | recall |
|---|---|---|---|---|---|---|
| attack | 48 | 21 | 8 | 56 | 0.70 | 0.86 |
| consumers | 8 | 1 | 5 | 13 | 0.89 | 0.62 |
| schedules | 40 | 2 | 20 | 60 | 0.95 | 0.67 |
| emergency | 17 | 3 | 1 | 18 | 0.85 | 0.94 |
| lifted | 8 | 0 | 0 | 8 | 1.00 | 1.00 |
| restored_full | 6 | 7 | 4 | 10 | 0.46 | 0.60 |
| restored_any | 25 | 5 | 13 | 38 | 0.83 | 0.66 |

## Oblast-level gold sample: how it was made and what it can tell

* **112 posts** in `telegram_region_gold.csv`, drawn with seed 7 / 11 from the regional channels (oblenergos, regional administrations)
  and the national channels `ukrenergo`, `dtek_ua`:
  `own_with_facts` 22 (own-channel posts where the extractor found something), `own_no_facts` 16 (own-channel posts without any fact, text
  of at least 40 characters), `national_text_facts` 24 and `national_region_no_fact` 14 (national posts that name an oblast, with and
  without an extracted oblast fact), and a second batch drawn after reading the first one to get positives of the rare fields:
  `ext_lifted` 8, `ext_restored_full` 8, `ext_consumers` 8 (posts where the extractor found that field) and `keyword_no_fact` 12 (posts with
  outage / restoration words and no extracted lifting, consumers or restoration, to look for misses).
* Every post was read (up to 2 600 characters, the long digests to their end where it mattered) and labelled **before** the extractor
  output for it was looked at. Labels per oblast: `attack` = the post reports damage or outages caused by a strike or shelling in that oblast
  (new or ongoing; retrospectives, statistics and "consequences of earlier attacks" as the reason of a nationwide regime are 0);
  `consumers` = `Oblast:count` of the largest stated non-weather count of consumers / families / houses cut off in that oblast;
  `schedules` = outage schedules of any kind (including emergency GAV / SGAV, industrial GOP) announced or in force for that oblast;
  `emergency` = emergency outages (GAV, SGAV, "екстрені / аварійні відключення") in force; `lifted` = restrictions are not applied or were
  cancelled for that oblast; `restored_full` = power is back for all consumers of that oblast / outage; `restored_any` = any statement that
  power was returned (partial included; weather outages included). Statements for the whole country carry no oblast and are 0.
* Scores are item-level over (oblast) sets: a post counts for an oblast only when label and extractor agree on that oblast.
* **Blind first pass** (the rules of `telegram_regional.py` as first written, before the gold errors were looked at; 112 posts):

  | field | tp | fp | fn | precision | recall |
  |---|---|---|---|---|---|
  | attack | 48 | 22 | 8 | 0.69 | 0.86 |
  | consumers | 8 | 2 | 5 | 0.80 | 0.62 |
  | schedules | 41 | 2 | 19 | 0.95 | 0.68 |
  | emergency | 17 | 3 | 1 | 0.85 | 0.94 |
  | lifted | 8 | 0 | 0 | 1.00 | 1.00 |
  | restored_full | 6 | 9 | 4 | 0.40 | 0.60 |
  | restored_any | 25 | 8 | 13 | 0.76 | 0.66 |

  The errors showed one structural problem: regional channels (Lvivoblenergo, Sumyoblenergo) repost Ukrenergo digests, and the own-channel
  rule attributed their facts (a full restoration for Kyiv, 380 000 consumers in Kyiv) to the channel's oblast. After that was fixed (a post that
  names another oblast is read sentence by sentence like a national post) the numbers in the current report are slightly better
  (consumers fp 2 -> 1, restored_full fp 9 -> 7, restored_any fp 8 -> 5); nothing else was changed after seeing the gold errors, so the
  remaining errors are listed as found.
* **Main remaining errors**: (1) schedules / consumers phrased without a number or without the oblast next to the cue ("Київ: графіки відключень на ...",
  "понад 335 тисяч киян", "178,7 тисячі сімей" parsed as 178 000); (2) generic nationwide digest sentences that name oblasts but are not new damage
  (attack false positives in `ukrenergo` digests); (3) restoration of a power line (nuclear plant feed) or a water pipeline read as power restored to
  consumers (`restored_full` false positives); (4) day-by-day oblenergo posts ("Командою Укренерго внесено зміни в обсяг ГПВ") that imply schedules
  without saying so.
* **Limits**: 112 posts, one labeller, borderline cases decided by the text alone; the strata are enriched, so the per-field numbers are
  not population precision / recall. On the two nearly unselected strata (`own_no_facts`, `national_region_no_fact`, 30 posts) the extractor found
  nothing and the labels hold 3 attack, 5 schedules and 3 restoration items, i.e. recall on ordinary traffic is low (about 0.0 on 11 items) while
  there were no false positives; the extractor is conservative (precision first).

## How the gold labels were made

* **Sample (114 posts, "main")**: stratified by channel (ukrenergo 36, dtek_ua 30, Lvivoblenergo 20, ztoe_ua 16, sumyoblenergo 12). In every
  channel about 40 % are *random* posts (year-stratified, 49 in total, to measure false positives on ordinary traffic) and about 60 %
  *enriched* posts drawn from four keyword families (attack and outage words, schedule words, numbers or MW, restoration words; 65 in total) so
  that rare fields have positives. Seed 20261018, posts of at least 25 characters, long digests printed up to 4 200 characters.
* **Targeted supplement (72 posts)**, drawn after the main sample had been used to fix the extractor, so it is a partly held-out check of the
  fields that are rare in the main sample: 24 posts with "number + consumers" patterns (`targeted_K`), 14 with duration phrases (`targeted_E`),
  16 more with duration phrases next to restoration words (`targeted_eta`), 8 with MW values (`targeted_W`), 10 with restoration verbs
  (`targeted_R`). Posts of at most 3 000 characters, so long digests are under-represented there. Only the fields listed in the `scored` column
  are scored for these rows (consumers, consumers_restored, settlements, eta_h, mw, restored_*, repairs; `targeted_eta` only eta_h).
* Every post was read in full and labelled **before** looking at extractor output (the extractor was run only afterwards). Labels follow the
  definitions in the module docstring: `attack` = a new strike or shelling damage on energy objects is reported (references such as "restrictions
  because of earlier strikes", retrospectives, interviews, deaths of workers, weekly/monthly restoration totals are 0); regions = oblasts and cities
  mentioned (company names are not regions); `regions_affected` = regions named next to damage, outage, restriction or attack; consumers = non-weather
  count of consumers cut off; MW classes deficit/import/export/limit/capacity_lost with the largest stated value per class; `eta_h` = a stated
  *estimate* of restoration time (past durations and schedule lengths do not count).
* **Honest limits.** (1) The extractor was tuned on the main sample after a first blind pass (first-pass numbers below), so the main-sample
  numbers in the table are optimistic; only the supplement was partly held out, and its failures (e.g. 9 false ETAs, MW lists without cue word,
  weather look-back, "м. Житомир" splitting a sentence) also led to fixes. (2) 114 + 72 posts and few positives for some fields (eta_h: 1 positive in
  186 posts, consumers: 10, lifted: 3), so those precision/recall values are anecdotal. (3) One person labelled; borderline cases were decided by
  the text alone (see "label consistency" below). (4) Recall for consumers/ETA/MW is conditional on posts that contain a number or phrase of that
  kind (recall for facts phrased without digits, e.g. "сотні тисяч точок обліку", is not measured).

### First blind pass on the main sample (before any tuning; 114 posts)

| field | tp | fp | fn | precision | recall |
|---|---|---|---|---|---|
| attack | 12 | 2 | 18 | 0.86 | 0.40 |
| objects | 6 | 2 | 23 | 0.75 | 0.21 |
| regions | 145 | 10 | 5 | 0.94 | 0.97 |
| regions_affected | 95 | 6 | 34 | 0.94 | 0.74 |
| consumers | 1 | 4 | 0 | 0.20 | 1.00 |
| consumers_restored | 6 | 0 | 4 | 1.00 | 0.60 |
| settlements | 5 | 2 | 0 | 0.71 | 1.00 |
| schedules | 33 | 1 | 6 | 0.97 | 0.85 |
| hours | 19 | 0 | 2 | 1.00 | 0.90 |
| queues_max | 6 | 1 | 5 | 0.86 | 0.55 |
| emergency | 16 | 4 | 0 | 0.80 | 1.00 |
| lifted | 3 | 2 | 0 | 0.60 | 1.00 |
| mw | 7 | 3 | 1 | 0.70 | 0.88 |
| restored_any | 11 | 3 | 4 | 0.79 | 0.73 |
| restored_full | 1 | 0 | 4 | 1.00 | 0.20 |
| repairs | 3 | 0 | 6 | 1.00 | 0.33 |
| cons_pct | 6 | 3 | 6 | 0.67 | 0.50 |
| micro average | | | | 0.90 | 0.76 |

The first pass missed most strike reports because it demanded damage word, energy object and a time marker in the same sentence
(digest sentences are split: "Ворог влучив по об'єкту..." / "Є руйнування"). That was relaxed to a three-sentence window, plus event verbs
("атакував", "завдав удару"), "через бойові дії є нові пошкодження" and causal present-tense statements.

### Label consistency decisions made while scoring

Two gold labels were changed after the first scoring because they contradicted other labels of the same kind: a DTEK "last week 27 thousand families
lost power because of attacks ... restored" summary (dtek_ua 757) and a Sumyoblenergo "reason: damage caused by the attack" line under a ГАВ notice
(sumyoblenergo 2823) are now `attack = 0` (weekly totals and "reasons for restrictions" are references, like the analogous posts labelled 0).

## Known failure cases and design limits

* **What is *not* a strike report is partly a judgement call.** Posts that explain current restrictions by earlier damage are marked `attack_ref`,
  not `is_attack_report`. A report with no time marker, no event verb and no "через ... обстріли ... є" pattern is missed (e.g. an interview
  mentioning "ТЕС ... яка була атакована 13 лютого", ukrenergo 2654; a one-line "Енергетична інфраструктура Житомирщини зазнала ворожої атаки",
  ztoe_ua 1818). Conversely a ZNPP/NPP name next to "attack" is sometimes read as a regional strike.
* **Object types are the weakest field (recall 0.70).** Types are taken only from attack sentences; digests that say "енергооб'єкти" or
  "обладнання" give `unspecified`; a list "генерації, системі передачі, системі розподілу" gives generation + distribution but not transmission;
  "мережі обленерго" is distribution only under the digest header "МЕРЕЖІ ОБЛЕНЕРГО" or with the word обленерго.
* **Regions.** Matching is by stems and listed cities, so "львівські енергетики" (workers of Lviv) and NPP names ("Запорізька АЕС") count as mentions;
  the digests of 2025-26 often say "у кількох областях" without names, so the count of regions per strike is a lower bound. `regions_affected` is
  sentence-based plus list continuations ("Зокрема ..."), and ignores weather-only sentences. Kyiv oblast needs "Київщина" or "Київська/Київській
  області" (bare "Київська" is accepted only when not followed by ТЕЦ/район/...).
* **Consumers.** Counts need "number + noun" (споживачів, абонентів, родин, осель, домівок, будинків, мешканців, клієнтів, точок обліку is *not*
  covered when a noun sits between, e.g. "11, 5 тисяч" with a stray space is read as 5 000). Ukrenergo posts of 2025-26 almost never give consumer
  counts (2 posts in 2025, 0 in 2026), DTEK and the oblenergos do. Counts mix causes when a post gives a total including weather. Word numbers
  ("сотні тисяч", "дві тисячі") are not parsed.
* **Schedules.** FAQ and explanation posts that say schedules "діють" are not announcements, but some are still counted (e.g. a Lvivoblenergo
  explainer about queue groups); the reverse also occurs (a post saying "чинні і діють" about yesterday's schedules is treated as past).
  The hours of a schedule are the time ranges in lines that mention restrictions; advice such as "користуйтесь приладами з 10:00 до 16:00" is
  skipped. A partially cancelled queue ("скасовано одну чергу ГПВ") counts as an announcement, not as lifting.
* **Lifting statements** are system-level: "заходи обмеження не застосовуються" does not mean every region is restored. A post that lifts household
  restrictions but keeps industrial ones (ГОП) is *not* a lifting statement. Posts under emergency outages ("графіки не діють") are not lifting.
* **MW.** Only МВт/ГВт/мегават (not МВт·год). The class is the nearest cue before the number in the sentence, else after it, else (only for
  import / export / limit) earlier in the paragraph. Capacity additions and unavailable capacity ("понад 10 ГВт під окупацією") get no class.
  Import is the largest stated value (hourly maximum or the technical limit of 1 700 MW), so it is a ceiling, not the flow.
* **Restoration.** "full" requires an all-quantifier or a statement without any count; counts and "most/part" are "partial". Restoration stated only
  as "ліквідовано аварію" with a typo ("Знесттрумлених") or as "кількість знеструмлених знизилася до 2284" is missed. Statements about generation
  units returning from *planned* repair are excluded from `restoration_repairs`.
* **ETA** (`eta_hours`) is rare (6 posts in 16 000) and needs both a restoration word and an estimate cue (очікується, орієнтовно, прогнозується,
  "буде відновлено"); "протягом декількох годин" has no number and gives nothing. Treat it as an auxiliary field, not as a target.
* **Language and typos.** Ukrainian only; Russian-language or English posts (Ukrenergo's early bilingual posts) are only matched through shared
  abbreviations and numbers.

## What the episode table can and cannot say

* The strike time in `attacks.csv` is a day-level placeholder (06:00), so the episode window starts at 00:00 UTC of the strike day; a restriction
  announced earlier that day by a regime that pre-dates the strike is counted as its onset (`pre_strike_schedule_posts` shows how many restriction
  posts were published in the 3 days before). Chains of strikes within days overlap: several episodes then share the same lifting post
  (`resolved_before_next_strike` marks the stand-alone ones; `lifted_sustained_at` requires 3 quiet days afterwards, which most chain episodes never reach).
* The first "restrictions not applied" post is often a weekend break inside a long regime, hence the sustained variant and the relapse flag.
* The consumer-level track (`restored_at`: first "all consumers have power" post after the first outage post) is region-agnostic: in the pooled
  scope it can be triggered by a different region's restoration. Use per-channel scopes (DTEK, oblenergos) for regional questions.
* Durations are right-censored at 30 days; `status = censored` means "no lifting statement within the window", not "lasted 30 days".
