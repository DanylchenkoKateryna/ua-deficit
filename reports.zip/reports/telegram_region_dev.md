# Oblast restoration forecast: DEV report (rolling-origin CV on train+validation, test period blind)

CV design: expanding window over the validation-period strikes (up to `telegram.region_validation_end`), K = 5 consecutive blocks of scored strikes; every strike is forecast from the earlier strikes only, with their labels as known at its issue time. MAE on observed episodes: mean over folds, SE over folds. LB = censoring-aware lower-bound MAE over all episodes; C = Harrell's C within strikes (0.5 = no ranking skill). Paired p: Wilcoxon on per-strike mean |error| differences vs the baseline. Selection: one-standard-error rule, complexity order baselines < strike < strike_oblast < *_hist < other sets (ridge < aft, larger alpha simpler). No test-period number is computed or shown.

## Window `next_strike`

Dev episodes 149 (79 observed); strikes scored 16 of 29 (2023-02-10 .. 2024-12-25).

Folds: #0: 4 strikes / 15 episodes / 11 observed; #1: 3 strikes / 12 episodes / 11 observed; #2: 3 strikes / 15 episodes / 8 observed; #3: 3 strikes / 18 episodes / 16 observed; #4: 3 strikes / 25 episodes / 15 observed

Best CV MAE: `ridge_strike_a10` 59.6 h (SE 10.1); 1-SE threshold 69.7 h; 27 designs within it. **Selected (simplest within 1 SE): `global_median`** (63.3 h).

Ensemble members: `ens_fixed` = geo_mean + ridge_strike_oblast_hist_a100 + ipcw_strike_oblast_hist_a100; `ens_best` = geo_mean + ridge_strike_a10 + ipcw_strike_a10

Top 10 by CV MAE, plus baselines and references:

| design | MAE_cv h | SE | LB_cv h | C_within | C_all | diff vs global_median h | better strikes | p per strike |
|---|---|---|---|---|---|---|---|---|
| ridge_strike_a10 | 59.6 | 10.1 | 90.7 | 0.500 | 0.532 | -0.4 | 0.50 | 0.855 |
| ridge_strike_oblast_a10 | 60.6 | 9.5 | 92.0 | 0.446 | 0.525 | 0.8 | 0.36 | 0.670 |
| ens_best | 61.0 | 10.7 | 91.8 | 0.500 | 0.532 | 0.2 | 0.43 | 0.761 |
| ridge_strike_a100 | 62.6 | 12.7 | 94.5 | 0.480 | 0.511 | 0.4 | 0.57 | 0.952 |
| ridge_strike_oblast_a100 | 62.8 | 12.6 | 94.6 | 0.395 | 0.514 | 0.5 | 0.57 | 1.000 |
| ridge_strike_oblast_hist_a100 | 62.9 | 12.6 | 94.1 | 0.448 | 0.558 | 0.4 | 0.57 | 0.952 |
| ipcw_strike_a10 | 63.1 | 10.3 | 89.8 | 0.500 | 0.545 | 1.9 | 0.43 | 0.583 |
| global_median | 63.3 | 15.2 | 96.2 | 0.500 | 0.425 |  |  |  |
| ipcw_strike_oblast_a10 | 63.8 | 9.5 | 91.4 | 0.407 | 0.537 | 2.9 | 0.43 | 0.502 |
| ens_fixed | 64.0 | 12.6 | 93.8 | 0.437 | 0.557 | 0.8 | 0.50 | 1.000 |
| geo_mean | 66.3 | 14.2 | 96.4 | 0.500 | 0.398 | 2.7 | 0.50 | 0.583 |
| oblast_median | 75.3 | 13.0 | 104.5 | 0.412 | 0.405 | 12.2 | 0.21 | 0.019 |
| km_global | 188.5 | 26.5 | 165.5 | 0.500 | 0.306 | 100.3 | 0.21 | 0.028 |
| const_30d | 607.1 | 15.7 | 447.8 | 0.500 | 0.500 | 510.0 | 0.00 | 0.001 |

Best design per family (CV MAE): `ridge_strike_a10` 59.6 h / C 0.500; `ens_best` 61.0 h / C 0.500; `ipcw_strike_a10` 63.1 h / C 0.500; `xgbaft_strike_oblast_hist_d1n25` 73.7 h / C 0.546; `aft_strike_oblast_hist_a100` 174.9 h / C 0.675

### Binary task: will the restoration take longer than T hours? (primary T = 72 h)

Label as known at issue time / final dev label: long = observed duration > T or still unresolved at an elapsed time > T; short = observed <= T; censored before T = unknown, excluded. Learners: L2 logistic regression on the same feature sets, base rates (`bin_const` training base rate, `bin_oblast` oblast base rate) and the regression designs as scores (predicted hours; AUC only). AUC pooled over the scored episodes (also across strikes, so it is confounded by the drift of the base rate over time: `bin_const` is the reference, not 0.5; AUC within strikes uses pairs of the same strike only); CI = bootstrap over strikes; p AUC>0.5 one-sided bootstrap. Brier skill = 1 - Brier / Brier(bin_const), mean and SE over folds; p = Wilcoxon over per-strike Brier differences vs `bin_const`. Selection: best mean Brier skill, one-SE rule toward the simpler design (bin_const < bin_oblast < logit_strike < _oblast < _hist < other sets, larger alpha simpler).

#### Long-outage task, T = 24 h

Labelled scored episodes 85 in 16 strikes: long (> T h) 85 (100.0%), short 0; unknown (censored before T, excluded) 0.

Degenerate threshold: only one class among the scored episodes, no metric is defined.

#### Long-outage task, T = 72 h (PRIMARY, fixed in advance)

Labelled scored episodes 81 in 16 strikes: long (> T h) 57 (70.4%), short 24; unknown (censored before T, excluded) 4.

Best mean Brier skill: `logit_full_no_oblast_a100` 0.014 (SE 0.017); 1-SE threshold -0.002; 6 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_full_no_oblast_a100 | 0.396 | [0.174, 0.584] | 0.843 | 0.491 [0.250, 0.691] | 0.556 | 0.315 +- 0.059 | 0.225 | 0.014 | 0.017 | 0.50 | 0.744 |
| logit_full_a100 | 0.387 | [0.163, 0.576] | 0.860 | 0.439 [0.231, 0.590] | 0.771 | 0.285 +- 0.051 | 0.226 | 0.013 | 0.017 | 0.50 | 0.821 |
| logit_strike_a100 | 0.272 | [0.101, 0.525] | 0.965 | 0.500 [0.500, 0.500] | 1.000 | 0.277 +- 0.043 | 0.228 | 0.007 | 0.010 | 0.62 | 0.528 |
| logit_strike_oblast_a100 | 0.253 | [0.067, 0.483] | 0.983 | 0.140 [0.051, 0.263] | 1.000 | 0.164 +- 0.046 | 0.228 | 0.006 | 0.010 | 0.62 | 0.562 |
| bin_const | 0.238 | [0.102, 0.483] | 0.981 | 0.500 [0.500, 0.500] | 1.000 | 0.220 +- 0.027 | 0.229 | 0.000 | 0.000 |  |  |
| logit_strike_oblast_hist_a100 | 0.280 | [0.110, 0.527] | 0.961 | 0.333 [0.193, 0.538] | 0.956 | 0.217 +- 0.076 | 0.229 | -0.000 | 0.010 | 0.50 | 0.900 |
| logit_strike_oblast_early_a100 | 0.286 | [0.108, 0.510] | 0.971 | 0.316 [0.087, 0.493] | 0.982 | 0.197 +- 0.072 | 0.229 | -0.006 | 0.014 | 0.56 | 0.597 |
| logit_strike_oblast_hist_early_a100 | 0.309 | [0.135, 0.532] | 0.962 | 0.298 [0.176, 0.465] | 0.987 | 0.216 +- 0.039 | 0.229 | -0.013 | 0.021 | 0.62 | 0.495 |
| ridge_full_a100 | 0.632 | [0.430, 0.795] | 0.102 | 0.632 [0.412, 0.787] | 0.119 | 0.441 +- 0.124 |  |  |  |  |  |
| ridge_strike_oblast_early_a1 | 0.618 | [0.374, 0.824] | 0.151 | 0.614 [0.353, 0.846] | 0.227 | 0.566 +- 0.125 |  |  |  |  |  |
| aft_strike_oblast_hist_a100 | 0.396 | [0.206, 0.649] | 0.785 | 0.614 [0.412, 0.839] | 0.143 | 0.410 +- 0.101 |  |  |  |  |  |
| ridge_full_no_oblast_a100 | 0.626 | [0.421, 0.793] | 0.115 | 0.614 [0.439, 0.756] | 0.100 | 0.437 +- 0.122 |  |  |  |  |  |
| aft_full_no_oblast_a100 | 0.504 | [0.252, 0.731] | 0.478 | 0.614 [0.542, 0.733] | 0.001 | 0.445 +- 0.089 |  |  |  |  |  |
| aft_strike_oblast_hist_early_a100 | 0.394 | [0.202, 0.648] | 0.793 | 0.614 [0.383, 0.897] | 0.162 | 0.444 +- 0.086 |  |  |  |  |  |
| aft_strike_oblast_hist_a10 | 0.453 | [0.268, 0.699] | 0.619 | 0.596 [0.390, 0.871] | 0.193 | 0.569 +- 0.136 |  |  |  |  |  |
| xgbaft_strike_oblast_hist_d2n25 | 0.368 | [0.216, 0.561] | 0.916 | 0.596 [0.405, 0.855] | 0.192 | 0.350 +- 0.059 |  |  |  |  |  |
| bin_oblast | 0.290 | [0.210, 0.390] | 1.000 | 0.211 [0.140, 0.295] | 1.000 | 0.253 +- 0.063 | 0.267 | -0.174 | 0.017 | 0.12 | 0.018 |

#### Long-outage task, T = 168 h

Labelled scored episodes 77 in 16 strikes: long (> T h) 24 (31.2%), short 53; unknown (censored before T, excluded) 8.

Best mean Brier skill: `logit_strike_oblast_hist_a100` 0.064 (SE 0.089); 1-SE threshold -0.026; 9 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_strike_oblast_hist_a100 | 0.351 | [0.086, 0.637] | 0.828 | 1.000 [1.000, 1.000] | 0.002 | 0.436 +- 0.204 | 0.322 | 0.064 | 0.089 | 0.50 | 0.782 |
| logit_strike_oblast_hist_early_a100 | 0.334 | [0.085, 0.627] | 0.857 | 1.000 [1.000, 1.000] | 0.002 | 0.436 +- 0.211 | 0.333 | 0.035 | 0.099 | 0.50 | 0.597 |
| logit_strike_a100 | 0.333 | [0.060, 0.643] | 0.857 | 0.500 [0.500, 0.500] | 1.000 | 0.380 +- 0.191 | 0.333 | 0.028 | 0.073 | 0.38 | 0.495 |
| logit_strike_oblast_a100 | 0.333 | [0.060, 0.643] | 0.857 | 0.438 [0.438, 0.438] | 1.000 | 0.373 +- 0.189 | 0.333 | 0.028 | 0.073 | 0.38 | 0.495 |
| logit_full_no_oblast_a100 | 0.369 | [0.133, 0.667] | 0.818 | 0.500 [0.500, 0.500] | 1.000 | 0.412 +- 0.163 | 0.336 | 0.024 | 0.116 | 0.50 | 0.744 |
| logit_full_a100 | 0.371 | [0.134, 0.668] | 0.814 | 0.500 [0.500, 0.500] | 1.000 | 0.414 +- 0.162 | 0.336 | 0.023 | 0.116 | 0.44 | 0.632 |
| logit_strike_oblast_early_a100 | 0.316 | [0.062, 0.600] | 0.891 | 0.562 [0.562, 0.562] | 0.002 | 0.391 +- 0.191 | 0.344 | 0.000 | 0.082 | 0.38 | 0.274 |
| bin_const | 0.230 | [0.025, 0.628] | 0.897 | 0.500 [0.500, 0.500] | 1.000 | 0.190 +- 0.081 | 0.338 | 0.000 | 0.000 |  |  |
| aft_strike_oblast_hist_early_a100 | 0.214 | [0.057, 0.531] | 0.962 | 1.000 [1.000, 1.000] | 0.002 | 0.312 +- 0.183 |  |  |  |  |  |
| aft_strike_oblast_hist_a10 | 0.300 | [0.107, 0.663] | 0.858 | 1.000 [1.000, 1.000] | 0.002 | 0.378 +- 0.182 |  |  |  |  |  |
| aft_strike_oblast_hist_a100 | 0.216 | [0.056, 0.525] | 0.960 | 1.000 [1.000, 1.000] | 0.002 | 0.300 +- 0.195 |  |  |  |  |  |
| aft_strike_oblast_hist_early_a10 | 0.263 | [0.093, 0.570] | 0.932 | 0.938 [0.938, 0.938] | 0.002 | 0.348 +- 0.181 |  |  |  |  |  |
| aft_strike_oblast_hist_a1 | 0.330 | [0.132, 0.651] | 0.850 | 0.812 [0.812, 0.812] | 0.002 | 0.412 +- 0.163 |  |  |  |  |  |
| xgbaft_strike_oblast_hist_d2n60 | 0.320 | [0.119, 0.570] | 0.928 | 0.750 [0.750, 0.750] | 0.002 | 0.308 +- 0.109 |  |  |  |  |  |
| xgbaft_strike_oblast_hist_d1n60 | 0.229 | [0.061, 0.584] | 0.950 | 0.656 [0.656, 0.656] | 0.002 | 0.246 +- 0.138 |  |  |  |  |  |
| xgbaft_strike_oblast_hist_early_d1n60 | 0.232 | [0.049, 0.623] | 0.932 | 0.656 [0.656, 0.656] | 0.002 | 0.226 +- 0.138 |  |  |  |  |  |
| bin_oblast | 0.318 | [0.174, 0.484] | 0.982 | 0.469 [0.469, 0.469] | 1.000 | 0.355 +- 0.070 | 0.378 | -0.149 | 0.064 | 0.31 | 0.211 |

#### Ranking skill of the regression designs (bootstrap over 16 strikes)

Top 10 by C_within of 74 designs (p-values are NOT corrected for the choice among 74 designs), plus the baselines.

| design | C_within [95% CI] | p (C_within>0.5) | C_all [95% CI] | p (C_all>0.5) |
|---|---|---|---|---|
| aft_strike_oblast_hist_a10 | 0.690 [0.543, 0.845] | 0.004 | 0.416 [0.267, 0.600] | 0.781 |
| aft_strike_oblast_hist_a100 | 0.672 [0.550, 0.802] | 0.002 | 0.362 [0.217, 0.547] | 0.915 |
| xgbaft_strike_oblast_hist_d2n60 | 0.638 [0.518, 0.782] | 0.013 | 0.421 [0.312, 0.564] | 0.871 |
| aft_strike_oblast_hist_a1 | 0.631 [0.496, 0.787] | 0.041 | 0.425 [0.282, 0.606] | 0.741 |
| xgbaft_strike_oblast_hist_d2n25 | 0.623 [0.539, 0.723] | 0.002 | 0.363 [0.262, 0.496] | 0.981 |
| aft_strike_oblast_hist_early_a100 | 0.612 [0.500, 0.752] | 0.034 | 0.354 [0.208, 0.535] | 0.929 |
| aft_strike_oblast_hist_early_a10 | 0.604 [0.490, 0.752] | 0.043 | 0.399 [0.254, 0.576] | 0.834 |
| aft_strike_oblast_hist_early_a1 | 0.578 [0.472, 0.699] | 0.088 | 0.430 [0.290, 0.598] | 0.746 |
| xgbaft_strike_oblast_hist_early_d2n60 | 0.563 [0.387, 0.752] | 0.246 | 0.404 [0.295, 0.549] | 0.909 |
| xgbaft_strike_oblast_hist_d1n60 | 0.560 [0.459, 0.691] | 0.141 | 0.348 [0.240, 0.509] | 0.965 |
| global_median | 0.500 [0.500, 0.500] | 1.000 | 0.425 [0.288, 0.595] | 0.809 |
| geo_mean | 0.500 [0.500, 0.500] | 1.000 | 0.398 [0.265, 0.575] | 0.887 |
| oblast_median | 0.451 [0.243, 0.653] | 0.696 | 0.405 [0.316, 0.477] | 0.995 |

Early-impact features: dev CV for each cut-off K (hours after the strike time; main tables use K = 3). C within strikes, mean over folds (SE); MAE_cv h (SE).

| K h | design | C_within (SE) | MAE_cv h (SE) |
|---|---|---|---|
| 3 | aft_strike_oblast_hist_early_a100 | 0.631 (0.074) | 186.9 (57.4) |
| 3 | aft_strike_oblast_hist_early_a10 | 0.599 (0.077) | 207.3 (97.1) |
| 3 | xgbaft_strike_oblast_hist_early_d2n60 | 0.576 (0.100) | 189.8 (59.7) |
| 3 | aft_strike_oblast_hist_early_a1 | 0.562 (0.073) | 239.3 (84.3) |
| 3 | oblast_median | 0.412 (0.105) | 75.3 (13.0) |
| 3 | geo_mean | 0.500 (0.000) | 66.3 (14.2) |
| 6 | aft_strike_oblast_hist_early_a100 | 0.653 (0.072) | 182.0 (47.5) |
| 6 | aft_strike_oblast_hist_early_a10 | 0.612 (0.068) | 210.4 (93.2) |
| 6 | xgbaft_strike_oblast_hist_early_d2n60 | 0.608 (0.080) | 224.0 (51.8) |
| 6 | aft_strike_oblast_early_a100 | 0.590 (0.086) | 202.5 (42.6) |
| 6 | oblast_median | 0.412 (0.105) | 75.3 (13.0) |
| 6 | geo_mean | 0.500 (0.000) | 66.3 (14.2) |

Warm-up sensitivity (`region_dev_min_obs` = observed past episodes needed before the first forecast; dev value 15, normal mode 30):

| min_obs | strikes scored | first scored | global_median MAE | geo_mean MAE | best design (MAE, SE) | selected (1 SE) |
|---|---|---|---|---|---|---|
| 15 | 16 of 29 | 2023-02-10 | 63.3 | 66.3 | `ridge_strike_a10` (59.6, 10.1) | `global_median` |
| 30 | 11 of 29 | 2024-04-11 | 80.0 | 79.6 | `ens_best` (64.9, 13.5) | `ridge_strike_a100` |

## Window `30d`

Dev episodes 149 (131 observed); strikes scored 25 of 29 (2022-10-31 .. 2024-12-25).

Folds: #0: 5 strikes / 20 episodes / 12 observed; #1: 5 strikes / 23 episodes / 23 observed; #2: 5 strikes / 23 episodes / 22 observed; #3: 5 strikes / 22 episodes / 14 observed; #4: 5 strikes / 37 episodes / 37 observed

Best CV MAE: `ipcw_strike_oblast_hist_a100` 160.3 h (SE 23.5); 1-SE threshold 183.7 h; 28 designs within it. **Selected (simplest within 1 SE): `global_median`** (167.2 h).

Ensemble members: `ens_fixed` = geo_mean + ridge_strike_oblast_hist_a100 + ipcw_strike_oblast_hist_a100; `ens_best` = geo_mean + ridge_strike_oblast_hist_a100 + ipcw_strike_oblast_hist_a100

Top 10 by CV MAE, plus baselines and references:

| design | MAE_cv h | SE | LB_cv h | C_within | C_all | diff vs global_median h | better strikes | p per strike |
|---|---|---|---|---|---|---|---|---|
| ipcw_strike_oblast_hist_a100 | 160.3 | 23.5 | 193.2 | 0.623 | 0.565 | -0.3 | 0.42 | 0.944 |
| ridge_strike_oblast_hist_a100 | 160.7 | 25.9 | 191.8 | 0.616 | 0.567 | 0.2 | 0.54 | 0.966 |
| ens_best | 162.2 | 28.5 | 196.9 | 0.616 | 0.552 | -1.3 | 0.54 | 0.900 |
| ens_fixed | 162.2 | 28.5 | 196.9 | 0.616 | 0.552 | -1.3 | 0.54 | 0.900 |
| ipcw_strike_a100 | 166.4 | 31.5 | 200.9 | 0.500 | 0.560 | 2.7 | 0.42 | 0.623 |
| ipcw_strike_oblast_a100 | 166.4 | 31.4 | 200.8 | 0.588 | 0.559 | 2.7 | 0.46 | 0.603 |
| ridge_strike_a100 | 167.0 | 34.1 | 199.4 | 0.500 | 0.569 | 3.4 | 0.54 | 0.747 |
| ridge_strike_oblast_a100 | 167.1 | 33.9 | 199.4 | 0.586 | 0.569 | 3.5 | 0.54 | 0.726 |
| global_median | 167.2 | 24.1 | 200.5 | 0.500 | 0.500 |  |  |  |
| aft_strike_oblast_hist_a100 | 167.8 | 19.8 | 206.3 | 0.617 | 0.483 | 15.3 | 0.54 | 0.790 |
| geo_mean | 167.8 | 35.0 | 205.1 | 0.500 | 0.457 | 0.2 | 0.58 | 0.886 |
| km_global | 178.1 | 23.7 | 209.6 | 0.500 | 0.462 | 13.1 | 0.12 | 0.087 |
| oblast_median | 186.9 | 23.3 | 219.8 | 0.537 | 0.473 | 20.0 | 0.25 | 0.012 |
| const_30d | 467.2 | 54.2 | 406.8 | 0.500 | 0.500 | 299.9 | 0.12 | 0.000 |

Best design per family (CV MAE): `ipcw_strike_oblast_hist_a100` 160.3 h / C 0.623; `ridge_strike_oblast_hist_a100` 160.7 h / C 0.616; `ens_best` 162.2 h / C 0.616; `aft_strike_oblast_hist_a100` 167.8 h / C 0.617; `xgbaft_strike_oblast_hist_d1n25` 182.5 h / C 0.510

### Binary task: will the restoration take longer than T hours? (primary T = 72 h)

Label as known at issue time / final dev label: long = observed duration > T or still unresolved at an elapsed time > T; short = observed <= T; censored before T = unknown, excluded. Learners: L2 logistic regression on the same feature sets, base rates (`bin_const` training base rate, `bin_oblast` oblast base rate) and the regression designs as scores (predicted hours; AUC only). AUC pooled over the scored episodes (also across strikes, so it is confounded by the drift of the base rate over time: `bin_const` is the reference, not 0.5; AUC within strikes uses pairs of the same strike only); CI = bootstrap over strikes; p AUC>0.5 one-sided bootstrap. Brier skill = 1 - Brier / Brier(bin_const), mean and SE over folds; p = Wilcoxon over per-strike Brier differences vs `bin_const`. Selection: best mean Brier skill, one-SE rule toward the simpler design (bin_const < bin_oblast < logit_strike < _oblast < _hist < other sets, larger alpha simpler).

#### Long-outage task, T = 24 h

Labelled scored episodes 125 in 25 strikes: long (> T h) 125 (100.0%), short 0; unknown (censored before T, excluded) 0.

Degenerate threshold: only one class among the scored episodes, no metric is defined.

#### Long-outage task, T = 72 h (PRIMARY, fixed in advance)

Labelled scored episodes 125 in 25 strikes: long (> T h) 100 (80.0%), short 25; unknown (censored before T, excluded) 0.

Best mean Brier skill: `logit_strike_oblast_hist_a100` 0.003 (SE 0.007); 1-SE threshold -0.003; 5 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_strike_oblast_hist_a100 | 0.484 | [0.295, 0.671] | 0.562 | 0.534 [0.388, 0.738] | 0.340 | 0.412 +- 0.048 | 0.166 | 0.003 | 0.007 | 0.44 | 0.508 |
| bin_const | 0.482 | [0.299, 0.669] | 0.590 | 0.500 [0.500, 0.500] | 1.000 | 0.306 +- 0.091 | 0.166 | 0.000 | 0.000 |  |  |
| logit_strike_a100 | 0.469 | [0.280, 0.657] | 0.634 | 0.500 [0.500, 0.500] | 1.000 | 0.324 +- 0.082 | 0.166 | -0.000 | 0.004 | 0.48 | 1.000 |
| logit_strike_oblast_a100 | 0.466 | [0.275, 0.656] | 0.646 | 0.479 [0.310, 0.661] | 0.588 | 0.327 +- 0.060 | 0.166 | -0.001 | 0.003 | 0.48 | 0.853 |
| logit_strike_oblast_hist_early_a100 | 0.493 | [0.300, 0.673] | 0.552 | 0.493 [0.286, 0.700] | 0.519 | 0.388 +- 0.060 | 0.166 | -0.003 | 0.009 | 0.52 | 0.958 |
| logit_full_no_oblast_a100 | 0.472 | [0.275, 0.647] | 0.627 | 0.425 [0.244, 0.613] | 0.777 | 0.296 +- 0.071 | 0.167 | -0.004 | 0.003 | 0.44 | 0.381 |
| logit_full_a100 | 0.473 | [0.275, 0.648] | 0.620 | 0.411 [0.222, 0.618] | 0.808 | 0.295 +- 0.073 | 0.167 | -0.004 | 0.002 | 0.44 | 0.367 |
| logit_strike_oblast_early_a100 | 0.487 | [0.292, 0.682] | 0.576 | 0.521 [0.268, 0.754] | 0.447 | 0.334 +- 0.090 | 0.166 | -0.007 | 0.006 | 0.40 | 0.751 |
| ipcw_strike_oblast_hist_early_a10 | 0.640 | [0.404, 0.784] | 0.108 | 0.658 [0.564, 0.773] | 0.005 | 0.595 +- 0.087 |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a10 | 0.634 | [0.400, 0.778] | 0.112 | 0.644 [0.551, 0.767] | 0.006 | 0.580 +- 0.086 |  |  |  |  |  |
| ridge_strike_oblast_early_a1 | 0.593 | [0.362, 0.747] | 0.205 | 0.630 [0.421, 0.837] | 0.105 | 0.581 +- 0.091 |  |  |  |  |  |
| ipcw_strike_oblast_early_a1 | 0.599 | [0.371, 0.751] | 0.186 | 0.630 [0.421, 0.837] | 0.105 | 0.606 +- 0.108 |  |  |  |  |  |
| ipcw_strike_oblast_hist_early_a100 | 0.635 | [0.388, 0.795] | 0.127 | 0.616 [0.492, 0.745] | 0.037 | 0.578 +- 0.069 |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a100 | 0.631 | [0.381, 0.796] | 0.133 | 0.616 [0.492, 0.745] | 0.037 | 0.561 +- 0.070 |  |  |  |  |  |
| ridge_strike_oblast_early_a10 | 0.613 | [0.364, 0.781] | 0.169 | 0.616 [0.386, 0.836] | 0.152 | 0.532 +- 0.076 |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a1 | 0.609 | [0.391, 0.750] | 0.143 | 0.616 [0.500, 0.734] | 0.027 | 0.558 +- 0.073 |  |  |  |  |  |
| bin_oblast | 0.468 | [0.338, 0.587] | 0.692 | 0.500 [0.320, 0.674] | 0.498 | 0.425 +- 0.051 | 0.188 | -0.137 | 0.085 | 0.24 | 0.032 |

#### Long-outage task, T = 168 h

Labelled scored episodes 125 in 25 strikes: long (> T h) 66 (52.8%), short 59; unknown (censored before T, excluded) 0.

Best mean Brier skill: `logit_strike_oblast_hist_a100` 0.026 (SE 0.050); 1-SE threshold -0.024; 7 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_strike_oblast_hist_a100 | 0.532 | [0.344, 0.727] | 0.384 | 0.683 [0.463, 0.891] | 0.063 | 0.450 +- 0.101 | 0.265 | 0.026 | 0.050 | 0.52 | 0.615 |
| bin_const | 0.499 | [0.281, 0.715] | 0.531 | 0.500 [0.500, 0.500] | 1.000 | 0.325 +- 0.096 | 0.268 | 0.000 | 0.000 |  |  |
| logit_strike_a100 | 0.506 | [0.330, 0.688] | 0.505 | 0.500 [0.500, 0.500] | 1.000 | 0.336 +- 0.120 | 0.269 | -0.001 | 0.025 | 0.56 | 0.458 |
| logit_strike_oblast_a100 | 0.513 | [0.334, 0.696] | 0.463 | 0.571 [0.358, 0.788] | 0.250 | 0.358 +- 0.117 | 0.269 | -0.002 | 0.026 | 0.56 | 0.458 |
| logit_full_no_oblast_a100 | 0.492 | [0.309, 0.684] | 0.561 | 0.508 [0.298, 0.696] | 0.517 | 0.275 +- 0.080 | 0.276 | -0.015 | 0.027 | 0.56 | 0.791 |
| logit_full_a100 | 0.492 | [0.311, 0.684] | 0.559 | 0.508 [0.298, 0.696] | 0.517 | 0.281 +- 0.081 | 0.276 | -0.016 | 0.027 | 0.56 | 0.895 |
| logit_strike_oblast_hist_early_a100 | 0.511 | [0.317, 0.702] | 0.475 | 0.635 [0.356, 0.899] | 0.171 | 0.513 +- 0.080 | 0.273 | -0.018 | 0.044 | 0.44 | 0.560 |
| logit_strike_oblast_hist_a10 | 0.575 | [0.405, 0.739] | 0.185 | 0.714 [0.480, 0.899] | 0.038 | 0.506 +- 0.096 | 0.284 | -0.036 | 0.138 | 0.52 | 0.300 |
| aft_strike_oblast_hist_a1 | 0.573 | [0.409, 0.737] | 0.194 | 0.722 [0.561, 0.868] | 0.001 | 0.551 +- 0.098 |  |  |  |  |  |
| aft_strike_oblast_hist_a10 | 0.556 | [0.370, 0.725] | 0.274 | 0.683 [0.500, 0.852] | 0.032 | 0.519 +- 0.132 |  |  |  |  |  |
| ipcw_strike_oblast_hist_a1 | 0.638 | [0.482, 0.786] | 0.041 | 0.643 [0.514, 0.756] | 0.024 | 0.487 +- 0.091 |  |  |  |  |  |
| ridge_strike_oblast_hist_a1 | 0.640 | [0.486, 0.786] | 0.038 | 0.627 [0.500, 0.731] | 0.032 | 0.484 +- 0.091 |  |  |  |  |  |
| xgbaft_strike_oblast_hist_early_d1n60 | 0.443 | [0.270, 0.620] | 0.746 | 0.611 [0.515, 0.768] | 0.015 | 0.345 +- 0.028 |  |  |  |  |  |
| ridge_strike_oblast_hist_a10 | 0.622 | [0.458, 0.777] | 0.069 | 0.595 [0.460, 0.722] | 0.106 | 0.465 +- 0.084 |  |  |  |  |  |
| aft_strike_oblast_hist_a100 | 0.501 | [0.317, 0.677] | 0.497 | 0.587 [0.383, 0.755] | 0.190 | 0.450 +- 0.123 |  |  |  |  |  |
| ipcw_strike_oblast_hist_a10 | 0.614 | [0.454, 0.771] | 0.092 | 0.571 [0.412, 0.714] | 0.204 | 0.516 +- 0.048 |  |  |  |  |  |
| bin_oblast | 0.486 | [0.360, 0.623] | 0.590 | 0.563 [0.357, 0.763] | 0.250 | 0.434 +- 0.028 | 0.296 | -0.112 | 0.057 | 0.36 | 0.130 |

#### Ranking skill of the regression designs (bootstrap over 25 strikes)

Top 10 by C_within of 74 designs (p-values are NOT corrected for the choice among 74 designs), plus the baselines.

| design | C_within [95% CI] | p (C_within>0.5) | C_all [95% CI] | p (C_all>0.5) |
|---|---|---|---|---|
| aft_strike_oblast_hist_a10 | 0.633 [0.538, 0.732] | 0.003 | 0.535 [0.438, 0.631] | 0.232 |
| ipcw_strike_oblast_hist_early_a100 | 0.629 [0.507, 0.730] | 0.021 | 0.530 [0.427, 0.644] | 0.293 |
| aft_strike_oblast_hist_a1 | 0.627 [0.540, 0.721] | 0.002 | 0.556 [0.469, 0.645] | 0.096 |
| ipcw_strike_oblast_hist_early_a10 | 0.627 [0.502, 0.726] | 0.026 | 0.539 [0.446, 0.634] | 0.203 |
| ipcw_strike_oblast_hist_a100 | 0.624 [0.495, 0.745] | 0.037 | 0.565 [0.457, 0.673] | 0.114 |
| ridge_strike_oblast_hist_early_a100 | 0.624 [0.509, 0.730] | 0.024 | 0.543 [0.434, 0.661] | 0.234 |
| ridge_strike_oblast_hist_a1 | 0.622 [0.503, 0.734] | 0.023 | 0.568 [0.477, 0.660] | 0.079 |
| ridge_strike_oblast_hist_early_a10 | 0.622 [0.498, 0.725] | 0.032 | 0.552 [0.457, 0.645] | 0.145 |
| ipcw_strike_oblast_hist_a10 | 0.620 [0.504, 0.730] | 0.025 | 0.565 [0.468, 0.659] | 0.095 |
| ipcw_strike_oblast_hist_a1 | 0.618 [0.500, 0.732] | 0.029 | 0.569 [0.478, 0.661] | 0.069 |
| oblast_median | 0.576 [0.458, 0.696] | 0.105 | 0.473 [0.400, 0.547] | 0.708 |
| geo_mean | 0.500 [0.500, 0.500] | 1.000 | 0.457 [0.350, 0.574] | 0.771 |
| global_median | 0.500 [0.500, 0.500] | 1.000 | 0.500 [0.386, 0.616] | 0.525 |

Early-impact features: dev CV for each cut-off K (hours after the strike time; main tables use K = 3). C within strikes, mean over folds (SE); MAE_cv h (SE).

| K h | design | C_within (SE) | MAE_cv h (SE) |
|---|---|---|---|
| 3 | ipcw_strike_oblast_hist_early_a100 | 0.622 (0.043) | 172.5 (26.9) |
| 3 | ridge_strike_oblast_hist_early_a100 | 0.613 (0.045) | 173.0 (29.4) |
| 3 | ridge_strike_oblast_early_a10 | 0.608 (0.070) | 188.5 (30.8) |
| 3 | aft_strike_oblast_hist_early_a10 | 0.604 (0.045) | 228.5 (40.0) |
| 3 | oblast_median | 0.537 (0.064) | 186.9 (23.3) |
| 3 | geo_mean | 0.500 (0.000) | 167.8 (35.0) |
| 6 | ridge_strike_oblast_hist_early_a10 | 0.590 (0.042) | 180.9 (20.4) |
| 6 | aft_strike_oblast_hist_early_a1 | 0.578 (0.062) | 223.3 (28.5) |
| 6 | aft_strike_oblast_hist_early_a100 | 0.575 (0.041) | 178.1 (19.9) |
| 6 | ridge_strike_oblast_early_a100 | 0.573 (0.073) | 172.2 (33.8) |
| 6 | oblast_median | 0.537 (0.064) | 186.9 (23.3) |
| 6 | geo_mean | 0.500 (0.000) | 167.8 (35.0) |

Warm-up sensitivity (`region_dev_min_obs` = observed past episodes needed before the first forecast; dev value 15, normal mode 30):

| min_obs | strikes scored | first scored | global_median MAE | geo_mean MAE | best design (MAE, SE) | selected (1 SE) |
|---|---|---|---|---|---|---|
| 15 | 25 of 29 | 2022-10-31 | 167.2 | 167.8 | `ipcw_strike_oblast_hist_a100` (160.3, 23.5) | `global_median` |
| 30 | 18 of 29 | 2023-01-14 | 150.0 | 141.4 | `ridge_strike_oblast_hist_a100` (136.5, 11.0) | `geo_mean` |
