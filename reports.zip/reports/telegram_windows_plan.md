# Telegram window collection: plan

Generated 2026-10-31 20:10 UTC by `deficit collect --windows-from-attacks`. The estimate makes no request: it uses the (post id, time) points already stored per channel (keyword-search samples) and linear interpolation between them.

## Selection rule (does not look at any outage outcome)

- Candidates: every row of `data/external/attacks.csv` dated 2022-09-01 or later (76 strikes).
- Window of a strike: [strike day - 1 d, strike day + 14 d], both days included, UTC; overlapping windows (chained strikes) are merged.
- Rule applied: **all strikes**. Strikes are ranked by `weapons_through` (weapons that reached their targets, an attack-size column of attacks.csv), never by observed impact or restoration times.
- Selected 76 of 76 strikes; time budget 100 h.

## Request budget (hard limits in `telegram_public.py`)

- One collector process, never parallel; 3-5 s random delay between requests, at most 800 requests per hour (sliding window, retries included), 60 s pause between channels, `Retry-After` honoured with growing backoff, descriptive User-Agent, everything stops at the 3rd HTTP 429.
- Effective rate: min(800/h cap, 3600 / mean delay = 900/h) = **800 requests/hour** (one request per 4.5 s).

## Estimate

Requests per window = ids in the window / 20 (an upper bound: deleted posts leave id gaps) + 3 probes (hard limit 6 per window).

Intervals already listed in `_windows.csv` are subtracted (only the uncovered parts are requested); "full" is the cost of the same windows without that.

| channel | windows | to do | est. ids | est. requests | full requests | est. hours |
|---|---|---|---|---|---|---|
| chernigivskaoda | 14 | 14 | 14426 | 771 | 771 | 0.96 |
| ternopilskaoda | 14 | 14 | 14284 | 764 | 764 | 0.95 |
| chernivetskaoda | 14 | 14 | 9161 | 508 | 508 | 0.64 |
| zakarpatskaoda | 14 | 14 | 6164 | 355 | 355 | 0.44 |
| donetskaoda | 14 | 14 | 34934 | 1795 | 1795 | 2.24 |
| kirovohradskaoda | 14 | 14 | 23034 | 1203 | 1203 | 1.50 |
| khersonskaoda | 14 | 14 | 34418 | 1769 | 1769 | 2.21 |
| vinnytsiaoda | 14 | 14 | 32958 | 1695 | 1695 | 2.12 |
| khmelnytskaoda | 14 | 14 | 6732 | 385 | 385 | 0.48 |
| zhytomyrskaoda | 14 | 14 | 8019 | 451 | 451 | 0.56 |
| volynskaoda | 14 | 14 | 4663 | 282 | 282 | 0.35 |
| **total** | | | | 9978 | 9978 | **12.64** (incl. channel pauses) |

With all 76 strikes the estimate would be 9978 requests (12.64 h).

## Strikes

| date | weapons_through | selected |
|---|---|---|
| 2022-09-11 | 3 | yes |
| 2022-10-10 | 52 | yes |
| 2022-10-11 | 10 | yes |
| 2022-10-22 | 20 | yes |
| 2022-10-31 | 38 | yes |
| 2022-11-15 | 21 | yes |
| 2022-11-23 | 19 | yes |
| 2022-12-05 | 10 | yes |
| 2022-12-16 | 43 | yes |
| 2022-12-29 | 12 | yes |
| 2022-12-31 | 5 | yes |
| 2023-01-14 | 13 | yes |
| 2023-01-26 | 5 | yes |
| 2023-02-10 | 47 | yes |
| 2023-02-16 | 18 | yes |
| 2023-03-09 | 43 | yes |
| 2024-03-22 | 59 | yes |
| 2024-03-29 | 15 | yes |
| 2024-04-11 | 25 | yes |
| 2024-04-27 | 13 | yes |
| 2024-05-08 | 17 | yes |
| 2024-06-01 | 19 | yes |
| 2024-06-20 | 4 | yes |
| 2024-06-22 | 4 | yes |
| 2024-08-26 | 30 | yes |
| 2024-11-17 | 23 | yes |
| 2024-11-28 | 12 | yes |
| 2024-12-13 | 15 | yes |
| 2024-12-25 | 19 | yes |
| 2025-01-15 | 13 | yes |
| 2025-02-01 | 48 | yes |
| 2025-02-11 | 22 | yes |
| 2025-02-20 | 17 | yes |
| 2025-03-07 | 22 | yes |
| 2025-07-23 | 26 | yes |
| 2025-08-19 | 44 | yes |
| 2025-08-27 | 21 | yes |
| 2025-08-31 | 16 | yes |
| 2025-09-08 | 30 | yes |
| 2025-10-03 | 96 | yes |
| 2025-10-05 | 65 | yes |
| 2025-10-10 | 73 | yes |
| 2025-10-16 | 51 | yes |
| 2025-10-22 | 67 | yes |
| 2025-10-30 | 79 | yes |
| 2025-11-08 | 88 | yes |
| 2025-11-19 | 41 | yes |
| 2025-11-25 | 34 | yes |
| 2025-11-29 | 55 | yes |
| 2025-12-06 | 89 | yes |
| 2025-12-13 | 59 | yes |
| 2025-12-23 | 49 | yes |
| 2025-12-27 | 40 | yes |
| 2026-01-01 | 29 | yes |
| 2026-01-08 | 27 | yes |
| 2026-01-09 | 34 | yes |
| 2026-01-13 | 71 | yes |
| 2026-01-20 | 31 | yes |
| 2026-01-24 | 24 | yes |
| 2026-02-03 | 71 | yes |
| 2026-02-07 | 41 | yes |
| 2026-02-12 | 31 | yes |
| 2026-02-17 | 33 | yes |
| 2026-02-22 | 40 | yes |
| 2026-02-26 | 53 | yes |
| 2026-03-07 | 37 | yes |
| 2026-03-14 | 38 | yes |
| 2026-03-24 | 51 | yes |
| 2026-04-01 | 57 | yes |
| 2026-04-02 | 25 | yes |
| 2026-04-03 | 38 | yes |
| 2026-04-16 | 36 | yes |
| 2026-05-01 | 41 | yes |
| 2026-05-14 | 109 | yes |
| 2026-06-02 | 87 | yes |
| 2026-06-15 | 49 | yes |
