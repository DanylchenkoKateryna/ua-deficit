# Telegram window collection: plan

Generated 2026-10-25 16:20 UTC by `deficit collect --windows-from-attacks`. The estimate makes no request: it uses the (post id, time) points already stored per channel (keyword-search samples) and linear interpolation between them.

## Selection rule (does not look at any outage outcome)

- Candidates: every row of `data/external/attacks.csv` dated 2022-09-01 or later (76 strikes).
- Window of a strike: [strike day - 1 d, strike day + 7 d], both days included, UTC; overlapping windows (chained strikes) are merged.
- Rule applied: **strikes in descending weapons_through (ties: earlier date first) while the estimated total time stays within 6 h: top 60 of 76**. Strikes are ranked by `weapons_through` (weapons that reached their targets, an attack-size column of attacks.csv), never by observed impact or restoration times.
- Selected 60 of 76 strikes; time budget 6 h.
- Channel-specific end of the window period: dnipropetrovskaoda until 2024-10-31.

## Request budget (hard limits in `telegram_public.py`)

- One collector process, never parallel; 3-5 s random delay between requests, at most 800 requests per hour (sliding window, retries included), 60 s pause between channels, `Retry-After` honoured with growing backoff, descriptive User-Agent, everything stops at the 3rd HTTP 429.
- Effective rate: min(800/h cap, 3600 / mean delay = 900/h) = **800 requests/hour** (one request per 4.5 s).

## Estimate

Requests per window = ids in the window / 20 (an upper bound: deleted posts leave id gaps) + 3 probes (hard limit 6 per window).

| channel | windows | est. ids | est. requests | est. hours |
|---|---|---|---|---|
| kharkivoda | 29 | 8280 | 514 | 0.64 |
| kyivoda | 29 | 18137 | 1008 | 1.26 |
| odeskaoda | 29 | 6559 | 429 | 0.54 |
| zoda_gov_ua | 29 | 19131 | 1058 | 1.32 |
| poltavskaoda | 29 | 28519 | 1522 | 1.90 |
| dnipropetrovskaoda | 11 | 1965 | 138 | 0.17 |
| **total** | | | 4669 | **5.92** (incl. channel pauses) |

With all 76 strikes the estimate would be 5506 requests (6.97 h).

## Strikes

| date | weapons_through | selected |
|---|---|---|
| 2022-09-11 | 3 | no |
| 2022-10-10 | 52 | yes |
| 2022-10-11 | 10 | no |
| 2022-10-22 | 20 | yes |
| 2022-10-31 | 38 | yes |
| 2022-11-15 | 21 | yes |
| 2022-11-23 | 19 | yes |
| 2022-12-05 | 10 | no |
| 2022-12-16 | 43 | yes |
| 2022-12-29 | 12 | no |
| 2022-12-31 | 5 | no |
| 2023-01-14 | 13 | no |
| 2023-01-26 | 5 | no |
| 2023-02-10 | 47 | yes |
| 2023-02-16 | 18 | yes |
| 2023-03-09 | 43 | yes |
| 2024-03-22 | 59 | yes |
| 2024-03-29 | 15 | no |
| 2024-04-11 | 25 | yes |
| 2024-04-27 | 13 | no |
| 2024-05-08 | 17 | yes |
| 2024-06-01 | 19 | yes |
| 2024-06-20 | 4 | no |
| 2024-06-22 | 4 | no |
| 2024-08-26 | 30 | yes |
| 2024-11-17 | 23 | yes |
| 2024-11-28 | 12 | no |
| 2024-12-13 | 15 | no |
| 2024-12-25 | 19 | yes |
| 2025-01-15 | 13 | no |
| 2025-02-01 | 48 | yes |
| 2025-02-11 | 22 | yes |
| 2025-02-20 | 17 | no |
| 2025-03-07 | 22 | yes |
| 2025-07-23 | 26 | yes |
| 2025-08-19 | 44 | yes |
| 2025-08-27 | 21 | yes |
| 2025-08-31 | 16 | no |
| 2025-09-08 | 30 | yes |
| 2025-10-03 | 96 | yes |
| 2025-10-05 | 65 | yes |
| 2025-10-10 | 73 | yes |
| 2025-10-16 | 51 | yes |
| 2025-10-22 | 67 | yes |
| 2025-10-30 | 79 | yes |
| 2025-11-08 | 88 | yes |
| 2025-11-19 | 41 | yes |
| 2025-11-25 | 34 | yes |
| 2025-11-29 | 55 | yes |
| 2025-12-06 | 89 | yes |
| 2025-12-13 | 59 | yes |
| 2025-12-23 | 49 | yes |
| 2025-12-27 | 40 | yes |
| 2026-01-01 | 29 | yes |
| 2026-01-08 | 27 | yes |
| 2026-01-09 | 34 | yes |
| 2026-01-13 | 71 | yes |
| 2026-01-20 | 31 | yes |
| 2026-01-24 | 24 | yes |
| 2026-02-03 | 71 | yes |
| 2026-02-07 | 41 | yes |
| 2026-02-12 | 31 | yes |
| 2026-02-17 | 33 | yes |
| 2026-02-22 | 40 | yes |
| 2026-02-26 | 53 | yes |
| 2026-03-07 | 37 | yes |
| 2026-03-14 | 38 | yes |
| 2026-03-24 | 51 | yes |
| 2026-04-01 | 57 | yes |
| 2026-04-02 | 25 | yes |
| 2026-04-03 | 38 | yes |
| 2026-04-16 | 36 | yes |
| 2026-05-01 | 41 | yes |
| 2026-05-14 | 109 | yes |
| 2026-06-02 | 87 | yes |
| 2026-06-15 | 49 | yes |
