# Telegram posts as forecast inputs: depth, duration and restriction-regime duration

Assembled from `reports/<scenario>/post_event*.csv` and `reports/telegram_restoration_*.csv` (commands: `deficit events --config config/<sc>.yaml`, `deficit restoration`).
Data: `data/processed/telegram_posts.parquet` (17 836 posts, extract of 2026-10-18; the collector for `energoatom_ua` was still running, which does not touch the national channel used here).

## Bottom line

1. **Depth after a strike is already forecast better than persistence without Telegram** (price: `ridge_depth` p=0.009 on validation and <0.001 on test; net import: test p<0.001; outages: no model beats persistence). **Telegram severity features do not improve it on the validation period** (the only period the design may be chosen on): in all three scenarios the Telegram variants are worse on validation than the same models without them. On the test period they are better in all three scenarios (for example net import `xgb_direct_g` 333 vs 383 MW, p=0.001; outages `xgb_direct_tg` 0.281 vs 0.426, p=0.009). Per the rules this is **not** a basis for adopting them, and the three scenarios share the same strike dates, so they are not three independent confirmations. The Telegram feature sets stay available as an ablation (`*_g`, `*_tg`), not as the headline model.
2. **The duration of the deficit episode never beats persistence**, with or without Telegram features, in any scenario or split. Where a test is significant it is against the model (net import test `xgb_direct` p=0.012: worse than persistence; price validation `xgb_rolling` p=0.043: worse). The Telegram duration variants change nothing consistently: differences have both signs, and the few nominally significant ones (outages: validation `xgb_aft_tg` worse than `xgb_aft_t` p=0.029, validation `xgb_direct_tg` better than `xgb_direct_t` p=0.039, test `xgb_direct_g` better than `xgb_direct` p=0.045) point in opposite directions.
3. **Restriction-regime duration** (new target, 77 strikes, 33 observed): there is no evidence that any model, with or without Telegram features, beats the median of past durations. Details and the censoring caveat below.
4. `demand` has 2 validation and 4 test events: no test is possible (n<8) and it is not reported.

## 1. Features (all known at the end of the issue day)

`features/telegram.py`, channel `ukrenergo` (`telegram.feature_channels`; chosen for continuous coverage since 2022-02, not on performance; pooled channels change coverage over time, see `reports/telegram_extraction_quality.md`). Row d reads only posts with `datetime < d + 1 day`; days before the first post are NaN.

* Issue day: damaged generation, damaged substation/transmission, number of regions hit, log(1+consumers without power), emergency outages, schedules announced, attack reports, "restrictions lifted" statement.
* 7 days: days with schedules, days with emergency outages, days with damaged generation, max regions per day, days with a lifting statement.
* 30 days: days with schedules, days with emergency outages, days with damaged generation, max regions per day.
* Direct post-event models: `_g` = base set + all 17 columns, `_tg` = tension set + all 17; `ridge_depth_g` adds six of them (consumers, regions, generation, substation, emergency, schedules) to the ridge. The old sets are unchanged (the old columns of `post_event.csv` are bit-identical to the previous run).
* Leakage tests (`tests/test_no_leakage.py`): posts at or after the issue time (and a post exactly at it) do not change the features, the direct forecasts or the restoration forecast; one second before it they do. The tests fail when the window is moved one day forward (checked by mutation).
* Day-ahead features (`features/build.py`) were **not** changed: it needs retraining and a four-scenario re-evaluation, which is not cheap.

## 2. Depth and duration after a strike (and BOCPD alarm), per scenario

Events are the strike days plus BOCPD alarms (one per issue day). Validation = events up to the end of the scenario's validation period, test = after. `persistence` is the reference, `xgb_rolling` the retraining ablation. p-values are paired Wilcoxon on per-event absolute errors against persistence; events overlap in time (30-day windows), so they are optimistic. About 60 p-values are shown without correction.

### price: 22 validation and 61 test events

Depth (MAE in the unit of the scenario; p = paired Wilcoxon against persistence)

| method | val n | val MAE | val p vs pers. | test n | test MAE | test p vs pers. |
|---|---|---|---|---|---|---|
| persistence | 22 | 0.051 |  | 61 | 0.228 |  |
| xgb_rolling | 22 | 0.043 | 0.019 | 61 | 0.163 | <0.001 |
| ridge_depth | 22 | 0.021 | 0.009 | 61 | 0.066 | <0.001 |
| ridge_depth_g | 22 | 0.047 | 0.949 | 61 | 0.059 | <0.001 |
| xgb_direct | 22 | 0.040 | 0.824 | 61 | 0.067 | <0.001 |
| xgb_direct_g | 22 | 0.060 | 0.679 | 61 | 0.064 | <0.001 |
| xgb_direct_t | 22 | 0.033 | 0.276 | 61 | 0.061 | <0.001 |
| xgb_direct_tg | 22 | 0.066 | 0.235 | 61 | 0.060 | <0.001 |

Duration (MAE in days)

| method | val n | val MAE | val p vs pers. | test n | test MAE | test p vs pers. |
|---|---|---|---|---|---|---|
| persistence | 22 | 5.636 |  | 61 | 3.295 |  |
| xgb_rolling | 22 | 9.273 | 0.043 | 61 | 2.803 | 0.317 |
| xgb_direct | 22 | 7.773 | 0.280 | 61 | 1.328 | 0.298 |
| xgb_direct_g | 22 | 8.136 | 0.267 | 61 | 1.328 | 0.308 |
| xgb_direct_t | 22 | 9.000 | 0.197 | 61 | 1.541 | 0.328 |
| xgb_direct_tg | 22 | 9.545 | 0.112 | 61 | 1.590 | 0.675 |
| xgb_aft | 22 | 7.318 | 0.416 | 61 | 1.230 | 0.515 |
| xgb_aft_g | 22 | 6.636 | 0.674 | 61 | 1.361 | 0.951 |
| xgb_aft_t | 22 | 8.318 | 0.374 | 61 | 1.459 | 0.897 |
| xgb_aft_tg | 22 | 8.364 | 0.286 | 61 | 1.443 | 0.717 |

Telegram vs the same model without telegram features (mean absolute error of the telegram model minus that of the reference; negative = telegram closer to the truth)

| method | reference | metric | val n | val diff | val p | test n | tes diff | tes p |
|---|---|---|---|---|---|---|---|---|
| ridge_depth_g | ridge_depth | depth | 22 | 0.0261 | 0.030 | 61 | -0.0071 | 0.002 |
| xgb_direct_g | xgb_direct | depth | 22 | 0.0198 | 0.276 | 61 | -0.0031 | 0.436 |
| xgb_direct_g | xgb_direct | duration | 22 | 0.3636 | 0.185 | 61 | 0.0000 | 0.782 |
| xgb_direct_tg | xgb_direct_t | depth | 22 | 0.0327 | <0.001 | 61 | -0.0009 | 0.453 |
| xgb_direct_tg | xgb_direct_t | duration | 22 | 0.5455 | 0.170 | 61 | 0.0492 | 0.257 |
| xgb_aft_g | xgb_aft | duration | 22 | -0.6818 | 0.317 | 61 | 0.1311 | 0.175 |
| xgb_aft_tg | xgb_aft_t | duration | 22 | 0.0455 | 0.865 | 61 | -0.0164 | 0.826 |

### net_import: 20 validation and 61 test events

Depth (MAE in the unit of the scenario; p = paired Wilcoxon against persistence)

| method | val n | val MAE | val p vs pers. | test n | test MAE | test p vs pers. |
|---|---|---|---|---|---|---|
| persistence | 20 | 199.814 |  | 61 | 632.214 |  |
| xgb_rolling | 20 | 163.103 | 0.368 | 61 | 517.939 | <0.001 |
| ridge_depth | 20 | 203.319 | 0.985 | 61 | 335.096 | <0.001 |
| ridge_depth_g | 20 | 270.738 | 0.189 | 61 | 315.452 | <0.001 |
| xgb_direct | 20 | 262.981 | 0.261 | 61 | 383.157 | <0.001 |
| xgb_direct_g | 20 | 304.728 | 0.114 | 61 | 333.327 | <0.001 |
| xgb_direct_t | 20 | 240.801 | 0.898 | 61 | 390.985 | <0.001 |
| xgb_direct_tg | 20 | 264.087 | 0.368 | 61 | 359.339 | <0.001 |

Duration (MAE in days)

| method | val n | val MAE | val p vs pers. | test n | test MAE | test p vs pers. |
|---|---|---|---|---|---|---|
| persistence | 20 | 0.000 |  | 61 | 3.705 |  |
| xgb_rolling | 20 | 0.000 | n/a | 61 | 4.361 | 0.285 |
| xgb_direct | 20 | 0.000 | n/a | 61 | 8.000 | 0.012 |
| xgb_direct_g | 20 | 0.000 | n/a | 61 | 8.000 | 0.012 |
| xgb_direct_t | 20 | 0.000 | n/a | 61 | 7.967 | 0.013 |
| xgb_direct_tg | 20 | 0.000 | n/a | 61 | 7.967 | 0.013 |
| xgb_aft | 20 | 0.000 | n/a | 61 | 6.344 | 0.091 |
| xgb_aft_g | 20 | 0.000 | n/a | 61 | 6.557 | 0.097 |
| xgb_aft_t | 20 | 0.000 | n/a | 61 | 6.328 | 0.059 |
| xgb_aft_tg | 20 | 0.000 | n/a | 61 | 6.213 | 0.105 |

Telegram vs the same model without telegram features (mean absolute error of the telegram model minus that of the reference; negative = telegram closer to the truth)

| method | reference | metric | val n | val diff | val p | test n | tes diff | tes p |
|---|---|---|---|---|---|---|---|---|
| ridge_depth_g | ridge_depth | depth | 20.0000 | 67.4186 | 0.091 | 61 | -19.6443 | 0.009 |
| xgb_direct_g | xgb_direct | depth | 20.0000 | 41.7468 | 0.070 | 61 | -49.8309 | 0.001 |
| xgb_direct_tg | xgb_direct_t | depth | 20.0000 | 23.2855 | 0.409 | 61 | -31.6463 | 0.060 |
| xgb_direct_tg | xgb_direct_t | duration |  |  | n/a | 61 | 0.0000 | 1.000 |
| xgb_aft_g | xgb_aft | duration |  |  | n/a | 61 | 0.2131 | 0.861 |
| xgb_aft_tg | xgb_aft_t | duration |  |  | n/a | 61 | -0.1148 | 0.463 |

### outages: 20 validation and 30 test events

Depth (MAE in the unit of the scenario; p = paired Wilcoxon against persistence)

| method | val n | val MAE | val p vs pers. | test n | test MAE | test p vs pers. |
|---|---|---|---|---|---|---|
| persistence | 20 | 0.283 |  | 29 | 0.281 |  |
| xgb_rolling | 20 | 0.233 | 0.398 | 29 | 0.313 | 0.370 |
| ridge_depth | 20 | 0.283 | 0.571 | 29 | 0.259 | 0.717 |
| ridge_depth_g | 20 | 0.303 | 0.648 | 29 | 0.231 | 0.256 |
| xgb_direct | 20 | 0.269 | 0.869 | 29 | 0.362 | 0.198 |
| xgb_direct_g | 20 | 0.288 | 0.841 | 29 | 0.279 | 0.766 |
| xgb_direct_t | 20 | 0.256 | 0.927 | 29 | 0.426 | 0.121 |
| xgb_direct_tg | 20 | 0.291 | 0.701 | 29 | 0.281 | 0.733 |

Duration (MAE in days)

| method | val n | val MAE | val p vs pers. | test n | test MAE | test p vs pers. |
|---|---|---|---|---|---|---|
| persistence | 20 | 9.050 |  | 30 | 5.933 |  |
| xgb_rolling | 20 | 10.700 | 0.180 | 30 | 7.933 | 0.157 |
| xgb_direct | 20 | 10.350 | 0.861 | 30 | 8.433 | 0.296 |
| xgb_direct_g | 20 | 9.800 | 0.753 | 30 | 7.533 | 0.437 |
| xgb_direct_t | 20 | 11.600 | 0.727 | 30 | 7.533 | 0.538 |
| xgb_direct_tg | 20 | 11.050 | 0.780 | 30 | 7.267 | 0.553 |
| xgb_aft | 20 | 12.400 | 0.308 | 30 | 10.467 | 0.052 |
| xgb_aft_g | 20 | 11.100 | 0.532 | 30 | 8.533 | 0.220 |
| xgb_aft_t | 20 | 11.000 | 0.477 | 30 | 8.733 | 0.235 |
| xgb_aft_tg | 20 | 12.200 | 0.234 | 30 | 8.100 | 0.537 |

Telegram vs the same model without telegram features (mean absolute error of the telegram model minus that of the reference; negative = telegram closer to the truth)

| method | reference | metric | val n | val diff | val p | test n | tes diff | tes p |
|---|---|---|---|---|---|---|---|---|
| ridge_depth_g | ridge_depth | depth | 20 | 0.0201 | 0.475 | 29 | -0.0284 | 0.096 |
| xgb_direct_g | xgb_direct | depth | 20 | 0.0193 | 0.956 | 29 | -0.0837 | 0.039 |
| xgb_direct_g | xgb_direct | duration | 20 | -0.5500 | 0.325 | 30 | -0.9000 | 0.045 |
| xgb_direct_tg | xgb_direct_t | depth | 20 | 0.0345 | 0.312 | 29 | -0.1452 | 0.009 |
| xgb_direct_tg | xgb_direct_t | duration | 20 | -0.5500 | 0.039 | 30 | -0.2667 | 0.527 |
| xgb_aft_g | xgb_aft | duration | 20 | -1.3000 | 0.938 | 30 | -1.9333 | 0.076 |
| xgb_aft_tg | xgb_aft_t | duration | 20 | 1.2000 | 0.029 | 30 | -0.6333 | 0.254 |



## 3. Duration of the restriction regime after a strike (`deficit restoration`)

**Target.** `days_to_resolution` from `telegram_episodes` (scope ALL): strike to the first Ukrenergo post saying that schedules / emergency outages are not applied any more (strikes without a regime: first "all consumers have power" post). 77 strikes, 33 observed, 44 right-censored (no such post within the 30-day window). Censored strikes are never dropped from the evaluation or from the AFT fit.

**Protocol.** Forecast at the end of the strike day from posts before it. Strikes are processed in time order (leave-later-out): the model for strike i is fitted on strikes j<i with the label **as it was known at that instant** (observed if the lifting post is older than the issue time, otherwise censored at the time watched), so later strikes and later posts never enter. A model needs at least 3 observed labels, so 5 early strikes are not scored: **12 validation strikes (9 observed) and 60 test strikes (21 observed)**; training sets hold 3 to 35 observed labels.

**Sample size warning.** Only 21 observed test durations; 16 of the 33 observed durations end after the next strike (a chain of strikes shares one lifting post and one "duration" is the time remaining of the same regime), so strikes are not independent and all p-values are optimistic. The validation period (9 observed) cannot choose a design reliably; the choice below is nominal.

**Predictors.** `median_obs` (median of observed durations so far; ignores censoring), `km_median` (Kaplan-Meier median of all labels so far), `last_episode` (duration of the latest observed strike), `const_30` (always the window length: not a model, a check on the metric), ridge on log-duration (observed strikes only) and log-normal AFT with right censoring (L2 penalty), each on five feature sets: `attack` (strength of the strike, gap to the previous strike, strikes in the last 30 days, heating season), `tg` (+ 8 compact Telegram severity columns), `tg_regime` (+ regime age and days since the last lifting post), `tg_full` (all 17 columns + regime), `tg_all` (as `tg_regime`, all channels pooled). Penalty 1 or 10 (config `telegram.restoration_alphas`). The design is chosen on validation by the lower-bound MAE: `aft_tg_a1` and `ridge_tg_a1` (the latter overall). All 20 designs are in `reports/telegram_restoration_scores.csv`; none was tuned on test.

**Metrics.** MAE in days on observed strikes (biased towards short predictions, because the long regimes are censored); a lower-bound MAE on all strikes (a censored strike costs max(0, censor time minus prediction), the smallest error it can have; biased towards long predictions); Harrell's C on all strikes (0.5 = no ranking skill).

**validation** (strikes scored: 12, observed: 9)

| method | chosen | MAE_observed_days | MAE_lower_bound_all_days | C_index |
|---|---|---|---|---|
| median_obs |  | 7.833 | 12.528 | 0.278 |
| km_median |  | 13.617 | 13.642 | 0.500 |
| last_episode |  | 8.001 | 11.144 | 0.643 |
| const_30 |  | 19.541 | 14.656 | 0.500 |
| aft_attack_a1 |  | 11.862 | 14.524 | 0.357 |
| aft_tg_a1 | yes | 9.653 | 9.512 | 0.595 |
| ridge_attack_a1 |  | 7.348 | 11.079 | 0.413 |
| ridge_tg_a1 | yes | 7.510 | 8.656 | 0.619 |
| aft_tg_all_a1 |  | 14.690 | 15.501 | 0.373 |

**test** (strikes scored: 60, observed: 21)

| method | chosen | MAE_observed_days | MAE_lower_bound_all_days | C_index |
|---|---|---|---|---|
| median_obs |  | 6.450 | 17.601 | 0.575 |
| km_median |  | 8.505 | 8.905 | 0.608 |
| last_episode |  | 8.144 | 20.159 | 0.362 |
| const_30 |  | 19.966 | 6.988 | 0.500 |
| aft_attack_a1 |  | 12.337 | 7.618 | 0.608 |
| aft_tg_a1 | yes | 11.983 | 8.266 | 0.594 |
| ridge_attack_a1 |  | 6.695 | 18.092 | 0.421 |
| ridge_tg_a1 | yes | 9.670 | 17.832 | 0.445 |
| aft_tg_all_a1 |  | 10.083 | 7.179 | 0.658 |

**paired Wilcoxon** (diff = mean error of method minus mean error of reference, days; negative = method better)

| split | method | vs | n_obs | diff_obs | p_obs | n_lb | diff_lb | p_lb |
|---|---|---|---|---|---|---|---|---|
| validation | aft_tg_a1 | aft_attack_a1 | 9 | -2.21 | 0.219 | 12 | -5.01 | 0.064 |
| validation | aft_tg_a1 | const_30 | 9 | -9.89 | 0.062 | 12 | -5.14 | 0.375 |
| validation | aft_tg_a1 | km_median | 9 | -3.96 | 0.156 | 12 | -4.13 | 0.164 |
| validation | aft_tg_a1 | last_episode | 9 | 1.65 | 0.879 | 12 | -1.63 | 0.665 |
| validation | aft_tg_a1 | median_obs | 9 | 1.82 | 1.000 | 12 | -3.02 | 0.554 |
| validation | km_median | const_30 | 9 | -5.92 | 0.062 | 12 | -1.01 | 0.656 |
| validation | km_median | last_episode | 9 | 5.62 | 0.242 | 12 | 2.50 | 0.475 |
| validation | km_median | median_obs | 9 | 5.78 | 0.359 | 12 | 1.11 | 0.835 |
| validation | ridge_tg_a1 | const_30 | 9 | -12.03 | 0.055 | 12 | -6.00 | 0.233 |
| validation | ridge_tg_a1 | km_median | 9 | -6.11 | 0.203 | 12 | -4.99 | 0.204 |
| validation | ridge_tg_a1 | last_episode | 9 | -0.49 | 1.000 | 12 | -2.49 | 0.380 |
| validation | ridge_tg_a1 | median_obs | 9 | -0.32 | 1.000 | 12 | -3.87 | 0.266 |
| validation | ridge_tg_a1 | ridge_attack_a1 | 9 | 0.16 | 0.734 | 12 | -2.42 | 0.733 |
| test | aft_tg_a1 | aft_attack_a1 | 21 | -0.35 | 0.807 | 60 | 0.65 | 0.784 |
| test | aft_tg_a1 | const_30 | 21 | -7.98 | 0.003 | 60 | 1.28 | 0.427 |
| test | aft_tg_a1 | km_median | 21 | 3.48 | 0.078 | 60 | -0.64 | 0.546 |
| test | aft_tg_a1 | last_episode | 21 | 3.84 | 0.243 | 60 | -11.89 | <0.001 |
| test | aft_tg_a1 | median_obs | 21 | 5.53 | 0.089 | 60 | -9.34 | <0.001 |
| test | km_median | const_30 | 21 | -11.46 | <0.001 | 60 | 1.92 | 0.375 |
| test | km_median | last_episode | 21 | 0.36 | 0.926 | 60 | -11.25 | <0.001 |
| test | km_median | median_obs | 21 | 2.06 | 0.192 | 60 | -8.70 | <0.001 |
| test | ridge_tg_a1 | const_30 | 21 | -10.30 | 0.003 | 60 | 10.84 | <0.001 |
| test | ridge_tg_a1 | km_median | 21 | 1.16 | 0.708 | 60 | 8.93 | <0.001 |
| test | ridge_tg_a1 | last_episode | 21 | 1.53 | 1.000 | 60 | -2.33 | 0.001 |
| test | ridge_tg_a1 | median_obs | 21 | 3.22 | 0.566 | 60 | 0.23 | 0.659 |
| test | ridge_tg_a1 | ridge_attack_a1 | 21 | 2.97 | 1.000 | 60 | -0.26 | 0.236 |

### Reading of the restoration results

* **Observed strikes (MAE in days, test, n=21).** The median of past observed durations is the best simple predictor (6.45 d); `last_episode` 8.1 d; Kaplan-Meier median 8.5 d; the two chosen designs are worse (`ridge_tg_a1` 9.7 d, `aft_tg_a1` 12.0 d). No model is significantly better than a baseline on observed strikes; the only significant differences are against `const_30`, which is not a forecast.
* **Lower-bound MAE on all strikes (test, n=60).** The AFT models beat `median_obs` and `last_episode` (p<0.001), but this is a censoring effect: they predict long regimes (mean prediction about 22 days against 6 days for `median_obs`), and `const_30` (always 30 days) scores 6.99 d, better than every model (best model 7.2 d, `aft_attack_a1` 7.6 d, chosen `aft_tg_a1` 8.3 d). The lower bound alone therefore shows no skill; together with the observed-strike MAE the AFT trades one error for the other. `ridge_tg_a1` is worse than `km_median` here (p<0.001).
* **Ranking (C-index, test).** 0.59 for the chosen AFT, 0.45 for the chosen ridge, 0.61 for `aft_attack_a1` and for the Kaplan-Meier median (a time-varying constant: it only follows the drift towards longer winter regimes). Weak at best, and not better with Telegram features.
* **Do the Telegram features help?** Compared with the same model on attack features only (same penalty): AFT test observed-strike error -0.35 d (p=0.81), lower bound +0.65 d (p=0.78); ridge test +2.97 d (p=1.0) and -0.26 d (p=0.24). On validation the AFT with Telegram features was better on the lower bound (-5.0 d, p=0.064) and not on test, so there is no stable effect. `aft_tg_all_a1` (all channels pooled) has the best test C (0.66) and the best test lower bound among the AFT models, but was among the worst on validation (C 0.37) and was not chosen; reading it as a result would be selection on test.
* **Honest conclusion.** With 21 observed test durations, chains of dependent strikes, and 44 of 77 labels censored, the data cannot show that the duration of the restriction regime is forecastable at the end of the strike day, with or without Telegram severity features. The reporting-friendly statements are: (a) the median past duration (about 6.5 days, `reports/telegram_extraction_quality.md`) is the baseline to beat; (b) censoring-aware models give a longer, more cautious forecast and do not improve ranking; (c) change-point-triggered retraining plays no role here (this target does not use `xgb_adaptive`), and `xgb_rolling` is shown in section 2 as the ablation.

## 4. Caveats

* **Informative censoring.** 9 of the 44 censored strikes had at most 5 days of restriction posts and no lifting post (2022-02-24, 2022-09-11, 2025-03-07, 2025-09-08, 2026-04-16, 2026-05-01, 2026-05-14, 2026-06-02, 2026-06-15): the regime most likely ended without an announcement that the extractor recognises, so "censored" there probably means "short", not "long". The lower-bound metric then penalises the correct short forecasts for these strikes, and the AFT is trained to treat them as long. The extraction recall for lifting posts is only anecdotal (3 gold positives, `reports/telegram_extraction_quality.md`).
* **Chains.** The label of a strike inside a chain is the time remaining to the shared lifting post. The `gap_prev` and `regime` features try to capture this; nothing beats the baselines.
* **Coverage and non-stationarity.** Ukrenergo lifting statements are frequent in 2022-2024 and rare in 2025-2026 (`reports/telegram_extraction_quality.md`, coverage table), which changes what "observed" means over time; the 2025-26 strikes are mostly censored.
* **Depth/duration tables.** Telegram features exist only from 2022-02 (NaN before; trees route NaN, the ridge imputes the median), so the Telegram models train on few covered rows early in the validation period. This may explain the validation deficit and the test gain, but it was not tested and is not a result.
* **Multiple testing.** About 60 p-values in section 2 and about 50 in section 3 without correction; strikes and events overlap.
* The extract used for this analysis was made while the Energoatom collector was still running; `deficit extract` was not re-run (the national channel used here does not depend on it). Re-running it later changes the Energoatom rows only.
* Day-ahead features were not changed, so `seasonal_naive` / `xgb_rolling` hourly results are unaffected.
