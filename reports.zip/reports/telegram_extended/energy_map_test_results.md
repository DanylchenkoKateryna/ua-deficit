# Energy Map: final test (protocol `docs/preregistration_energy_map.md`)

Model chosen in development (`energy_map_chosen_for_test.md`): `ridge_strike_oblast_a100`. Comparison: `oblast_median`, `global_median`. Training: walk-forward, labels as known at forecast time. Bootstrap over strikes: 2000 resamples, seed 42, paired (strikes are resampled once, both C on the same resample). The test was run once.

## Main metric (cohort: all oblasts)

- Within-strike C, `ridge_strike_oblast_a100`: 0.699 [0.657, 0.742]
- Within-strike C, `oblast_median`: 0.652 [0.605, 0.700]
- Difference C(model) - C(`oblast_median`): 0.0470 [0.0228, 0.0708] (95% paired bootstrap interval); one-sided p (difference <= 0) = 0.0005
- **Success criterion (lower bound of the interval > 0): YES** (lower bound 0.0228)

## C against 0.5 (all oblasts)

| method | within-strike C [95% CI] | p (C > 0.5) |
|---|---|---|
| ridge_strike_oblast_a100 | 0.699 [0.657, 0.742] | 0.0005 |
| oblast_median | 0.652 [0.605, 0.700] | |
| global_median | 0.500 (constant within a strike) | |

Difference C(model) - C(`global_median`): 0.1988 [0.1573, 0.2416].

## Additional metrics (no conclusions about success)

### 1. Rear: without Donetsk, Luhansk, Zaporizhzhia, Kherson

Test table without these oblasts; training (including `oblast_median`) is also without them, as in the development mode.

- C `ridge_strike_oblast_a100`: 0.640 [0.587, 0.692]; p (C > 0.5) = 0.0005
- C `oblast_median`: 0.617 [0.562, 0.672]
- Difference: 0.0231 [0.0000, 0.0466]; p (difference <= 0) = 0.0330
- Strikes 243, pairs scored 501 (292 observed), comparable within-strike pairs 346.

### 2. MAE on observed episodes against `global_median`

| cohort | observed | MAE model, h | MAE oblast_median, h | MAE global_median, h | mean difference over strikes (model - global), h | share of better strikes | Wilcoxon p (over strikes) |
|---|---|---|---|---|---|---|---|
| all oblasts | 423 | 109.7 | 108.8 | 120.2 | -7.6 | 0.67 | 0.0000 |
| rear | 292 | 131.2 | 133.3 | 139.7 | -6.6 | 0.59 | 0.0011 |

### 3. C against 0.5

See the table above (all oblasts) and item 1 (rear).

## Counts

- Test pairs (strike x oblast) in the table: 641 (423 observed) in 256 strikes.
- Scored by the model (needs >= 30 observed past episodes): 641 pairs, 423 of them observed, in 256 strikes; comparable within-strike pairs (denominator of C): 596.
- Forecasts and labels: `energy_map_test_predictions.csv`.

## Limitations (from the protocol)

- The label is the first restoration report, not full restoration; the records are events, not a continuous series.
- Episodes of the same strike are dependent; intervals are computed over strikes. A large part of C comes from differences between oblasts, so the criterion is an advantage over `oblast_median`.
