# Energy Map labels for the oblast restoration forecast: DEV report (test period blind)

Source: Energy Map / DiXi Group, https://energy-map.info (free account; files `*_oblasti_osr.csv` = regional administrations and DSOs, `*_oblasti_minenergo.csv` = Ministry of Energy). These are human-curated event records, not a continuous series: a missing record means 'not reported', not 'no outage'.

Label (see `energy_map_labels.py`): a (strike, oblast) pair is labelled iff a blackout is reported on the strike day or the day after; restoration = first later record with restored consumers/settlements within 30 days (observed) else censored. Period records (number_days > 1) are ignored. The notes never contain an 'all restored' statement, so the label is the FIRST RESTORATION REPORT (possibly partial), a different quantity from the Telegram label (schedules lifted / all consumers have power). Time resolution is one day. The cohort is defined by the reported blackout (label side), so results are conditional on it.

Splits decided BEFORE looking at any model result: all oblasts, and excluding the front-line oblasts Donetsk, Luhansk, Zaporizhzhia, Kherson (their records are dominated by daily shelling outages). Both are reported whatever the outcome. No model metric for strikes from 2025-01-01 is computed; below the 2025+ numbers are label counts only.

Records loaded: 8353 (4806 osr, 3547 minenergo); 948 period records ignored; with blackout 5783, with restoration 4055.

## 1. Coverage (counts only)

Strikes: 890; (strike x oblast) pairs with an Energy Map label: 3097 (2402 observed, 695 censored). 1434 pairs also have a restoration record on the first blackout day (not used as restoration). `em_*` = Energy Map, `tg_*` = Telegram pairs with status observed/censored (30 d window) on the same grid.

### By year

| year | em_pairs | em_observed | tg_pairs | tg_observed |
|---|---|---|---|---|
| 2022 | 230 | 148 | 1052 | 654 |
| 2023 | 840 | 696 | 2619 | 2141 |
| 2024 | 1386 | 1135 | 3566 | 2821 |
| 2025 | 369 | 259 | 2176 | 776 |
| 2026 | 272 | 164 | 2949 | 1343 |

### By region group (front-line = Donetsk, Luhansk, Zaporizhzhia, Kherson; rear = other 20)

| group | em_pairs | em_observed | tg_pairs | tg_observed |
|---|---|---|---|---|
| frontline | 1290 | 1267 | 1916 | 1234 |
| rear | 1807 | 1135 | 10446 | 6501 |

### By strike type (air_force = Air Force list, derived = from attack-report posts)

| type | em_pairs | em_observed | tg_pairs | tg_observed |
|---|---|---|---|---|
| air_force | 274 | 183 | 1219 | 683 |
| derived | 2823 | 2219 | 11143 | 7052 |

### Year x group

| year | group | em_pairs | em_observed | tg_pairs | tg_observed |
|---|---|---|---|---|---|
| 2022 | frontline | 115 | 104 | 158 | 92 |
| 2022 | rear | 115 | 44 | 894 | 562 |
| 2023 | frontline | 486 | 486 | 481 | 447 |
| 2023 | rear | 354 | 210 | 2138 | 1694 |
| 2024 | frontline | 549 | 546 | 583 | 413 |
| 2024 | rear | 837 | 589 | 2983 | 2408 |
| 2025 | frontline | 76 | 69 | 343 | 108 |
| 2025 | rear | 293 | 190 | 1833 | 668 |
| 2026 | frontline | 64 | 62 | 351 | 174 |
| 2026 | rear | 208 | 102 | 2598 | 1169 |

### Year x strike type

| year | type | em_pairs | em_observed | tg_pairs | tg_observed |
|---|---|---|---|---|---|
| 2022 | air_force | 43 | 23 | 213 | 155 |
| 2022 | derived | 187 | 125 | 839 | 499 |
| 2023 | air_force | 13 | 9 | 81 | 76 |
| 2023 | derived | 827 | 687 | 2538 | 2065 |
| 2024 | air_force | 93 | 70 | 230 | 174 |
| 2024 | derived | 1293 | 1065 | 3336 | 2647 |
| 2025 | air_force | 65 | 48 | 363 | 137 |
| 2025 | derived | 304 | 211 | 1813 | 639 |
| 2026 | air_force | 60 | 33 | 332 | 141 |
| 2026 | derived | 212 | 131 | 2617 | 1202 |

### By oblast

| oblast | em_pairs | em_observed | tg_pairs | tg_observed | group |
|---|---|---|---|---|---|
| Cherkasy | 9 | 0 | 221 | 119 | rear |
| Chernihiv | 393 | 102 | 494 | 186 | rear |
| Chernivtsi | 2 | 0 | 241 | 164 | rear |
| Dnipropetrovsk | 315 | 311 | 798 | 540 | rear |
| Donetsk | 385 | 383 | 622 | 394 | frontline |
| Ivano-Frankivsk | 7 | 0 | 97 | 66 | rear |
| Kharkiv | 290 | 270 | 817 | 606 | rear |
| Kherson | 311 | 301 | 567 | 393 | frontline |
| Khmelnytskyi | 8 | 0 | 714 | 487 | rear |
| Kirovohrad | 15 | 4 | 578 | 349 | rear |
| Kyiv | 73 | 45 | 806 | 601 | rear |
| Kyiv_city | 37 | 23 | 663 | 514 | rear |
| Luhansk | 16 | 7 | 0 | 0 | frontline |
| Lviv | 15 | 2 | 566 | 311 | rear |
| Mykolaiv | 215 | 73 | 177 | 98 | rear |
| Odesa | 122 | 98 | 800 | 520 | rear |
| Poltava | 23 | 2 | 634 | 346 | rear |
| Rivne | 8 | 2 | 81 | 61 | rear |
| Sumy | 240 | 198 | 784 | 430 | rear |
| Ternopil | 3 | 0 | 440 | 219 | rear |
| Vinnytsia | 19 | 3 | 500 | 231 | rear |
| Volyn | 6 | 0 | 270 | 128 | rear |
| Zakarpattia | 0 | 0 | 119 | 65 | rear |
| Zaporizhzhia | 578 | 576 | 727 | 447 | frontline |
| Zhytomyr | 7 | 2 | 646 | 460 | rear |

Dev period (strikes up to 2024-12-31): 2456 labelled pairs, 1979 observed (1136 front-line, 843 rear). Threshold for running the CV: >= 150 observed.

## 2. Comparison with the Telegram labels (dev period, overlapping pairs)

Dev pairs: Energy Map 2456, Telegram (observed/censored) 7237, overlap 1818.

Observed/censored agreement: 71.7% (Cohen kappa 0.101). Rows Energy Map, columns Telegram:

| EM \ TG | observed | censored |
|---|---|---|
| observed | 1218 | 374 |
| censored | 140 | 86 |

Both observed: 1218 pairs; Spearman of durations 0.012, Pearson of log durations 0.022; median duration Energy Map 52 h vs Telegram 276 h.

- frontline: 859 overlapping pairs, agreement 74.6%, both observed 640, Spearman 0.027
- rear: 959 overlapping pairs, agreement 69.1%, both observed 578, Spearman 0.065

## 3. Dev CV with the Energy Map target

Rolling-origin CV exactly as `region_dev.dev_cv` (expanding window over strikes, K = 5, warm-up `region_dev_min_obs`, 1-SE rule on MAE, mean C within strike as primary metric, MAE paired against `global_median`). Window 30 d only (the next-strike variant is almost all censored here). Features are the same Telegram/strike/oblast/history features as in the Telegram runs; only the label (and the cohort) differs.

### all oblasts

Dev pairs 2456 (1979 observed); strikes scored 511 of 517 (2022-05-04 .. 2024-12-31). Folds: 103 strikes / 186 observed; 102 strikes / 244 observed; 102 strikes / 470 observed; 102 strikes / 648 observed; 102 strikes / 412 observed

Best CV MAE `ridge_strike_oblast_a1` 54.6 h (SE 7.1); 1-SE selected `global_median` (58.4 h).

Primary metric: mean C within strike over folds (SE over folds). Top 6 by C plus baselines:

| design | MAE_cv h | SE | LB_cv h | C_within | C_all | diff vs global_median h | better strikes | p per strike |
|---|---|---|---|---|---|---|---|---|
| aft_strike_oblast_a1 | 75.9 | 11.0 | 93.2 | 0.795 | 0.725 | 15.6 | 0.38 | 0.000 |
| aft_full_a1 | 79.2 | 7.5 | 90.2 | 0.794 | 0.731 | 18.7 | 0.40 | 0.000 |
| aft_full_a10 | 75.7 | 6.6 | 105.1 | 0.794 | 0.728 | 16.0 | 0.41 | 0.000 |
| aft_strike_oblast_early_a10 | 75.5 | 7.2 | 110.5 | 0.794 | 0.728 | 15.6 | 0.38 | 0.000 |
| aft_strike_oblast_a10 | 73.9 | 8.2 | 114.0 | 0.794 | 0.717 | 14.3 | 0.36 | 0.000 |
| aft_strike_oblast_early_a1 | 77.7 | 9.9 | 93.6 | 0.789 | 0.733 | 16.9 | 0.38 | 0.000 |
| global_median | 58.4 | 7.8 | 194.7 | 0.500 | 0.490 |  |  |  |
| oblast_median | 55.4 | 7.3 | 169.4 | 0.758 | 0.679 | -2.3 | 0.54 | 0.008 |
| geo_mean | 58.9 | 7.9 | 193.7 | 0.500 | 0.490 | 0.6 | 0.41 | 0.005 |
| km_global | 61.4 | 7.6 | 191.3 | 0.500 | 0.488 | 3.2 | 0.36 | 0.000 |
| const_30d | 629.5 | 9.2 | 496.6 | 0.500 | 0.500 | 574.6 | 0.00 | 0.000 |

Bootstrap over strikes (dev, descriptive; p-values not corrected for the choice among designs):

| design | C_within [95% CI] | p (C>0.5) |
|---|---|---|
| aft_full_a1 | 0.811 [0.797, 0.824] | 0.001 |
| aft_strike_oblast_a1 | 0.807 [0.794, 0.821] | 0.001 |
| aft_full_a10 | 0.804 [0.791, 0.817] | 0.001 |
| oblast_median | 0.769 [0.753, 0.785] | 0.001 |
| global_median | 0.500 [0.500, 0.500] | 1.000 |

### excluding front-line (Donetsk, Luhansk, Zaporizhzhia, Kherson)

Dev pairs 1306 (843 observed); strikes scored 450 of 459 (2022-07-19 .. 2024-12-31). Folds: 90 strikes / 28 observed; 90 strikes / 73 observed; 90 strikes / 237 observed; 90 strikes / 316 observed; 90 strikes / 173 observed

Best CV MAE `ens_best` 77.6 h (SE 14.1); 1-SE selected `global_median` (83.7 h).

Primary metric: mean C within strike over folds (SE over folds). Top 6 by C plus baselines:

| design | MAE_cv h | SE | LB_cv h | C_within | C_all | diff vs global_median h | better strikes | p per strike |
|---|---|---|---|---|---|---|---|---|
| xgbaft_strike_oblast_hist_d2n60 | 119.6 | 18.6 | 132.3 | 0.823 | 0.776 | 33.5 | 0.39 | 0.000 |
| xgbaft_strike_oblast_hist_early_d2n60 | 118.6 | 19.0 | 131.6 | 0.819 | 0.779 | 33.0 | 0.39 | 0.000 |
| aft_strike_oblast_hist_early_a1 | 128.0 | 20.7 | 131.2 | 0.814 | 0.771 | 40.1 | 0.41 | 0.000 |
| ipcw_strike_oblast_a1 | 77.9 | 14.2 | 310.5 | 0.811 | 0.649 | -6.9 | 0.62 | 0.001 |
| ens_best | 77.6 | 14.1 | 323.8 | 0.811 | 0.629 | -6.8 | 0.66 | 0.000 |
| ridge_strike_oblast_a1 | 77.7 | 14.2 | 311.3 | 0.811 | 0.650 | -7.0 | 0.62 | 0.000 |
| global_median | 83.7 | 14.9 | 345.1 | 0.500 | 0.423 |  |  |  |
| oblast_median | 80.1 | 16.3 | 302.5 | 0.740 | 0.655 | -4.9 | 0.53 | 0.035 |
| geo_mean | 83.3 | 14.9 | 342.2 | 0.500 | 0.424 | 0.1 | 0.44 | 0.196 |
| km_global | 303.6 | 88.1 | 287.3 | 0.500 | 0.525 | 217.3 | 0.14 | 0.000 |
| const_30d | 598.6 | 17.7 | 342.1 | 0.500 | 0.500 | 498.7 | 0.03 | 0.000 |

Bootstrap over strikes (dev, descriptive; p-values not corrected for the choice among designs):

| design | C_within [95% CI] | p (C>0.5) |
|---|---|---|
| xgbaft_strike_oblast_hist_early_d2n60 | 0.840 [0.821, 0.859] | 0.001 |
| xgbaft_strike_oblast_hist_d2n60 | 0.839 [0.821, 0.859] | 0.001 |
| aft_strike_oblast_hist_early_a1 | 0.832 [0.811, 0.852] | 0.001 |
| oblast_median | 0.785 [0.761, 0.808] | 0.001 |
| global_median | 0.500 [0.500, 0.500] | 1.000 |
