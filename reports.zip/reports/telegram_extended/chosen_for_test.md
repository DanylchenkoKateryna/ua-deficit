# Chosen for the single test run (DEV only, nothing from the test period was computed)

Written 2026-11-02, before any `region-restoration` run in normal mode. Data: `config/telegram_extended.yaml`
(890 strikes from `attacks_extended.csv`, new extraction rules), dev report `reports/telegram_extended/telegram_region_dev.md`.

## Rule (docs/preregistration_region.md, "Model selection")

> Candidates: all regression variants of the development mode (ridge, ipcw, aft, xgbaft, ensembles); baselines are shown but are not selected as a "model with ranking skill".
> Criterion: mean within-strike C over 5 consecutive folds (`region_cv_folds`, warm-up `region_dev_min_obs = 15`), 30-day window. One-standard-error rule: among the variants no worse than the best by more than one SE, the simplest is taken (`complexity_key` in `region_dev.py`).
> The choice is written to a file before the test is run; exactly one model is evaluated on the test.

## Selection

- Window: **30d** (primary).
- Best by mean C within strike: `aft_strike_oblast_hist_a100`, C = 0.576 (SE 0.019); threshold 0.557.
- Only one other design is within 1 SE (`xgbaft_strike_oblast_hist_early_d2n60`, C = 0.562, SE 0.017); it is more complex.
- **Chosen model: `aft_strike_oblast_hist_a100`, window 30d.**

Reference (dev, 30d): `oblast_median` C = 0.510 (SE 0.028), `global_median` = 0.5.
Caveat: dev MAE of the chosen model is 239 h vs 172 h for `global_median` (it ranks, it does not predict level well).
The MAE-based 1-SE rule (secondary metric) selects `geo_mean` (MAE 167.1 h) for 30d and `geo_mean` for `next_strike`.
Note the 74 designs were not corrected for multiple comparison.
