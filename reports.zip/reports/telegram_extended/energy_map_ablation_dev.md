# Energy Map restoration forecast: ablation of features and training strikes (DEV; CV over ALL strikes up to 2026-06-26)

Question: which data are redundant or harmful? Same label, cohort, walk-forward, 8 expanding folds, scored pairs and metrics as `energy_map_improve_dev.md` (the frozen test is spent, the whole period is development data; the blind test of `docs/preregistration_energy_map_v2_draft.md` is untouched). Dev pairs 3097 (2402 observed) in 773 strikes; scored 767 strikes (2022-05-04 .. 2026-06-26); folds (strikes / pairs / observed): 96 / 288 / 173; 96 / 265 / 210; 96 / 472 / 421; 96 / 704 / 596; 96 / 636 / 524; 96 / 265 / 171; 96 / 252 / 182; 95 / 196 / 106.

Cells: C = Harrell's C within strike, MAE h on observed episodes, mean over folds (SE over folds). Paired columns: difference (reduced design - full design) per fold, mean (SE), folds where the reduced design is BETTER (dC > 0, dMAE < 0); pooled paired bootstrap over strikes (2000 resamples, seed 42) with 95% CI. Rule fixed in the code: removal is 'KEEP' only if the CI shows a worse C (upper bound < 0) or a worse MAE (lower bound > 0); otherwise 'REMOVE' (an improvement is flagged when a CI is entirely on the better side). 'Safe to remove' is therefore 'not provably worse', not 'proven useless'.

Notes: the columns of `so` contain only `log_through, gap_prev, n_strikes_30, heating, temp_24h` and the oblast dummies; no `sev_`/`act_`/`early_` feature is in any of the designs, so group (a) is exactly these five. For `ridge_so_em` / `xgbaft_so_em` the groups HIST_F, GEO_F, CTX_F are not part of the design (not ablated). Alerts and weather are not part of the reference designs: rows `+ alerts` / `+ weather` ADD them (the sets of `energy_map_alerts_weather_dev.md`), so the sign of the effect is that of adding. Features: strike-level `log_through, gap_prev, n_strikes_30, heating, temp_24h`; EM_F record density/history; HIST_F Telegram history; GEO_F front/tier/border; CTX_F `is_af`, sin/cos day of year.

## 1. Feature-group ablation

### ipcw_so_all_a100

| design | n features | C_cv (SE) | MAE_cv h (SE) | dC vs full (SE), folds better | dMAE vs full h (SE), folds better | pooled dC [95% CI] | pooled dMAE h [95% CI] | verdict |
|---|---|---|---|---|---|---|---|---|
| full | 52 | 0.806 (0.015) | 68.1 (8.8) | (reference) | | | | |
| - telegram_strike | 47 | 0.805 (0.016) | 68.0 (8.8) | -0.0012 (0.0018), 2/8 | -0.1 (0.3), 4/8 | -0.0024 [-0.0054, +0.0007] | -0.2 [-0.5, +0.1] | REMOVE (no difference) |
| - oblast_dummies | 27 | 0.806 (0.014) | 68.2 (8.8) | -0.0003 (0.0020), 2/8 | +0.0 (0.3), 3/8 | -0.0028 [-0.0073, +0.0016] | +0.2 [-0.1, +0.5] | REMOVE (no difference) |
| - EM_F | 42 | 0.729 (0.018) | 72.7 (9.8) | -0.0770 (0.0199), 0/8 | +4.6 (1.3), 0/8 | -0.0553 [-0.0660, -0.0442] | +4.2 [+3.0, +5.4] | KEEP (C worse, MAE worse) |
| - HIST_F | 46 | 0.812 (0.017) | 68.6 (9.0) | +0.0054 (0.0064), 3/8 | +0.5 (0.3), 1/8 | +0.0007 [-0.0044, +0.0058] | +0.2 [-0.2, +0.6] | REMOVE (no difference) |
| - GEO_F | 49 | 0.805 (0.016) | 68.2 (8.8) | -0.0010 (0.0020), 5/8 | +0.0 (0.1), 4/8 | +0.0009 [-0.0014, +0.0031] | -0.0 [-0.2, +0.1] | REMOVE (no difference) |
| - CTX_F | 49 | 0.807 (0.015) | 68.1 (8.7) | +0.0006 (0.0009), 3/8 | -0.0 (0.1), 4/8 | +0.0007 [-0.0005, +0.0018] | +0.0 [-0.2, +0.2] | REMOVE (no difference) |
| + alerts | 56 | 0.807 (0.015) | 68.3 (8.8) | +0.0008 (0.0036), 5/8 | +0.1 (0.1), 2/8 | +0.0024 [-0.0027, +0.0075] | -0.0 [-0.3, +0.2] | REMOVE (no difference) |
| + weather | 60 | 0.806 (0.015) | 68.3 (8.7) | -0.0003 (0.0020), 2/8 | +0.2 (0.1), 2/8 | -0.0003 [-0.0033, +0.0024] | +0.2 [-0.1, +0.4] | REMOVE (no difference) |
| minimal (dummies + EM_F) | 35 | 0.809 (0.019) | 68.4 (9.1) | +0.0031 (0.0075), 5/8 | +0.3 (0.5), 3/8 | +0.0035 [-0.0022, +0.0091] | -0.0 [-0.5, +0.5] | REMOVE (no difference) |

### ridge_so_em_a100

| design | n features | C_cv (SE) | MAE_cv h (SE) | dC vs full (SE), folds better | dMAE vs full h (SE), folds better | pooled dC [95% CI] | pooled dMAE h [95% CI] | verdict |
|---|---|---|---|---|---|---|---|---|
| full | 40 | 0.808 (0.019) | 68.8 (9.1) | (reference) | | | | |
| - telegram_strike | 35 | 0.808 (0.018) | 68.5 (9.1) | -0.0005 (0.0027), 3/8 | -0.3 (0.4), 3/8 | +0.0012 [-0.0021, +0.0043] | -0.3 [-0.6, -0.0] | REMOVE (better: MAE) |
| - oblast_dummies | 15 | 0.807 (0.015) | 68.8 (9.1) | -0.0013 (0.0067), 3/8 | +0.0 (0.3), 4/8 | -0.0017 [-0.0070, +0.0033] | +0.2 [-0.1, +0.5] | REMOVE (no difference) |
| - EM_F | 30 | 0.741 (0.026) | 75.2 (10.1) | -0.0679 (0.0203), 1/8 | +6.4 (1.4), 0/8 | -0.0580 [-0.0689, -0.0470] | +6.1 [+4.7, +7.5] | KEEP (C worse, MAE worse) |
| + alerts | 44 | 0.811 (0.020) | 69.0 (9.2) | +0.0028 (0.0071), 5/8 | +0.3 (0.2), 2/8 | +0.0040 [-0.0005, +0.0085] | +0.1 [-0.1, +0.3] | REMOVE (no difference) |
| + weather | 48 | 0.807 (0.019) | 68.9 (9.1) | -0.0013 (0.0032), 4/8 | +0.1 (0.1), 3/8 | -0.0014 [-0.0049, +0.0018] | +0.1 [-0.1, +0.4] | REMOVE (no difference) |
| minimal (dummies + EM_F) | 35 | 0.808 (0.018) | 68.5 (9.1) | -0.0005 (0.0027), 3/8 | -0.3 (0.4), 3/8 | +0.0012 [-0.0021, +0.0043] | -0.3 [-0.6, -0.0] | REMOVE (better: MAE) |

### xgbaft_so_em_d2n25

| design | n features | C_cv (SE) | MAE_cv h (SE) | dC vs full (SE), folds better | dMAE vs full h (SE), folds better | pooled dC [95% CI] | pooled dMAE h [95% CI] | verdict |
|---|---|---|---|---|---|---|---|---|
| full | 40 | 0.813 (0.013) | 76.5 (9.7) | (reference) | | | | |
| - telegram_strike | 35 | 0.813 (0.013) | 76.5 (9.7) | -0.0006 (0.0009), 1/8 | -0.0 (0.1), 5/8 | -0.0010 [-0.0030, +0.0007] | -0.0 [-0.2, +0.1] | REMOVE (no difference) |
| - oblast_dummies | 15 | 0.805 (0.013) | 77.5 (10.0) | -0.0083 (0.0051), 2/8 | +1.0 (0.6), 3/8 | -0.0053 [-0.0107, -0.0001] | +0.8 [-0.0, +1.6] | KEEP (C worse) |
| - EM_F | 30 | 0.761 (0.020) | 76.3 (10.2) | -0.0522 (0.0140), 0/8 | -0.2 (2.2), 4/8 | -0.0407 [-0.0517, -0.0289] | +0.3 [-3.1, +3.7] | KEEP (C worse) |
| + alerts | 44 | 0.813 (0.013) | 76.4 (9.7) | -0.0009 (0.0013), 1/8 | -0.0 (0.1), 5/8 | -0.0008 [-0.0033, +0.0018] | -0.1 [-0.3, +0.1] | REMOVE (no difference) |
| + weather | 48 | 0.813 (0.014) | 76.3 (9.6) | -0.0003 (0.0015), 3/8 | -0.2 (0.2), 7/8 | -0.0008 [-0.0035, +0.0021] | -0.0 [-0.5, +0.4] | REMOVE (no difference) |
| minimal (dummies + EM_F) | 35 | 0.813 (0.013) | 76.5 (9.7) | -0.0006 (0.0009), 1/8 | -0.0 (0.1), 5/8 | -0.0010 [-0.0030, +0.0007] | -0.0 [-0.2, +0.1] | REMOVE (no difference) |

## 2. Strike-subset ablation (training set only changes; evaluation on the same pairs)

Regimes: (i) all strikes (current); (ii) Air Force + derived with n_channels >= 2; (iii) Air Force only. Scored strikes 767 (Air Force strikes among them: 72; 73 Air Force strikes and 323 strikes with Air Force or n_channels >= 2 in the whole list). A strike is scored only if the UNFILTERED training set has >= 15 observed episodes (as before); a regime whose filtered training set has < 5 observed episodes gives no forecast, and such strikes are dropped for ALL regimes: the comparison uses the 758 strikes where every regime forecasts. **`n_channels` is a whole-day count (known only after the day):** it filters the PAST training strikes (their day is over before the issue time of the strike being forecast; labels evaluated later) and is never a feature nor used to select evaluated strikes. Paired against regime (i) with the same design.

### Evaluation on: all pairs

| design | training set | strikes / observed evaluated | C_cv (SE) | MAE_cv h (SE) | dC vs (i) (SE), folds better | dMAE vs (i) h (SE), folds better | pooled dC [95% CI] | pooled dMAE h [95% CI] | verdict |
|---|---|---|---|---|---|---|---|---|---|
| ipcw_so_all_a100 | (i) all | 758 / 2339 | 0.810 (0.016) | 68.4 (8.7) | (reference) | | | | |
| ipcw_so_all_a100 | (ii) AF + ch>=2 | 758 / 2339 | 0.797 (0.013) | 69.2 (8.5) | -0.0125 (0.0156), 2/8 | +0.8 (0.3), 1/8 | -0.0081 [-0.0145, -0.0019] | +0.9 [+0.4, +1.5] | KEEP (C worse, MAE worse) |
| ipcw_so_all_a100 | (iii) AF only | 758 / 2339 | 0.721 (0.044) | 73.3 (8.7) | -0.0886 (0.0385), 3/8 | +4.9 (1.3), 1/8 | -0.1304 [-0.1523, -0.1079] | +6.3 [+5.1, +7.5] | KEEP (C worse, MAE worse) |
| ridge_so_em_a100 | (i) all | 758 / 2339 | 0.815 (0.022) | 69.1 (9.0) | (reference) | | | | |
| ridge_so_em_a100 | (ii) AF + ch>=2 | 758 / 2339 | 0.773 (0.034) | 69.6 (8.7) | -0.0419 (0.0440), 2/8 | +0.5 (0.6), 2/8 | -0.0183 [-0.0250, -0.0114] | +0.6 [+0.1, +1.1] | KEEP (C worse, MAE worse) |
| ridge_so_em_a100 | (iii) AF only | 758 / 2339 | 0.725 (0.042) | 72.5 (8.8) | -0.0899 (0.0429), 1/8 | +3.4 (0.8), 1/8 | -0.0998 [-0.1192, -0.0812] | +4.4 [+3.5, +5.4] | KEEP (C worse, MAE worse) |
| xgbaft_so_em_d2n25 | (i) all | 758 / 2339 | 0.823 (0.018) | 76.9 (9.7) | (reference) | | | | |
| xgbaft_so_em_d2n25 | (ii) AF + ch>=2 | 758 / 2339 | 0.807 (0.012) | 72.0 (9.7) | -0.0155 (0.0111), 3/8 | -4.9 (1.6), 7/8 | -0.0090 [-0.0160, -0.0020] | -5.0 [-6.6, -3.4] | KEEP (C worse) |
| xgbaft_so_em_d2n25 | (iii) AF only | 758 / 2339 | 0.804 (0.017) | 70.9 (9.0) | -0.0193 (0.0158), 2/8 | -6.0 (2.1), 7/8 | -0.0276 [-0.0384, -0.0169] | -6.3 [-9.2, -3.3] | KEEP (C worse) |

### Evaluation on: Air Force strikes only

| design | training set | strikes / observed evaluated | C_cv (SE) | MAE_cv h (SE) | dC vs (i) (SE), folds better | dMAE vs (i) h (SE), folds better | pooled dC [95% CI] | pooled dMAE h [95% CI] | verdict |
|---|---|---|---|---|---|---|---|---|---|
| ipcw_so_all_a100 | (i) all | 71 / 175 | 0.798 (0.051) | 77.9 (13.2) | (reference) | | | | |
| ipcw_so_all_a100 | (ii) AF + ch>=2 | 71 / 175 | 0.780 (0.036) | 79.2 (13.2) | -0.0182 (0.0480), 1/7 | +1.3 (0.9), 1/7 | -0.0321 [-0.0707, -0.0039] | +1.9 [-0.4, +4.3] | KEEP (C worse) |
| ipcw_so_all_a100 | (iii) AF only | 71 / 175 | 0.735 (0.074) | 83.4 (14.5) | -0.0627 (0.0405), 3/7 | +5.5 (2.1), 1/7 | -0.0513 [-0.1187, -0.0016] | +8.3 [+4.5, +12.3] | KEEP (C worse, MAE worse) |
| ridge_so_em_a100 | (i) all | 71 / 175 | 0.810 (0.055) | 79.4 (14.0) | (reference) | | | | |
| ridge_so_em_a100 | (ii) AF + ch>=2 | 71 / 175 | 0.746 (0.063) | 79.3 (13.6) | -0.0636 (0.0639), 1/7 | -0.2 (1.5), 3/7 | -0.0449 [-0.0944, -0.0094] | +0.6 [-2.1, +3.0] | KEEP (C worse) |
| ridge_so_em_a100 | (iii) AF only | 71 / 175 | 0.723 (0.081) | 83.6 (14.5) | -0.0874 (0.0624), 2/7 | +4.2 (2.0), 1/7 | -0.0684 [-0.1377, -0.0143] | +6.1 [+2.4, +9.7] | KEEP (C worse, MAE worse) |
| xgbaft_so_em_d2n25 | (i) all | 71 / 175 | 0.823 (0.023) | 84.9 (13.9) | (reference) | | | | |
| xgbaft_so_em_d2n25 | (ii) AF + ch>=2 | 71 / 175 | 0.785 (0.026) | 82.6 (13.2) | -0.0381 (0.0314), 4/7 | -2.3 (3.5), 3/7 | -0.0171 [-0.0541, +0.0095] | -2.1 [-8.0, +3.6] | REMOVE (no difference) |
| xgbaft_so_em_d2n25 | (iii) AF only | 71 / 175 | 0.820 (0.021) | 81.5 (12.7) | -0.0028 (0.0328), 3/7 | -3.4 (3.4), 4/7 | -0.0053 [-0.0518, +0.0336] | -3.8 [-16.7, +8.9] | REMOVE (no difference) |

## 3. Verdict

**Feature groups** (verdict by the fixed rule, per reference design):

- `ipcw_so_all_a100`: keep EM_F; removable alone (not provably worse): telegram_strike, oblast_dummies, HIST_F, GEO_F, CTX_F; adding alerts: REMOVE (no difference); weather: REMOVE (no difference); minimal model (35 features): C 0.809 vs 0.806, MAE 68.4 vs 68.1, REMOVE (no difference).
- `ridge_so_em_a100`: keep EM_F; removable alone (not provably worse): telegram_strike, oblast_dummies; adding alerts: REMOVE (no difference); weather: REMOVE (no difference); minimal model (35 features): C 0.808 vs 0.808, MAE 68.5 vs 68.8, REMOVE (better: MAE).
- `xgbaft_so_em_d2n25`: keep oblast_dummies, EM_F; removable alone (not provably worse): telegram_strike; adding alerts: REMOVE (no difference); weather: REMOVE (no difference); minimal model (35 features): C 0.813 vs 0.813, MAE 76.5 vs 76.5, REMOVE (no difference).

**Simplest model not worse than the best (1 SE, among all designs of section 1)**: by C the best is `xgbaft_so_em_d2n25` C = 0.8135 (SE 0.0125), 21 designs within one SE; simplest `ridge_so_em_a100__no_oblast_dummies` (15 features) C = 0.8072. By MAE the best is `ipcw_so_all_a100__no_telegram_strike` 68.0 h (SE 8.8), 23 within one SE; simplest `ridge_so_em_a100__no_oblast_dummies` (15 features) 68.8 h.

**Training strikes**:

- evaluated on all pairs, trained on Air Force + derived with n_channels >= 2: ipcw_so_all_a100: KEEP (C worse, MAE worse) (dC -0.013, dMAE +0.8 h); ridge_so_em_a100: KEEP (C worse, MAE worse) (dC -0.042, dMAE +0.5 h); xgbaft_so_em_d2n25: KEEP (C worse) (dC -0.016, dMAE -4.9 h).
- evaluated on all pairs, trained on Air Force only: ipcw_so_all_a100: KEEP (C worse, MAE worse) (dC -0.089, dMAE +4.9 h); ridge_so_em_a100: KEEP (C worse, MAE worse) (dC -0.090, dMAE +3.4 h); xgbaft_so_em_d2n25: KEEP (C worse) (dC -0.019, dMAE -6.0 h).
- evaluated on Air Force strikes only, trained on Air Force + derived with n_channels >= 2: ipcw_so_all_a100: KEEP (C worse) (dC -0.018, dMAE +1.3 h); ridge_so_em_a100: KEEP (C worse) (dC -0.064, dMAE -0.2 h); xgbaft_so_em_d2n25: REMOVE (no difference) (dC -0.038, dMAE -2.3 h).
- evaluated on Air Force strikes only, trained on Air Force only: ipcw_so_all_a100: KEEP (C worse, MAE worse) (dC -0.063, dMAE +5.5 h); ridge_so_em_a100: KEEP (C worse, MAE worse) (dC -0.087, dMAE +4.2 h); xgbaft_so_em_d2n25: REMOVE (no difference) (dC -0.003, dMAE -3.4 h).

## 4. Caveats

- Development numbers only (the whole period is dev); the groups were fixed before the run, but the three reference designs were chosen on the same CV. A pooled CI that includes 0 is weak evidence of redundancy with ~2400 observed episodes; the blind test decides.
- Dropping one group at a time cannot reveal redundancy between two groups that carry the same signal (e.g. EM_F and the oblast dummies): each can be removed alone while removing both would hurt. The 'minimal' row is the joint check.
- The simplest design within one SE (by number of features, then family) is chosen among the designs of section 1 only, with the SE of the best design's fold-mean.
