# Alerts and weather as features of the Energy Map restoration forecast (DEV; rolling-origin CV over ALL strikes up to 2026-06-26)

Same label, cohort, walk-forward, folds and metrics as `energy_map_improve_dev.md` (the frozen test of `docs/preregistration_energy_map.md` is spent; the whole period is development data; the blind test of `docs/preregistration_energy_map_v2_draft.md` is untouched). Only the feature sets differ.

Sources (downloaded 2026-11-09): air-raid alerts, Vadimkin/ukrainian-air-raid-sirens-dataset `official_data_en.csv` (MIT), https://github.com/Vadimkin/ukrainian-air-raid-sirens-dataset; daily weather at the oblast centre, Open-Meteo archive API (CC BY 4.0), https://open-meteo.com.

Dev pairs 3097 (2402 observed) in 773 strikes; scored 767 strikes (2022-05-04 .. 2026-06-26); 8 folds (strikes / pairs / observed): 96 / 288 / 173; 96 / 265 / 210; 96 / 472 / 421; 96 / 704 / 596; 96 / 636 / 524; 96 / 265 / 171; 96 / 252 / 182; 95 / 196 / 106.

## 1. Features (issue time = end of the strike day D, UTC)

- Alerts (`al_*`): union of the intervals of the oblast, its raions and hromadas (no double counting; a hromada alert counts as the oblast being under alert), clipped to the issue time: `al_h_day` hours under alert on D (= 24 x the share of D under alert, so no separate share column), `al_h_prev` on D-1, `al_h_7d` on D-7..D-1, `al_n_day` number of separate alerts starting on D.
- Weather (`w_*`) at the oblast centre: minimum temperature of D and the minimum over D-2..D, frost flags (< -5 C) for both, maximum gust of D and of D-2..D, snowfall of D and the sum over D-2..D. Weather of D is observed by the end of D (acceptable, README 5.1.2). Nothing after D is used (`tests/test_no_leakage.py`).
- Coverage: 299271 alert records (2022-03-15 .. 2026-09-07 starts), weather for 25 oblasts up to 2026-11-07; over the 3097 dev pairs the mean `al_h_day` is 8.7 h (alert on D in 96% of pairs), frost on D in 9%, missing weather 0.0%.
- Designs: the previous best designs `ipcw_so_all_a100` (best MAE), `ridge_so_em_a100`, `xgbaft_so_em_d2n25` (selected by C) and the same with `_al` (+alerts), `_w` (+weather), `_alw` (+both); `ridge_so_alw_a100` = the old `ridge_so_a100` + both. Only 12 designs + 3 references, no tuning of alphas or tree sizes on the new sets. The rows are fixed in advance, so there is no selection among them, but the numbers still come from the same dev CV as the earlier designs.

## 2. CV table (8 folds)

Cells: mean over folds (SE over folds); dC > 0 and dMAE < 0 are better; 'folds better' counts folds. 'vs base' = paired against the design without the new features.

| design | C_cv (SE) | dC vs oblast_median (SE), folds better | MAE_cv h (SE) | dMAE vs oblast_median h (SE), folds better | dC vs base (SE), folds better | dMAE vs base h (SE), folds better |
|---|---|---|---|---|---|---|
| ipcw_so_all_a100 | 0.806 (0.015) | 0.085 (0.022), 8/8 | 68.1 (8.8) | -6.2 (2.0), 8/8 | (base) | (base) |
| ipcw_so_all_al_a100 | 0.806 (0.015) | 0.085 (0.022), 8/8 | 68.3 (8.8) | -6.0 (2.0), 8/8 | 0.000 (0.003), 4/8 | 0.2 (0.1), 2/8 |
| ipcw_so_all_w_a100 | 0.806 (0.016) | 0.084 (0.023), 8/8 | 68.5 (8.7) | -5.9 (2.1), 8/8 | -0.001 (0.003), 4/8 | 0.3 (0.2), 1/8 |
| ipcw_so_all_alw_a100 | 0.805 (0.016) | 0.084 (0.022), 8/8 | 68.6 (8.7) | -5.7 (2.0), 7/8 | -0.001 (0.003), 4/8 | 0.5 (0.2), 2/8 |
| ridge_so_em_a100 | 0.808 (0.019) | 0.087 (0.022), 8/8 | 68.8 (9.1) | -5.6 (1.8), 8/8 | (base) | (base) |
| ridge_so_em_al_a100 | 0.806 (0.017) | 0.085 (0.020), 8/8 | 69.1 (9.2) | -5.2 (1.8), 8/8 | -0.002 (0.005), 6/8 | 0.4 (0.2), 1/8 |
| ridge_so_em_w_a100 | 0.808 (0.019) | 0.087 (0.023), 8/8 | 69.0 (9.0) | -5.3 (1.8), 8/8 | -0.000 (0.005), 4/8 | 0.2 (0.2), 2/8 |
| ridge_so_em_alw_a100 | 0.806 (0.018) | 0.085 (0.022), 8/8 | 69.4 (9.1) | -5.0 (1.8), 7/8 | -0.002 (0.005), 5/8 | 0.6 (0.2), 1/8 |
| xgbaft_so_em_d2n25 | 0.813 (0.013) | 0.092 (0.023), 8/8 | 76.5 (9.7) | 2.1 (3.2), 3/8 | (base) | (base) |
| xgbaft_so_em_al_d2n25 | 0.813 (0.013) | 0.091 (0.023), 8/8 | 76.4 (9.7) | 2.1 (3.2), 4/8 | -0.001 (0.001), 1/8 | -0.0 (0.1), 5/8 |
| xgbaft_so_em_w_d2n25 | 0.813 (0.014) | 0.092 (0.023), 8/8 | 76.3 (9.6) | 2.0 (3.2), 3/8 | -0.000 (0.001), 3/8 | -0.2 (0.2), 7/8 |
| xgbaft_so_em_alw_d2n25 | 0.812 (0.013) | 0.091 (0.023), 8/8 | 76.4 (9.6) | 2.0 (3.2), 3/8 | -0.001 (0.001), 3/8 | -0.1 (0.2), 6/8 |
| ridge_so_alw_a100 | 0.730 (0.026) | 0.008 (0.011), 5/8 | 75.4 (10.4) | 1.0 (1.9), 4/8 | -0.011 (0.015), 3/8 (vs ridge_so_a100) | 0.2 (0.5), 2/8 |
| ridge_so_a100 | 0.741 (0.026) | 0.019 (0.009), 6/8 | 75.2 (10.1) | 0.8 (2.0), 5/8 | (base) | (base) |
| global_median | 0.500 (0.000) | -0.221 (0.030), 0/8 | 79.6 (11.5) | 5.3 (2.7), 1/8 | | |
| oblast_median | 0.721 (0.030) | 0.000 (0.000), 0/8 | 74.3 (10.5) | 0.0 (0.0), 0/8 | | |
| oblast_last10_median | 0.675 (0.033) | -0.046 (0.010), 0/8 | 76.4 (10.7) | 2.1 (0.8), 1/8 | | |

## 3. Ablation: alerts only, weather only, both (the `_al`, `_w`, `_alw` rows above; paired against the base)

| family | suffix | dC vs base (SE) | folds better | pooled-bootstrap dC vs base [95% CI] | dMAE vs base h (SE) | folds better | pooled-bootstrap dMAE [95% CI] | verdict by the fixed rule |
|---|---|---|---|---|---|---|---|---|
| ipcw (so_all) | _al | 0.0001 (0.0032) | 4/8 | +0.0026 [-0.0029, +0.0081] | 0.2 (0.1) | 2/8 | +0.0 [-0.2, +0.3] | C no clear effect; MAE no clear effect |
| ipcw (so_all) | _w | -0.0006 (0.0027) | 4/8 | -0.0016 [-0.0054, +0.0021] | 0.3 (0.2) | 1/8 | +0.3 [+0.0, +0.6] | C no clear effect; MAE hurts |
| ipcw (so_all) | _alw | -0.0010 (0.0033) | 4/8 | +0.0010 [-0.0055, +0.0075] | 0.5 (0.2) | 2/8 | +0.3 [-0.0, +0.7] | C no clear effect; MAE no clear effect |
| ridge (so_em) | _al | -0.0021 (0.0051) | 6/8 | +0.0022 [-0.0028, +0.0071] | 0.4 (0.2) | 1/8 | +0.2 [-0.1, +0.4] | C no clear effect; MAE no clear effect |
| ridge (so_em) | _w | -0.0005 (0.0047) | 4/8 | -0.0010 [-0.0051, +0.0030] | 0.2 (0.2) | 2/8 | +0.2 [-0.0, +0.5] | C no clear effect; MAE no clear effect |
| ridge (so_em) | _alw | -0.0021 (0.0047) | 5/8 | +0.0002 [-0.0058, +0.0061] | 0.6 (0.2) | 1/8 | +0.4 [+0.1, +0.7] | C no clear effect; MAE hurts |
| xgbaft (so_em) | _al | -0.0009 (0.0013) | 1/8 | -0.0008 [-0.0033, +0.0018] | -0.0 (0.1) | 5/8 | -0.1 [-0.3, +0.1] | C no clear effect; MAE no clear effect |
| xgbaft (so_em) | _w | -0.0003 (0.0015) | 3/8 | -0.0008 [-0.0035, +0.0021] | -0.2 (0.2) | 7/8 | -0.0 [-0.5, +0.4] | C no clear effect; MAE no clear effect |
| xgbaft (so_em) | _alw | -0.0013 (0.0011) | 3/8 | -0.0005 [-0.0037, +0.0029] | -0.1 (0.2) | 6/8 | +0.0 [-0.5, +0.5] | C no clear effect; MAE no clear effect |

Fixed rule (written before the run): an effect is called 'helps' only if the mean per-fold difference is beyond 2 SE, at least 6 of 8 folds agree and the pooled bootstrap CI (strikes resampled, paired) excludes 0; 'hurts' if the CI is entirely on the wrong side; otherwise 'no clear effect'.

## 4. Pooled bootstrap over strikes against oblast_median (all scored dev strikes, 2000 resamples, seed 42)

| design | C pooled | C oblast_median | dC [95% CI] | MAE pooled h | dMAE vs oblast_median h [95% CI] |
|---|---|---|---|---|---|
| ipcw_so_all_al_a100 | 0.817 | 0.757 | +0.0600 [+0.0472, +0.0728] | 62.3 | -4.4 [-6.4, -2.5] |
| ipcw_so_all_w_a100 | 0.813 | 0.757 | +0.0559 [+0.0427, +0.0687] | 62.6 | -4.1 [-6.1, -2.2] |
| ipcw_so_all_alw_a100 | 0.815 | 0.757 | +0.0585 [+0.0453, +0.0716] | 62.6 | -4.1 [-6.1, -2.2] |
| ridge_so_em_al_a100 | 0.818 | 0.757 | +0.0614 [+0.0486, +0.0744] | 62.8 | -3.9 [-5.9, -2.1] |
| ridge_so_em_w_a100 | 0.815 | 0.757 | +0.0581 [+0.0446, +0.0711] | 62.8 | -3.9 [-5.8, -1.9] |
| ridge_so_em_alw_a100 | 0.816 | 0.757 | +0.0593 [+0.0461, +0.0725] | 63.0 | -3.7 [-5.7, -1.8] |
| xgbaft_so_em_al_d2n25 | 0.814 | 0.757 | +0.0571 [+0.0431, +0.0704] | 69.8 | +3.1 [-0.6, +6.6] |
| xgbaft_so_em_w_d2n25 | 0.814 | 0.757 | +0.0571 [+0.0432, +0.0706] | 69.9 | +3.1 [-0.5, +6.7] |
| xgbaft_so_em_alw_d2n25 | 0.814 | 0.757 | +0.0574 [+0.0437, +0.0707] | 69.9 | +3.2 [-0.5, +6.7] |
| ridge_so_alw_a100 | 0.769 | 0.757 | +0.0116 [-0.0018, +0.0242] | 68.1 | +1.4 [-0.7, +3.6] |

## 5. Verdict

- `ipcw_so_all_alw_a100` vs `ipcw_so_all_a100`: dC -0.0010 (SE 0.0033), 4/8 folds; dMAE +0.5 h (SE 0.2), 2/8 folds; by the fixed rule: C no clear effect; MAE no clear effect.
- `ridge_so_em_alw_a100` vs `ridge_so_em_a100`: dC -0.0021 (SE 0.0047), 5/8 folds; dMAE +0.6 h (SE 0.2), 1/8 folds; by the fixed rule: C no clear effect; MAE hurts.
- `xgbaft_so_em_alw_d2n25` vs `xgbaft_so_em_d2n25`: dC -0.0013 (SE 0.0011), 3/8 folds; dMAE -0.1 h (SE 0.2), 6/8 folds; by the fixed rule: C no clear effect; MAE no clear effect.
- `ridge_so_alw_a100` vs `ridge_so_a100`: dC -0.0109 (SE 0.0150), 3/8 folds; dMAE +0.2 h (SE 0.5), 2/8 folds; by the fixed rule: C no clear effect; MAE no clear effect.

Conclusion: alerts and weather (alone or together) do not improve C or MAE of any design by the fixed rule; the paired differences are within noise (or slightly negative), so they are NOT added to the model. Not a statement that alerts or weather do not matter physically: at the (strike, oblast) level, with ~2400 observed episodes, day resolution and a first-report label, they carry no usable extra signal beyond oblast, strike and Energy Map history. Alerts are almost always on (alert on the strike day in ~96% of pairs), which limits their contrast.

## 6. Caveats

- All numbers are development numbers (the whole period is dev); nothing here is a blind result. With 12 designs the table is small, but the earlier ~67-design search chose the bases on the same CV.
- Alerts are a union of oblast, raion and hromada alerts: a hromada alert in a large oblast counts as the oblast being under alert, and the share of raion/hromada records grows over time, so the alert hours are not homogeneous across the years.
- Weather is taken at one point (the oblast centre) and the strike-day value is observed by the end of the day (assumption of README 5.1.2). The day of a strike is also the day of its attack, so alerts of D partly describe the strike itself.
- The label is the first restoration report (maybe partial) in the Energy Map event records, day resolution; the cohort (blackout reported on D or D+1) is label-side.
