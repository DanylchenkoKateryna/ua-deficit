# Energy Map restoration forecast: improvement study (DEV; rolling-origin CV over ALL strikes up to 2026-06-26)

The frozen test of `docs/preregistration_energy_map.md` (strikes 2025-01-01 .. 2026-06-26) is spent, so these strikes are now development data. Label, cohort and walk-forward are exactly those of the old test (first Energy Map restoration report, 30 d window, labels as known at the issue time, warm-up 15 observed episodes). The next blind test (strikes from 2026-06-27, a fresher Energy Map file) has not been looked at; its draft protocol is `docs/preregistration_energy_map_v2_draft.md`.

Dev pairs 3097 (2402 observed) in 773 strikes; scored 767 strikes (2022-05-04 .. 2026-06-26). 8 expanding-window folds (strikes / pairs / observed): 96 / 288 / 173; 96 / 265 / 210; 96 / 472 / 421; 96 / 704 / 596; 96 / 636 / 524; 96 / 265 / 171; 96 / 252 / 182; 95 / 196 / 106.

Metrics: C = Harrell's C within strike (pairs of one strike, ties 0.5; constant forecast = 0.5), pooled inside a fold; MAE on observed episodes, pooled inside a fold. Cells: mean over folds (SE over folds). Paired columns: per-fold difference to the reference (positive dC = better, negative dMAE = better), mean (SE) and number of folds where the design is better. `rank_*` models give an order only (no hours, MAE blank).

Features (all at the issue time = end of the strike day): `em_*` = Energy Map history of the oblast (known durations of earlier episodes: last-3 / last-10 median, recency-weighted mean, count; blackout/restoration records dated STRICTLY BEFORE the strike day: days since last, blackout days in the last 7 / 30 days, consumers of the last record, oblasts with a blackout record in the last 7 days); `geo_*` = front-line flag, 4-level proximity tier, border flag; `is_af`, `sin_doy`, `cos_doy` (context); `hist_*` = previous-episode features of `region_restoration`. Sets: so = strike + oblast dummies (the old model `ridge_so_a100`), so_geo = so + geo + context, so_em = so + em, so_emh = so + hist + em, so_all = everything.

## 1. Selection (one-SE rule, simplest within one SE)

- **C**: best `ens_top3_C` C = 0.8244 (SE 0.0132); 9 designs within one SE; **selected `xgbaft_so_em_d2n25`** C = 0.8135 (SE 0.0125).
- **MAE** (separate design for hours): best `ipcw_so_all_a100` 68.1 h (SE 8.8); 45 within one SE; **selected `ridge_so_a100`** 75.2 h (SE 10.1).
- With ~67 designs on one CV the best numbers are optimistic (selection effect); blends/ensembles use members and weights picked on the same CV.

## 2. CV table (8 folds), by C: top 12 plus the selected / best / old designs; references at the bottom

| design | C_cv (SE) | dC vs oblast_median (SE), folds better | dC vs global_median (SE) | MAE_cv h (SE) | dMAE vs oblast_median h (SE), folds better | dMAE vs global_median h (SE) |
|---|---|---|---|---|---|---|
| ens_top3_C | 0.824 (0.013) | 0.103 (0.024), 8/8 | 0.324 (0.013) | 81.7 (11.1) | 7.3 (3.5), 2/8 | 2.0 (3.0) |
| blend75_xgbaft_so_all_d2n60 | 0.823 (0.011) | 0.102 (0.023), 8/8 | 0.323 (0.011) | 74.8 (9.9) | 0.5 (3.2), 4/8 | -4.8 (2.7) |
| xgbaft_so_em_d2n60 | 0.823 (0.014) | 0.101 (0.023), 8/8 | 0.323 (0.014) | 88.9 (11.7) | 14.5 (3.8), 1/8 | 9.2 (3.2) |
| xgbaft_so_all_d2n60 | 0.822 (0.013) | 0.100 (0.023), 8/8 | 0.322 (0.013) | 90.8 (12.2) | 16.4 (4.4), 1/8 | 11.1 (3.5) |
| blend75_xgbaft_so_em_d2n60 | 0.821 (0.013) | 0.099 (0.022), 8/8 | 0.321 (0.013) | 73.9 (9.7) | -0.5 (2.9), 4/8 | -5.8 (2.8) |
| blend75_xgbaft_so_all_d2n25 | 0.816 (0.013) | 0.095 (0.022), 8/8 | 0.316 (0.013) | 71.6 (9.5) | -2.7 (1.9), 4/8 | -8.0 (2.9) |
| xgbaft_so_all_d2n25 | 0.814 (0.012) | 0.093 (0.025), 7/8 | 0.314 (0.012) | 76.0 (10.0) | 1.6 (2.9), 4/8 | -3.7 (3.1) |
| xgbaft_so_em_d2n25 | 0.813 (0.013) | 0.092 (0.023), 8/8 | 0.313 (0.013) | 76.5 (9.7) | 2.1 (3.2), 3/8 | -3.2 (3.4) |
| blend50_xgbaft_so_em_d2n60 | 0.813 (0.013) | 0.092 (0.021), 8/8 | 0.313 (0.013) | 70.8 (9.7) | -3.5 (1.8), 7/8 | -8.8 (2.5) |
| blend50_xgbaft_so_all_d2n60 | 0.811 (0.012) | 0.090 (0.021), 8/8 | 0.311 (0.012) | 71.2 (9.8) | -3.1 (1.9), 6/8 | -8.4 (2.4) |
| aft_so_all_a100 | 0.810 (0.012) | 0.088 (0.028), 7/8 | 0.310 (0.012) | 85.0 (10.8) | 10.6 (4.5), 2/8 | 5.3 (3.7) |
| ridge_so_em_a100 | 0.808 (0.019) | 0.087 (0.022), 8/8 | 0.308 (0.019) | 68.8 (9.1) | -5.6 (1.8), 8/8 | -10.9 (2.8) |
| ridge_so_a100 | 0.741 (0.026) | 0.019 (0.009), 6/8 | 0.241 (0.026) | 75.2 (10.1) | 0.8 (2.0), 5/8 | -4.5 (1.6) |
| ipcw_so_all_a100 | 0.806 (0.015) | 0.085 (0.022), 8/8 | 0.306 (0.015) | 68.1 (8.8) | -6.2 (2.0), 8/8 | -11.5 (3.1) |
| global_median | 0.500 (0.000) | -0.221 (0.030), 0/8 | 0.000 (0.000) | 79.6 (11.5) | 5.3 (2.7), 1/8 | 0.0 (0.0) |
| oblast_median | 0.721 (0.030) | 0.000 (0.000), 0/8 | 0.221 (0.030) | 74.3 (10.5) | 0.0 (0.0), 0/8 | -5.3 (2.7) |
| oblast_last10_median | 0.675 (0.033) | -0.046 (0.010), 0/8 | 0.175 (0.033) | 76.4 (10.7) | 2.1 (0.8), 1/8 | -3.2 (3.1) |

## 3. Pooled bootstrap over strikes (paired with oblast_median; all scored dev strikes, 2000 resamples, seed 42)

| design | C pooled | C oblast_median | dC [95% CI] | dC vs global_median [95% CI] | MAE pooled h | dMAE vs oblast_median h [95% CI] |
|---|---|---|---|---|---|---|
| xgbaft_so_em_d2n25 | 0.815 | 0.757 | +0.0579 [+0.0440, +0.0711] | +0.3148 [+0.3021, +0.3266] | 69.9 | +3.2 [-0.5, +6.7] |
| ens_top3_C | 0.821 | 0.757 | +0.0638 [+0.0503, +0.0768] | +0.3208 [+0.3082, +0.3321] | 74.2 | +7.5 [+3.2, +11.7] |
| ridge_so_a100 | 0.758 | 0.757 | +0.0011 [-0.0082, +0.0105] | +0.2581 [+0.2448, +0.2713] | 68.7 | +2.0 [-0.3, +4.2] |
| ipcw_so_all_a100 | 0.814 | 0.757 | +0.0574 [+0.0446, +0.0701] | +0.3144 [+0.3008, +0.3269] | 62.3 | -4.4 [-6.4, -2.5] |
| blend75_xgbaft_so_all_d2n60 | 0.822 | 0.757 | +0.0649 [+0.0527, +0.0773] | +0.3219 [+0.3094, +0.3338] | 67.8 | +1.1 [-1.9, +4.1] |
| xgbaft_so_em_d2n60 | 0.821 | 0.757 | +0.0643 [+0.0500, +0.0778] | +0.3213 [+0.3085, +0.3327] | 80.3 | +13.6 [+8.9, +18.1] |
| xgbaft_so_all_d2n60 | 0.819 | 0.757 | +0.0622 [+0.0488, +0.0750] | +0.3191 [+0.3070, +0.3307] | 82.1 | +15.3 [+10.5, +20.0] |
| blend75_xgbaft_so_em_d2n60 | 0.823 | 0.757 | +0.0662 [+0.0534, +0.0789] | +0.3232 [+0.3104, +0.3351] | 66.9 | +0.2 [-2.6, +3.2] |
| blend75_xgbaft_so_all_d2n25 | 0.821 | 0.757 | +0.0638 [+0.0514, +0.0762] | +0.3208 [+0.3075, +0.3329] | 64.8 | -1.9 [-4.2, +0.4] |
| xgbaft_so_all_d2n25 | 0.816 | 0.757 | +0.0587 [+0.0449, +0.0720] | +0.3157 [+0.3027, +0.3275] | 69.6 | +2.8 [-0.8, +6.4] |

## 4. Period-restricted CV (4 consecutive blocks of the scored strikes of the period; the models are still the walk-forward ones)

**The period 2025-01..2026-06-26 was the frozen test of the previous protocol and is now development data; numbers on it are NOT a blind result.**

### 2025-01..2026-06-26 (the old test period, now dev)

256 scored strikes in 4 blocks of 64, 64, 64, 64 strikes.

| design | C_cv (SE) | dC vs oblast_median (SE), folds better | dC vs global_median (SE) | MAE_cv h (SE) | dMAE vs oblast_median h (SE), folds better | dMAE vs global_median h (SE) |
|---|---|---|---|---|---|---|
| xgbaft_so_em_d2n25 | 0.801 (0.030) | 0.150 (0.040), 4/4 | 0.301 (0.030) | 107.9 (1.7) | -1.5 (11.9), 2/4 | -12.4 (12.0) |
| ens_top3_C | 0.807 (0.029) | 0.155 (0.049), 4/4 | 0.307 (0.029) | 118.3 (3.6) | 8.9 (13.7), 1/4 | -2.0 (13.4) |
| ridge_so_a100 | 0.695 (0.037) | 0.044 (0.015), 4/4 | 0.195 (0.037) | 110.0 (11.1) | 0.7 (4.6), 2/4 | -10.3 (1.2) |
| ipcw_so_all_a100 | 0.799 (0.024) | 0.148 (0.041), 4/4 | 0.299 (0.024) | 97.0 (6.9) | -12.4 (4.6), 4/4 | -23.3 (5.7) |
| blend75_xgbaft_so_all_d2n60 | 0.816 (0.017) | 0.164 (0.037), 4/4 | 0.316 (0.017) | 107.4 (3.2) | -1.9 (10.3), 2/4 | -12.9 (9.4) |
| xgbaft_so_em_d2n60 | 0.804 (0.029) | 0.153 (0.050), 4/4 | 0.304 (0.029) | 129.1 (5.6) | 19.7 (15.2), 1/4 | 8.8 (14.9) |
| xgbaft_so_all_d2n60 | 0.808 (0.027) | 0.156 (0.042), 4/4 | 0.308 (0.027) | 132.2 (5.2) | 22.8 (14.8), 1/4 | 11.9 (13.9) |
| blend75_xgbaft_so_em_d2n60 | 0.810 (0.019) | 0.158 (0.042), 4/4 | 0.310 (0.019) | 105.7 (2.1) | -3.6 (10.3), 2/4 | -14.5 (9.9) |
| blend75_xgbaft_so_all_d2n25 | 0.815 (0.023) | 0.163 (0.027), 4/4 | 0.315 (0.023) | 102.5 (4.2) | -6.8 (7.1), 2/4 | -17.8 (7.9) |
| xgbaft_so_all_d2n25 | 0.805 (0.028) | 0.153 (0.034), 4/4 | 0.305 (0.028) | 107.6 (1.9) | -1.7 (12.3), 2/4 | -12.6 (12.3) |
| global_median | 0.500 (0.000) | -0.152 (0.046), 0/4 | 0.000 (0.000) | 120.3 (11.5) | 10.9 (5.7), 0/4 | 0.0 (0.0) |
| oblast_median | 0.652 (0.046) | 0.000 (0.000), 0/4 | 0.152 (0.046) | 109.4 (11.0) | 0.0 (0.0), 0/4 | -10.9 (5.7) |
| oblast_last10_median | 0.580 (0.036) | -0.072 (0.029), 0/4 | 0.080 (0.036) | 110.2 (9.0) | 0.9 (5.2), 3/4 | -10.1 (10.0) |

### 2022..2024

511 scored strikes in 4 blocks of 128, 128, 128, 127 strikes.

| design | C_cv (SE) | dC vs oblast_median (SE), folds better | dC vs global_median (SE) | MAE_cv h (SE) | dMAE vs oblast_median h (SE), folds better | dMAE vs global_median h (SE) |
|---|---|---|---|---|---|---|
| xgbaft_so_em_d2n25 | 0.819 (0.017) | 0.061 (0.030), 4/4 | 0.319 (0.017) | 57.8 (7.2) | 3.3 (2.2), 2/4 | -0.5 (3.6) |
| ens_top3_C | 0.830 (0.021) | 0.071 (0.027), 4/4 | 0.330 (0.021) | 60.1 (8.4) | 5.6 (3.2), 1/4 | 1.8 (4.1) |
| ridge_so_a100 | 0.768 (0.044) | 0.010 (0.015), 2/4 | 0.268 (0.044) | 56.8 (5.2) | 2.3 (2.1), 1/4 | -1.4 (0.6) |
| ipcw_so_all_a100 | 0.812 (0.025) | 0.054 (0.021), 4/4 | 0.312 (0.025) | 52.6 (4.4) | -1.9 (1.5), 3/4 | -5.6 (1.9) |
| blend75_xgbaft_so_all_d2n60 | 0.825 (0.022) | 0.067 (0.024), 4/4 | 0.325 (0.022) | 55.6 (6.5) | 1.1 (1.5), 2/4 | -2.7 (3.2) |
| xgbaft_so_em_d2n60 | 0.831 (0.022) | 0.072 (0.027), 4/4 | 0.331 (0.022) | 65.4 (8.0) | 10.9 (3.0), 0/4 | 7.1 (4.4) |
| xgbaft_so_all_d2n60 | 0.825 (0.020) | 0.067 (0.027), 4/4 | 0.325 (0.020) | 66.8 (8.6) | 12.3 (3.5), 0/4 | 8.6 (4.6) |
| blend75_xgbaft_so_em_d2n60 | 0.826 (0.027) | 0.068 (0.019), 4/4 | 0.326 (0.027) | 54.9 (6.2) | 0.4 (1.2), 2/4 | -3.3 (3.1) |
| blend75_xgbaft_so_all_d2n25 | 0.819 (0.024) | 0.061 (0.021), 4/4 | 0.319 (0.024) | 53.6 (5.7) | -0.9 (0.8), 3/4 | -4.6 (2.8) |
| xgbaft_so_all_d2n25 | 0.817 (0.016) | 0.059 (0.030), 4/4 | 0.317 (0.016) | 57.2 (7.6) | 2.7 (2.5), 2/4 | -1.1 (3.7) |
| global_median | 0.500 (0.000) | -0.258 (0.044), 0/4 | 0.000 (0.000) | 58.3 (5.5) | 3.8 (2.1), 0/4 | 0.0 (0.0) |
| oblast_median | 0.758 (0.044) | 0.000 (0.000), 0/4 | 0.258 (0.044) | 54.5 (5.2) | 0.0 (0.0), 0/4 | -3.8 (2.1) |
| oblast_last10_median | 0.723 (0.038) | -0.035 (0.022), 0/4 | 0.223 (0.038) | 57.0 (5.3) | 2.5 (0.5), 0/4 | -1.2 (1.6) |

## 5. What helps: best C per family and feature set (8-fold CV)

| family_set | best design | C_cv (SE) | dC vs oblast_median | MAE_cv h |
|---|---|---|---|---|
| xgbaft_so_em | xgbaft_so_em_d2n60 | 0.823 (0.014) | 0.101 | 88.9 |
| xgbaft_so_all | xgbaft_so_all_d2n60 | 0.822 (0.013) | 0.100 | 90.8 |
| aft_so_all | aft_so_all_a100 | 0.810 (0.012) | 0.088 | 85.0 |
| ridge_so_em | ridge_so_em_a100 | 0.808 (0.019) | 0.087 | 68.8 |
| aft_so_em | aft_so_em_a100 | 0.808 (0.019) | 0.087 | 82.8 |
| ipcw_so_all | ipcw_so_all_a100 | 0.806 (0.015) | 0.085 | 68.1 |
| ridge_so_all | ridge_so_all_a100 | 0.806 (0.015) | 0.085 | 68.2 |
| ridge_so_emh | ridge_so_emh_a100 | 0.805 (0.016) | 0.084 | 68.2 |
| rank_so_em | rank_so_em_d1n60 | 0.793 (0.015) | 0.072 |  |
| rank_so_all | rank_so_all_d1n60 | 0.786 (0.015) | 0.065 |  |
| aft_so | aft_so_a1 | 0.786 (0.021) | 0.064 | 97.8 |
| xgbaft_so | xgbaft_so_d2n60 | 0.778 (0.020) | 0.056 | 83.1 |
| xgbaft_so_geo | xgbaft_so_geo_d1n60 | 0.776 (0.016) | 0.054 | 87.4 |
| ipcw_so | ipcw_so_a10 | 0.750 (0.028) | 0.029 | 72.6 |
| ridge_so | ridge_so_a10 | 0.750 (0.028) | 0.029 | 72.6 |
| ridge_so_geo | ridge_so_geo_a10 | 0.742 (0.025) | 0.021 | 72.6 |

## 6. Blends with oblast_median (log space; weight on the model) and ensembles

Anchors (top 3 by C, top 3 by MAE, old model): xgbaft_so_em_d2n60, xgbaft_so_all_d2n60, xgbaft_so_all_d2n25, ipcw_so_all_a100, ridge_so_emh_a100, ridge_so_all_a100, ridge_so_a100. Ensemble members: `ens_top3_C` = xgbaft_so_em_d2n60 + xgbaft_so_all_d2n60 + xgbaft_so_all_d2n25; `ens_top3_MAE` = ipcw_so_all_a100 + ridge_so_emh_a100 + ridge_so_all_a100.

| design | C_cv (SE) | dC vs oblast_median (SE), folds better | dC vs global_median (SE) | MAE_cv h (SE) | dMAE vs oblast_median h (SE), folds better | dMAE vs global_median h (SE) |
|---|---|---|---|---|---|---|
| ens_top3_MAE | 0.805 (0.015) | 0.084 (0.021), 8/8 | 0.305 (0.015) | 68.2 (8.8) | -6.2 (2.0), 8/8 | -11.5 (3.1) |
| blend75_ridge_so_emh_a100 | 0.807 (0.016) | 0.085 (0.019), 8/8 | 0.307 (0.016) | 68.4 (9.0) | -5.9 (1.7), 8/8 | -11.2 (3.1) |
| blend75_ipcw_so_all_a100 | 0.807 (0.016) | 0.086 (0.019), 8/8 | 0.307 (0.016) | 68.4 (9.0) | -5.9 (1.7), 8/8 | -11.2 (3.1) |
| blend75_ridge_so_all_a100 | 0.807 (0.016) | 0.085 (0.019), 8/8 | 0.307 (0.016) | 68.5 (9.0) | -5.9 (1.7), 8/8 | -11.2 (3.1) |
| blend50_ridge_so_emh_a100 | 0.787 (0.019) | 0.065 (0.012), 8/8 | 0.287 (0.019) | 69.6 (9.3) | -4.7 (1.3), 8/8 | -10.0 (3.1) |
| blend50_ipcw_so_all_a100 | 0.788 (0.018) | 0.067 (0.014), 8/8 | 0.288 (0.018) | 69.7 (9.3) | -4.6 (1.3), 8/8 | -9.9 (3.1) |
| blend50_ridge_so_all_a100 | 0.788 (0.017) | 0.066 (0.014), 8/8 | 0.288 (0.017) | 69.7 (9.3) | -4.6 (1.3), 8/8 | -9.9 (3.1) |
| blend50_xgbaft_so_all_d2n25 | 0.805 (0.016) | 0.083 (0.017), 8/8 | 0.305 (0.016) | 70.6 (9.5) | -3.7 (1.5), 7/8 | -9.0 (3.0) |
| blend50_xgbaft_so_em_d2n60 | 0.813 (0.013) | 0.092 (0.021), 8/8 | 0.313 (0.013) | 70.8 (9.7) | -3.5 (1.8), 7/8 | -8.8 (2.5) |
| blend50_xgbaft_so_all_d2n60 | 0.811 (0.012) | 0.090 (0.021), 8/8 | 0.311 (0.012) | 71.2 (9.8) | -3.1 (1.9), 6/8 | -8.4 (2.4) |
| blend25_ridge_so_emh_a100 | 0.775 (0.018) | 0.054 (0.015), 8/8 | 0.275 (0.018) | 71.6 (9.8) | -2.7 (0.8), 8/8 | -8.0 (2.9) |
| blend75_xgbaft_so_all_d2n25 | 0.816 (0.013) | 0.095 (0.022), 8/8 | 0.316 (0.013) | 71.6 (9.5) | -2.7 (1.9), 4/8 | -8.0 (2.9) |

## 7. Caveats

- The label is the first restoration report (maybe partial), event records, day resolution; frontline records are dominated by shelling.
- Features from records use only records dated before the strike day; the cohort itself (blackout reported on D or D+1) is label-side, so all numbers are conditional on it.
- ~67 designs on one CV; the winner is optimistic. Pairs of one strike are dependent: bootstrap is over strikes, folds are blocks of strikes.

## 8. Which features carry the gain (ridge, alpha 100, 8-fold CV; extra analysis run after the table above)

| feature block added to `so` | C_cv (SE) | dC vs oblast_median (SE), folds better | MAE_cv h | dMAE vs oblast_median h (SE), folds better |
|---|---|---|---|---|
| none (`ridge_so_a100`, the old model) | 0.741 (0.026) | 0.019 (0.009), 6/8 | 75.2 | 0.8 (2.0), 5/8 |
| durations of earlier EM episodes (last-3/10 median, recency mean, count) | 0.730 (0.029) | 0.009 (0.025), 6/8 | 72.1 | -2.2 (1.2), 6/8 |
| days since last blackout record, blackout days in 7 / 30 days | 0.737 (0.018) | 0.015 (0.034), 5/8 | 73.5 | -0.9 (2.3), 5/8 |
| last-record consumers, oblasts with a record in 7 days, days since last restoration record | 0.796 (0.015) | 0.075 (0.023), 7/8 | 70.5 | -3.9 (2.4), 6/8 |
| all record-based features (no duration history) | 0.799 (0.018) | 0.077 (0.024), 7/8 | 70.1 | -4.2 (2.6), 6/8 |
| everything (`ridge_so_em_a100`) | 0.808 (0.019) | 0.087 (0.022), 8/8 | 68.8 | -5.6 (1.8), 8/8 |

So the gain does NOT come from the oblast's own past durations (hist-only is no better than the old model) but from the Energy Map record intensity before the strike
(how large the last reported blackout was, how many oblasts were reporting in the last week, how long ago the last restoration was reported). This is legitimate at the issue
time, but it partly measures how densely the source curates records, so it may not transfer to a fresher file or to another curation regime: the blind test on the new file is exactly the check.

By group (all scored dev pairs, pooled C within strike / MAE h on observed): front-line (4 oblasts, 680 comparable pairs): oblast_median 0.664 / 39.1, ridge_so_a100 0.668 / 40.8,
ridge_so_em_a100 0.710 / 39.4, xgbaft_so_em_d2n25 0.712 / 41.7, ipcw_so_all_a100 0.707 / 39.4. Rear (1984 comparable pairs): oblast_median 0.725 / 97.5, ridge_so_a100 0.689 / 99.6,
ridge_so_em_a100 0.814 / 88.4, xgbaft_so_em_d2n25 0.817 / 101.2, ipcw_so_all_a100 0.810 / 87.8.

## 9. Verdict (dev only; nothing here is a blind result)

- Ranking (C within strike): the old model `ridge_so_a100` is barely better than `oblast_median` over all dev strikes (0.741 vs 0.721, paired folds 6/8; pooled bootstrap +0.001 [-0.008, +0.011]); the +0.047 of the old test is
  mostly a feature of that period. With the Energy Map record features the gain is large and consistent: the one-SE pick `xgbaft_so_em_d2n25` has C 0.813 vs 0.721 (dC +0.092, SE 0.023, better in 8/8 folds; pooled
  bootstrap +0.058 [+0.044, +0.071]); the same holds in the 2025-01..2026-06-26 blocks (+0.150, 4/4) and in 2022..2024 (+0.061, 4/4).
- Hours: the xgb AFT and AFT models give a better order but WORSE hours (MAE +2 to +16 h vs `oblast_median`). Ridge/IPCW-ridge with the record features improve both: `ipcw_so_all_a100` MAE 68.1 h vs 74.3 h
  (-6.2 h, SE 2.0, 8/8 folds; pooled bootstrap -4.4 h [-6.4, -2.5]) with C 0.806 (+0.085, 8/8); `ridge_so_em_a100` -5.6 h (SE 1.8, 8/8) with C 0.808. The one-SE rule on MAE is uninformative here (SE of the fold mean
  is dominated by between-fold level shifts, 45 designs are 'within one SE' and it falls back to the old model); the paired per-fold differences are the meaningful comparison, and the best MAE design is chosen by CV MAE.
  Blending with `oblast_median` (weight 0.75) does nothing for the ridge/IPCW designs (C within 0.001, MAE +0.3 h); for the d2n60 xgb AFT designs it repairs the hours at unchanged C (MAE +14.5 / +16.4 h -> +0.5 / -0.5 h vs `oblast_median`, C 0.822-0.823), but it still does not beat the ridge/IPCW MAE.
- Pairwise ranking trees (`rank:pairwise`) reach C 0.793 (so_em), below the xgb AFT / AFT designs: no gain from the ranking objective.
- Geography/context features (front-line tier, border, is_af, season) add nothing on their own (`so_geo` best C 0.776 for xgb, 0.742 for ridge): the oblast dummies already carry geography.
- Caveats: 67 designs on one CV (the winners are optimistic; the margin over `oblast_median` is large relative to that selection effect but the true size is unknown); the gain comes from record-intensity features and may depend on how the
  Energy Map file is curated; the cohort is label-side (blackout reported on D or D+1). The blind test on the fresher file decides.
