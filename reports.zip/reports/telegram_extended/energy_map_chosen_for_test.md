# Energy Map: model chosen in the development mode for the final test

This file was written before any test code was run; no test metrics existed at the time of writing. Protocol: `docs/preregistration_energy_map.md` (frozen).

Protocol rule: candidates are the regression variants of the development mode (ridge, ipcw, aft, xgbaft, ensembles; baselines are not selected); criterion is the mean within-strike C over 5 consecutive folds, cohort 'all oblasts', 30-day window; among the variants no worse than the best by more than one SE (SE over the folds of the best), the simplest is taken (`complexity_key` in `region_dev.py`).

Development mode: cohort 'all oblasts', 30-day window, K = 5 folds; 2456 pairs (1979 observed); 511 of 517 strikes scored.

- Best by mean C: `aft_strike_oblast_a1`, C = 0.7953, SE = 0.0304.
- 1-SE threshold: C >= 0.7649; variants within the threshold: 40.
- **Model chosen for the test: `ridge_strike_oblast_a100`**, development C = 0.7661 (SE over folds 0.0321).
- Test forecasts: only this model + `oblast_median` + `global_median`.

Variants within 1 SE (and baselines for reference), by decreasing C:

| design | C_cv | SE | MAE_cv h |
|---|---|---|---|
| aft_strike_oblast_a1 | 0.7953 | 0.0304 | 75.9 |
| aft_full_a1 | 0.7945 | 0.0242 | 79.2 |
| aft_full_a10 | 0.7944 | 0.0146 | 75.7 |
| aft_strike_oblast_early_a10 | 0.7941 | 0.0316 | 75.5 |
| aft_strike_oblast_a10 | 0.7936 | 0.0299 | 73.9 |
| aft_strike_oblast_early_a1 | 0.7893 | 0.0311 | 77.7 |
| xgbaft_strike_oblast_hist_d2n60 | 0.7880 | 0.0275 | 64.0 |
| ipcw_strike_oblast_a10 | 0.7855 | 0.0310 | 55.3 |
| xgbaft_strike_oblast_hist_early_d2n60 | 0.7851 | 0.0283 | 65.2 |
| aft_strike_oblast_a100 | 0.7848 | 0.0296 | 79.5 |
| ridge_strike_oblast_hist_a10 | 0.7846 | 0.0297 | 54.9 |
| ridge_strike_oblast_a10 | 0.7840 | 0.0322 | 55.3 |
| ipcw_strike_oblast_hist_a10 | 0.7831 | 0.0299 | 54.9 |
| aft_full_a100 | 0.7822 | 0.0082 | 73.1 |
| xgbaft_strike_oblast_hist_d2n25 | 0.7817 | 0.0266 | 56.0 |
| xgbaft_full_d2n60 | 0.7780 | 0.0177 | 68.3 |
| aft_strike_oblast_hist_a1 | 0.7778 | 0.0274 | 76.1 |
| xgbaft_strike_oblast_hist_early_d2n25 | 0.7775 | 0.0260 | 56.0 |
| ipcw_strike_oblast_a1 | 0.7754 | 0.0330 | 54.6 |
| aft_strike_oblast_hist_early_a10 | 0.7750 | 0.0233 | 75.9 |
| ens_best | 0.7749 | 0.0327 | 55.1 |
| ridge_strike_oblast_a1 | 0.7749 | 0.0330 | 54.6 |
| ipcw_strike_oblast_hist_early_a10 | 0.7745 | 0.0300 | 55.0 |
| aft_strike_oblast_hist_a10 | 0.7744 | 0.0240 | 74.2 |
| xgbaft_strike_oblast_hist_d1n60 | 0.7733 | 0.0243 | 66.2 |
| ridge_strike_oblast_hist_early_a10 | 0.7722 | 0.0296 | 55.0 |
| xgbaft_strike_oblast_hist_early_d1n60 | 0.7718 | 0.0271 | 65.9 |
| ridge_strike_oblast_early_a10 | 0.7714 | 0.0396 | 55.3 |
| ridge_full_a1 | 0.7712 | 0.0245 | 54.6 |
| xgbaft_full_d2n25 | 0.7710 | 0.0171 | 57.8 |
| ipcw_strike_oblast_early_a10 | 0.7709 | 0.0403 | 55.3 |
| ipcw_strike_oblast_hist_a1 | 0.7707 | 0.0367 | 55.1 |
| xgbaft_full_d1n60 | 0.7705 | 0.0143 | 66.2 |
| ridge_strike_oblast_hist_a1 | 0.7694 | 0.0363 | 55.0 |
| aft_strike_oblast_hist_early_a1 | 0.7693 | 0.0285 | 79.2 |
| ridge_full_a10 | 0.7693 | 0.0244 | 55.1 |
| ipcw_strike_oblast_early_a1 | 0.7671 | 0.0379 | 54.8 |
| ipcw_strike_oblast_a100 | 0.7671 | 0.0319 | 57.0 |
| ridge_strike_oblast_a100 | 0.7661 | 0.0321 | 57.0 |
| ridge_strike_oblast_early_a1 | 0.7656 | 0.0383 | 54.8 |
| oblast_median | 0.7575 | 0.0352 | 55.4 |
| global_median | 0.5000 | 0.0000 | 58.4 |