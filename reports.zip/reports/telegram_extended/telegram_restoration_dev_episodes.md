# National restriction-regime duration: DEV report (rolling-origin CV on strikes up to 2024-12-31, test period blind)

EPISODE LEVEL: 517 dev strikes merged into 99 chain episodes (gap <= 2 days; first strike = episode start; features of the first strike only, history over earlier episodes only; training rows are earlier episodes). 'Strikes' below = episodes. Extended strike list (99 dev strikes, 66 with an observed lifting post within 30 days). Strikes with at least 15 observed past durations are scored: 78 strikes (51 observed), 2023-01-12 .. 2024-12-30. CV: expanding window, K = 5 consecutive blocks; every strike is forecast at the end of its day from earlier strikes only, with their labels as known at that instant. MAE on observed strikes (days; mean over folds, SE over folds). LB = censoring-aware lower-bound MAE over all strikes (a censored strike counts max(0, time watched - forecast)); `const_30` shows that LB alone can be gamed. C = Harrell's C over strikes (0.5 = no ranking skill). Paired columns: per-strike |error| difference vs `median_obs` on observed strikes (negative = better), 95% CI by a moving-block bootstrap (blocks of 10 consecutive strikes, 2000 resamples, seed 42), Wilcoxon p. Strikes in a chain share one lifting post, so p-values and CIs are optimistic. Features: strike list (weapons_through for Air Force strikes, gap, strikes in 30 days, heating, temperature) and history of earlier labels as known before 00:00 UTC of the strike day; whole-day counts (n_channels, n_attack_posts) are not features. No test-period number is computed.

Folds: #0: 16 strikes / 8 observed; #1: 16 strikes / 10 observed; #2: 16 strikes / 10 observed; #3: 15 strikes / 8 observed; #4: 15 strikes / 15 observed

Best CV MAE: `median_obs` 8.91 d (SE 1.43); 1-SE threshold 10.33 d; 35 designs within it. **Selected (simplest within 1 SE): `median_obs`** (8.91 d).

| design | MAE_cv d | SE | LB_cv d | C_cv | C_pooled | diff vs median_obs d [CI95] | better strikes | p Wilcoxon | p LB |
|---|---|---|---|---|---|---|---|---|---|
| median_obs | 8.91 | 1.43 | 12.89 | 0.458 | 0.418 |  |  |  |  |
| ipcw_hist_a1 | 9.17 | 2.23 | 13.63 | 0.528 | 0.517 | 0.20 [-1.48, 0.96] | 0.45 | 0.771 | 0.097 |
| ipcw_hist_a10 | 9.20 | 2.11 | 13.78 | 0.537 | 0.522 | 0.23 [-1.30, 0.92] | 0.45 | 0.757 | 0.033 |
| ipcw_dmg_a100 | 9.23 | 1.87 | 13.90 | 0.482 | 0.438 | 0.22 [-0.84, 1.23] | 0.45 | 0.722 | 0.007 |
| ridge_hist_a1 | 9.23 | 2.25 | 13.73 | 0.517 | 0.509 | 0.25 [-1.43, 1.04] | 0.45 | 0.715 | 0.063 |
| ipcw_hist_a100 | 9.24 | 1.96 | 13.99 | 0.518 | 0.483 | 0.24 [-0.97, 1.10] | 0.41 | 0.888 | 0.012 |
| ridge_hist_a10 | 9.25 | 2.13 | 13.86 | 0.519 | 0.509 | 0.27 [-1.27, 0.97] | 0.47 | 0.708 | 0.022 |
| ridge_dmg_a100 | 9.28 | 1.89 | 13.97 | 0.481 | 0.426 | 0.26 [-0.82, 1.28] | 0.45 | 0.663 | 0.006 |
| ridge_hist_a100 | 9.29 | 1.98 | 14.06 | 0.507 | 0.460 | 0.28 [-0.96, 1.17] | 0.41 | 0.837 | 0.010 |
| ipcw_strike_hist_dmg_a100 | 9.38 | 1.97 | 13.97 | 0.511 | 0.482 | 0.37 [-0.91, 1.35] | 0.41 | 0.494 | 0.003 |
| last_episode | 10.13 | 2.09 | 13.53 | 0.491 | 0.528 | 1.25 [-0.26, 2.80] | 0.37 | 0.170 | 0.305 |
| prev_strike | 10.13 | 2.09 | 13.53 | 0.491 | 0.528 | 1.25 [-0.26, 2.80] | 0.37 | 0.170 | 0.305 |
| km_global | 11.32 | 1.23 | 11.49 | 0.484 | 0.435 | 3.10 [-0.63, 7.20] | 0.37 | 0.014 | 0.203 |
| const_30 | 18.43 | 2.33 | 12.64 | 0.500 | 0.500 | 10.81 [5.41, 16.30] | 0.24 | 0.000 | 0.582 |

Best design per feature set (CV MAE; `dmg` = damage features: object classes named in the posts of the strike day, repeats, oblasts, queues): hist: `ipcw_hist_a1` 9.17 d (SE 2.23) / C 0.528; dmg: `ipcw_dmg_a100` 9.23 d (SE 1.87) / C 0.482; strike_hist_dmg: `ipcw_strike_hist_dmg_a100` 9.38 d (SE 1.97) / C 0.511; strike_hist: `ipcw_strike_hist_a100` 9.40 d (SE 2.01) / C 0.551; strike: `ipcw_strike_a100` 9.42 d (SE 1.99) / C 0.521; strike_dmg: `ipcw_strike_dmg_a100` 9.43 d (SE 1.94) / C 0.496

Best design per family (CV MAE): `ipcw_hist_a1` 9.17 d / C 0.528; `ridge_hist_a1` 9.23 d / C 0.517; `xgbaft_strike_hist_dmg_d1n25` 9.43 d / C 0.440; `aft_hist_a100` 10.97 d / C 0.478
Highest C_cv: `ipcw_strike_a1` 0.575 (SE 0.074); `ipcw_strike_hist_a10` 0.574 (SE 0.101); `ridge_strike_hist_a10` 0.573 (SE 0.100)

MAE (days, observed strikes, all scored dev strikes pooled) by strike type:

| type | strikes | observed | median_obs |
|---|---|---|---|
| Air Force strikes | 3 | 2 | 2.11 |
| derived strikes | 75 | 49 | 8.60 |

## Verdict (dev only)

The 1-SE rule selects the baseline `median_obs`: no model is distinguishable from the best design within one SE of the CV MAE.
Median baseline: MAE 8.91 d (SE 1.43). Best model `ipcw_hist_a1`: 9.17 d (SE 2.23), per-strike difference +0.20 d, block-bootstrap CI [-1.48, +0.96], Wilcoxon p = 0.771, C 0.528 (SE 0.092).
Designs whose bootstrap CI of the difference to the median lies entirely below 0 and Wilcoxon p < 0.05: 0 of 62 (p-values not corrected for the choice among designs; strikes in a chain are dependent).
