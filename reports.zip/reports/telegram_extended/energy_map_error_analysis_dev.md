# Energy Map: error analysis and the nature of the signal (DEV; all strikes up to 2026-06-26; the blind test was not touched)

Data and method: 3078 scored pairs (767 strikes, 2383 observed, 22.6 % censored), the same walk-forward forecasts as in `energy_map_improve_dev.md` (the recomputed
`ridge_so_em_a100`, `ipcw_so_all_a100`, `oblast_median` match `energy_map_improve_dev_predictions.csv` to 0.0 h). C = Harrell's C within a strike,
**pooled** in this report (the improve report averages over 8 folds, hence 0.757/0.816 here against 0.721/0.808 there). MAE is on observed pairs. CI = bootstrap over strikes (1000).
Scripts (scratchpad only): `ea3..ea8.py`, `ea_common.py`. No changes to code, tests or config; `data/raw/energy_map/new/` was not opened.

## Main findings

1. Almost all of the C gain comes from **one** feature: `em_days_since_restored` (days since the previous restoration record in the oblast). Added to `so`, it gives C 0.806 against 0.808 for the full `so_em`.
2. This is mostly **reporting cadence**, not the physics of restoration: the same features (a) predict "placebo labels" (time to the next record of any type / not about restoration) just as well (even better), (b) give the same gain on days **without strikes**,
   (c) the largest errors are "restorations" after 25-30 days that are records about other events (weather, gas, another shelling).
3. The MAE error is concentrated in the "long tail": 15 % of observed pairs (record lag > 7 days) give 55 % of the total absolute error; 5.5 % (lag > 14 days) give 32 %. Rounding to a day accounts for only ~6 h of the 62 h MAE.

## 1. Which EM_F features carry the signal

Features that are **constant within a strike** (`log_through, gap_prev, n_strikes_30, heating, temp_24h, is_af, sin/cos_doy, em_nat_7d`) have a within-strike C of exactly 0.5, so by definition they do not affect C (they can shift the level of the hours).
Therefore, the C gain can come only from features that differ between oblasts of the same strike (dummies + `em_*` except `em_nat_7d`).

Table: standardised coefficients of `ridge_so_em_a100` (refitted on all dev data, target log-hours, SE = bootstrap over strikes, 300), single-feature C, add-one / drop-one in walk-forward CV (8 folds, ridge alpha 100) and permutation importance (8 permutations, loss on CV forecasts).

| feature | coef. (SE), x per +1 SD | C-within alone (pooled; fold mean) | C_cv `so`+feature (dC vs `so`) | C_cv without it (`so_em` minus feature) | permutation: loss of C / MAE |
|---|---|---|---|---|---|
| em_days_since_restored | **+0.256 (0.023)**, x1.29 (SD = 14 days) | **0.771** (0.787) | **0.806 (+0.065)**, 8/8 | **0.740** | **-0.164 / +10.8 h** |
| em_prev_ewm | +0.233 (0.031), x1.26 (SD = 0.52 log-h) | 0.767 (0.724) | 0.748 (+0.007) | 0.806 | -0.033 / +3.6 h |
| em_prev_med10 | -0.035 (0.027) | 0.747 (0.706) | 0.735 | 0.807 | ~0 |
| em_prev_med3 | -0.004 (0.022) | 0.657 | 0.726 | 0.807 | ~0 |
| em_n_obs | -0.007 (0.018) | 0.765 (oriented; more = shorter) | 0.713 | 0.804 | -0.036 / +1.9 h (proxy of time) |
| em_bl_7d | -0.082 (0.026), x0.92 | 0.531 (oriented) | 0.753 (+0.012) | 0.812 | -0.003 |
| em_days_since_blackout | -0.043 (0.020) | 0.565 | 0.773 (+0.032) | 0.810 | 0 |
| em_last_log_cons | -0.027 (0.014) | 0.685 (oriented; a larger last blackout = shorter) | 0.726 | 0.811 | -0.002 |
| em_bl_30d | -0.013 (0.025) | 0.513 | 0.719 | 0.808 | -0.002 |
| em_nat_7d | +0.005 (0.017) | 0.500 (constant within a strike) | 0.747 | 0.808 | 0.004 |

Base C_cv: `so` 0.741, `so_em` 0.808, `oblast_median` 0.721. Groups: all duration features together (`em_prev_*`, `em_n_obs`) give 0.730 without the rest; all record features without duration give 0.799; without `em_days_since_restored` the model falls back to the level of the old one (0.740).
MAE: add-one `days_since_restored` gives -3.8 h relative to `oblast_median` (the full `so_em` -5.6 h); the rest of the MAE gain comes from `em_prev_ewm` (-2.4 h on `so`) and small contributions.
Oblast coefficients (dummies, not standardised): Sumy +0.225 (x1.25), Chernihiv +0.119, Odesa +0.097; Donetsk -0.261 (x0.77), Dnipropetrovsk -0.096, Kharkiv -0.087.

Physical interpretation:
- `em_days_since_restored` (capped at 60 days): a long pause without restoration records = the oblast is in a sparse reporting regime. The next "restoration record" then comes late or by chance:

| days_since_restored | pairs | censored % | median observed label, h | share of observed with lag <= ~2 days |
|---|---|---|---|---|
| 1 | 915 | 1.4 | 48 | 69 % |
| 2 | 342 | 2.9 | 52 | 58 % |
| 3-4 | 426 | 3.5 | 66 | 51 % |
| 5-8 | 386 | 8.3 | 74 | 49 % |
| 9-15 | 193 | 19.2 | 99 | 37 % |
| 16-59 | 302 | 65.9 | 150 | 18 % |
| 60 (no record in 60 days; 16.7 % of pairs) | 514 | **75.7** | **388** | 8 % |

  Within the group: C 0.64 (front) and 0.80 (rear); Spearman within an oblast 0.17 (front 0.09, rear 0.24), so part of the effect is the change of the reporting regime over time, not only the difference between oblasts.
- `em_prev_ewm`: inertia of the oblast's label level (regime); it adds almost nothing to C beyond the dummies but improves the hours.
- `em_bl_7d` (negative): many blackout records in a week = a "daily" regime (front, Sumy), where restoration is reported quickly.
- `em_last_log_cons`: large recent blackouts are reported as restored faster (size of the current event, label side: C 0.70 oriented, but it adds nothing in CV: `so`+size 0.730 against `so` 0.741).
- Strike size / weather / season: no C effect (constant within a strike); `n_strikes_30` affects only the level (+0.048).

## 2. Physics or a reporting artefact?

All models: ridge alpha 100 on log(h), the same folds and the same pairs; `so` = strike+oblast (old model), `so_rec` = `so` + 6 record features (`em_days_since_*`, `bl_7d/30d`, `last_log_cons`, `nat_7d`),
`so_cad` = `so` + purely "cadence" features (number of days with a record of any type in 7/30 days, median gap over 60 days, days since the last record of any type; `ea6.py`). Labels: `rest` is the real one;
`any` is the time from b0 to the next record of **any** type in the oblast (partly overlaps mechanically with `rest`); `nonrest` is the next record **without** restoration figures (does not overlap with the real label); `blkonly` is the next blackout-only record.

| label | observed | C `oblast_median` | C `so` | C `so_rec` (gain vs `so`) | C `so_cad` (gain) | C `so_em` (gain) | dMAE `so_rec` vs `so`, h |
|---|---|---|---|---|---|---|---|
| rest (real) | 0.774 | 0.721 | 0.741 | 0.799 (+0.058) | 0.735 (-0.006) | 0.808 (+0.067) | -5.1 |
| any (any record) | 0.942 | 0.640 | 0.645 | 0.786 (+0.141) | 0.805 (+0.160) | 0.775 (+0.130) | -6.5 |
| nonrest (record not about restoration) | 0.845 | 0.682 | 0.639 | 0.718 (+0.079) | 0.733 (+0.094) | 0.693 (+0.054) | **-13.2** |
| blkonly | 0.838 | 0.680 | 0.635 | 0.717 (+0.082) | 0.731 (+0.096) | 0.693 (+0.058) | **-13.3** |

Conclusions: the record features predict the time to **irrelevant** records no worse (by C gain) and much better in hours than the real label. Pure cadence features (`so_cad`) do not predict the real label
but do predict the placebo; so the real signal is the "history of restoration records" (`days_since_restored`), i.e. the **renewal behaviour of reporting** (a renewal process: a past pause predicts a future pause).
The model trained on the real label and evaluated on the placebo: pooled C `any` 0.670 (`oblast_median` 0.532), `nonrest` 0.430 (0.354); it ranks the time to unrelated records much better than the median.

Days without strikes (338 days without a strike in D-1..D+1, 1395 pairs with a blackout on D or D+1; label = first restoration record; 8 folds; features are only dummies + record):

| set | model | C `oblast_median` | C `od` (oblasts only) | C `od+rec` | gain of rec over `od` | C `od+cad` |
|---|---|---|---|---|---|---|
| real strikes | rest | 0.721 | 0.726 | 0.793 | **+0.067** | 0.731 |
| days without strikes | rest | 0.595 | 0.765 | 0.828 | **+0.063** (8/8 folds) | 0.746 |
| real strikes | nonrest | 0.682 | 0.638 | 0.714 | +0.076 | 0.725 |
| days without strikes | nonrest | 0.736 | 0.759 | 0.821 | +0.062 | 0.786 |

The gain is identical on days without strikes: the signal is **not specific to a strike**. Mediation (within a strike, observed, in-sample R2 of log-hours): oblasts 0.323; +REC 0.355; +ex-post log(time to the next non-restoration record) 0.337;
REC + this time 0.379 (the contribution of REC does not decrease: 0.032 -> 0.042; correlation of the REC score with this time 0.06). So the signal is **not** explained by the time to "any other record"; it lies in the history of restoration records specifically.

More on the label artefact (`ea7.py`): 66.8 % of observed pairs share the same restoration record (oblast, date) with another strike (rear 76.6 %); in 84 % of pairs there was at least one more listed strike between the strike and the record
(lag > 7 days: 97-99 %). The label is "the first restoration record after a blackout", not "restoration after this particular strike".

Conclusion Q2: the C gain is mostly the cadence / regime of restoration reporting (plus the stable level of the oblast). A physical component is not excluded (the direction of `bl_7d` / size of the last blackout agrees with faster restoration in active oblasts),
but it cannot be separated from cadence in these data. For the blind test this means a risk: the effect depends on how the fresh file is curated.

## 3. Error analysis

Notation: om = `oblast_median`, rm = `ridge_so_em_a100`, ip = `ipcw_so_all_a100`. MAE in h (observed). C for groups of oblasts uses only pairs within the group; for the other slices with a pair-level attribute
(oblast, size) it is an "anchored" C (a in the group, b any oblast of the strike). dMAE/dC = model rm minus om, 95 % CI bootstrap over strikes.

Overall: MAE om 66.7 / rm 62.6 / ip 62.3; C 0.757 / 0.816 / 0.814; dMAE(rm) -4.1 [-5.9, -2.3]; dC(rm) +0.059 [+0.046, +0.073]; censored 22.6 %.

| slice | pairs / observed | censored % | MAE om / rm / ip | C om / rm / ip | dMAE (rm) | dC (rm) |
|---|---|---|---|---|---|---|
| front (Donetsk, Luhansk, Zaporizhzhia, Kherson) | 1277 / 1254 | 1.8 | 39.1 / 39.4 / 39.4 | 0.664 / 0.710 / 0.707 | **+0.3 [-0.4, +1.0]** | +0.046 [+0.009, +0.088] |
| large cities* | 779 / 704 | 9.6 | 66.6 / 59.5 / 59.1 | 0.564 / 0.691 / 0.704 | -7.0 [-11.5, -2.7] | +0.127 [+0.078, +0.182] |
| rest of the rear | 1022 / 425 | **58.4** | 148.6 / 136.4 / 135.4 | 0.670 / 0.762 / 0.753 | -12.3 [-21.3, -3.9] | +0.093 [+0.033, +0.154] |
| 2022 | 211 / 129 | 38.9 | 21.9 / 21.2 / 21.5 | 0.833 / 0.850 / 0.835 | -0.7 [-1.9, +0.4] | +0.017 [-0.030, +0.057] |
| 2023 | 840 / 696 | 17.1 | 71.2 / 66.1 / 66.0 | 0.700 / 0.749 / 0.751 | -5.1 [-8.7, -1.8] | +0.049 [+0.016, +0.087] |
| 2024 | 1386 / 1135 | 18.1 | 53.4 / 51.8 / 52.1 | 0.790 / 0.842 / 0.839 | -1.6 [-4.0, +0.5] | +0.053 [+0.040, +0.067] |
| 2025 | 369 / 259 | 29.8 | 116.2 / 105.3 / 102.0 | 0.646 / 0.791 / 0.805 | -10.9 [-21.3, +0.4] | +0.146 [+0.096, +0.192] |
| 2026 | 272 / 164 | 39.7 | 97.2 / 88.0 / 87.4 | 0.662 / 0.793 / 0.784 | -9.2 [-17.1, -1.0] | +0.131 [+0.031, +0.216] |
| heating season (Oct-Mar) | 1780 / 1319 | 25.9 | 70.6 / 66.1 / 65.0 | 0.765 / 0.813 / 0.810 | -4.5 [-7.4, -1.7] | +0.048 [+0.030, +0.067] |
| non-heating (Apr-Sep) | 1298 / 1064 | 18.0 | 62.0 / 58.4 / 58.9 | 0.748 / 0.819 / 0.819 | -3.6 [-5.8, -1.2] | +0.072 [+0.053, +0.091] |
| Air Force (72 strikes) | 272 / 181 | 33.5 | 96.1 / 90.8 / 88.4 | 0.719 / 0.836 / 0.836 | -5.3 [-14.5, +3.2] | +0.117 [+0.074, +0.157] |
| derived (695 strikes) | 2806 / 2202 | 21.5 | 64.3 / 60.3 / 60.2 | 0.760 / 0.814 / 0.812 | -4.0 [-5.9, -2.1] | +0.054 [+0.040, +0.068] |
| blackout <= 1 thousand (size of the current event, label side) | 335 / 207 | 38.2 | 99.8 / 91.8 / 91.6 | 0.613 / 0.672 / 0.675 | -8.0 [-18.5, +1.9] | +0.059 [-0.005, +0.120] |
| 1-10 thousand | 1120 / 824 | 26.4 | 81.7 / 76.8 / 76.5 | 0.672 / 0.765 / 0.768 | -4.8 [-9.3, -0.6] | +0.093 [+0.073, +0.114] |
| 10-100 thousand | 1130 / 1060 | 6.2 | 47.2 / 45.2 / 44.9 | 0.818 / 0.868 / 0.863 | -2.0 [-3.3, -0.6] | +0.050 [+0.035, +0.064] |
| > 100 thousand | 172 / 115 | 33.1 | 63.2 / 56.6 / 58.5 | 0.793 / 0.826 / 0.818 | -6.7 [-16.0, +2.6] | +0.033 [-0.016, +0.082] |
| size unknown | 321 / 177 | 44.9 | 77.6 / 70.3 / 69.0 | 0.900 / 0.848 / 0.844 | -7.3 [-12.5, -2.1] | **-0.053 [-0.103, -0.002]** |

*large cities = oblasts Kyiv_city, Kharkiv, Dnipropetrovsk, Odesa, Lviv. 2025-2026 is the former test period: all numbers are dev.

Where the model is **worse** than `oblast_median`: (i) the front overall by MAE (+0.3 h, CI contains 0), front 2024 +1.5 h [+0.7, +2.3]; (ii) by C: Donetsk -0.024 [-0.040, -0.010] (MAE +1.2 h), Mykolaiv -0.096 [-0.191, 0.000] (although MAE -38 h; 73 observed),
Kharkiv -0.005 [-0.031, +0.021]; (iii) pairs with unknown blackout size (C -0.053); (iv) 2022, no gain; (v) small cells (rear 2022: MAE +5.1 h; rear 2023: C 0.708 -> 0.323, but only 65 comparable pairs).
The gain is concentrated in 2025-2026 (om is weak there: C 0.65-0.66), in large cities and in the rear, where the label is sparsest and longest.

Individual oblasts (observed >= 25): Zaporizhzhia MAE 43.5 -> 43.7, C 0.809 -> 0.870; Dnipropetrovsk 41.5 -> 38.7, C 0.598 -> 0.764; Kherson 49.8 -> 49.2, C 0.733 -> 0.831; Sumy 106 -> 104, C 0.468 -> 0.568;
Odesa 169 -> 147, C 0.317 -> 0.568; Chernihiv 207 -> 204 (74 % censored, C 0.077 -> 0.218). Share of the total absolute error of ip: Zaporizhzhia 16.9 % (24.2 % of pairs), Chernihiv 13.9 % (4.3 % of pairs), Sumy 13.8 % (8.3 %), Odesa 9.5 % (4.1 %).

Structure of the ip error (observed): the top 5 % of pairs (119) = 31.5 % of the total error; the 15 worst = 5.8 %; **none** of them is overestimated, all are underestimated. Systematic bias: for true values <= 48 h the forecast is too high by +26 h on average,
for 192-360 h too low by 145 h, for > 360 h by 371 h. All 695 censored pairs are underestimated (median forecast 153 h against median censoring time 736 h; not included in MAE).

| true lag (days from the strike day to the record) | observed pairs (share) | MAE ip, h | MAE om, h | share of total error |
|---|---|---|---|---|
| 1 | 807 (34 %) | 26.7 | 26.1 | 14.5 % |
| 2 | 462 (19 %) | 19.8 | 20.9 | 6.2 % |
| 3 | 249 (10 %) | 24.0 | 34.9 | 4.0 % |
| 4-7 | 511 (21 %) | 59.9 | 78.0 | 20.6 % |
| 8-14 | 224 (9 %) | 148.9 | 142.1 | 22.5 % |
| 15-24 | 83 (3.5 %) | 302.0 | 300.6 | 16.9 % |
| 25-30 | 47 (2 %) | 485.3 | 489.6 | 15.4 % |

Without lags > 14 days (5.5 % of pairs) MAE ip = 44.7 h (om 49.3 h); without lags > 7 days 33.2 h. The model beats om only at lags of 3-7 days; at lags >= 8 days it is no better than the median.

### The 15 largest ip errors (observed; forecast ip / om; all are a "restoration" record after 26-30 days)

| strike date | oblast | type | true, h | ip, h | om, h | restoration record (date) / source |
|---|---|---|---|---|---|---|
| 2023-11-25 | Sumy | derived | 721 | 75 | 98 | 2023-12-25, mev.gov.ua "as of 25 December, 72 settlements without power because of bad weather" (weather) |
| 2026-04-14 | Odesa | derived | 725 | 97 | 167 | 2026-05-14, dtek-oem.com.ua (another attack on a DTEK OEM facility) |
| 2023-11-27 | Sumy | derived | 677 | 76 | 98 | the same record of 2023-12-25 |
| 2024-12-25 | Kherson | Air Force | 702 | 103 | 52 | 2025-01-23, t.me/olexandrprokudin/5822 |
| 2024-12-26 | Kherson | derived | 675 | 87 | 52 | the same record of 2025-01-23 |
| 2023-03-31 | Mykolaiv | derived | 677 | 99 | 52 | 2023-04-28, facebook energy.mk.ua |
| 2023-07-20 | Odesa | derived | 627 | 50 | 51 | 2023-08-15, facebook dtekoem |
| 2023-11-28 | Sumy | derived | 651 | 78 | 98 | the same record of 2023-12-25 |
| 2023-11-01 | Chernihiv | derived | 722 | 157 | 387 | 2023-12-01, mev.gov.ua "as of 1 December, 492 without power because of bad weather and hostilities" |
| 2023-03-10 | Chernihiv | derived | 675 | 113 | 49 | 2023-04-07, dcz.cg.gov.ua |
| 2023-03-11 | Chernihiv | derived | 653 | 95 | 49 | the same record of 2023-04-07 |
| 2024-04-11 | Chernihiv | Air Force | 726 | 170 | 326 | 2024-05-11, mev.gov.ua "gas distribution restored in Donetsk oblast" (gas) |
| 2023-11-29 | Sumy | derived | 627 | 81 | 98 | the same record of 2023-12-25 |
| 2024-08-20 | Chernihiv | derived | 724 | 179 | 263 | 2024-09-19, t.me/energyofukraine/2907-2908 |
| 2025-10-29 | Kyiv | derived | 653 | 115 | 75 | 2025-11-25, dtek-krem "power restored over the past day" (there is also a restoration record on the blackout day) |

The `notes` field is empty for these records (only ~186 restoration notes in the whole file are non-empty), so the link is the guide. For most of them this is not restoration after the strike but an unrelated later record.
Full CSV: scratchpad `out3_worst15.csv`. For these pairs `em_days_since_restored` was 1-5 (the model assumed "active reporting") or 60 (forecast 95-180 h, but the true label is even longer).

## 4. Label quality

Label = record date + 12 h - strike time, so it is in days (24 L + 12 - strike hour; strike hour UTC ~ 8.7 +- 2.5); the "spikes at multiples of 24 h" are by construction, and the meaningful distribution is in days (3097 pairs, 2402 observed):

| lag, days from the strike day to the restoration record | front | rear | total |
|---|---|---|---|
| 1 | 43.6 % | 23.1 % | 33.9 % |
| 2 | 20.5 % | 18.1 % | 19.4 % |
| 3 | 10.3 % | 10.7 % | 10.5 % |
| 4-5 | 12.1 % | 14.9 % | 13.4 % |
| 6-7 | 7.8 % | 8.4 % | 8.1 % |
| 8-14 | 5.1 % | 14.1 % | 9.3 % |
| 15-24 | 0.6 % | 6.7 % | 3.5 % |
| 25-30 | 0.2 % | 4.0 % | 2.0 % |

- Lag <= 2 days: 53 % (front 64 %, rear 41 %); median label 53 h. From the first blackout record (b0) to restoration: 1 day 42 %, 2 days 14 %.
- A restoration record **on day b0** (ignored by the label): 46.3 % of all pairs (front 62 %, rear 35 %), 55.7 % among observed, 13.8 % among censored. For these pairs the real time may be hours, while the label is >= 1 day + the rest of the day.
- Within a strike: 4449 observed-observed pairs, of which **ties (same day) 18.8 %** (836, not included in C); among the comparable ones, 25.8 % differ by only 1 day (the most fragile to a date error).
  C of the model on pairs with a true difference >= 1 / >= 2 / >= 4 days: ip 0.815 / 0.852 / 0.894 (om 0.758 / 0.787 / 0.825).

Simulation of date noise (60 draws; noise on every observed label; "oracle" = forecast equal to the recorded label):

| noise | minimum MAE (oracle) | C oracle | C ip | C rm | C om | MAE ip |
|---|---|---|---|---|---|---|
| no noise | 0 | 1.000* | 0.814 | 0.816 | 0.757 | 62.3 |
| U(-12 h, +12 h) | 6.0 | 0.937 | 0.775 | 0.776 | 0.725 | 62.8 |
| U(-24 h, +24 h) | 12.0 | 0.919 | 0.770 | 0.771 | 0.720 | 64.2 |
| -1 / 0 / +1 day (0.25/0.5/0.25) | 11.9 | 0.941 | 0.789 | 0.790 | 0.736 | 65.0 |

*on pairs with different days; the 18.8 % tied pairs are not scored.

Irreducible share due to daily resolution: MAE >= 6 h (E|U(-12,12)|) = ~10 % of 62 h (front: 15 % of 39 h; rear: 7 % of 88 h); noise variance 48 h2 against the model MSE of 12 509 h2 (0.4 %).
Rounding does not change the order of pairs with different days, so rounding by itself costs C almost nothing; the scenario of "extra" noise of +-12 h / +-1 day gives a C ceiling of ~0.94 for any model
(i.e. up to ~1/3 of the gap 1 - C = 0.19 may be date/reporting noise). The main unpredictable component is not rounding but **attribution** (the long tail, see §3): record lags of 8+ days give 55 % of the error.

## 5. Which additional data are most likely to reduce the remaining error

From §1-4: the signal of the features is the reporting regime, and the main error is in pairs where the "restoration" is not related to the strike. Therefore, label quality has priority over new strike predictors.

1. **An event-based, hourly restoration label** (largest expected effect): the file already has a `link` for every restoration record (t.me of oblast administrations / DSOs, facebook of DSOs, mev.gov.ua). The publication time from the links (especially t.me) and DSO texts such as "N consumers without power / power fully restored"
   give hours instead of days (removes the ~6 h floor and the 18.8 % of ties) and allow records about weather / gas / another shelling to be dropped (the 15 worst pairs; lag > 7 days = 55 % of the error). An alternative to check on dev without new data: treat a lag > 7 (14) days as censoring and check MAE/C.
2. **A daily panel of "consumers without power by oblast"** (daily summaries of mev.gov.ua / DSOs; roughly the same sources as the EM records, but as a continuous series with zeros): removes the dependence of the label on cadence ("no record" now means "0 consumers") and allows restoration to be defined as a fall below a share of the peak.
   This is the only thing that directly removes the `days_since_restored` effect as an artefact.
3. **Oblast-specific strike severity**: the cohort has no information on whether the oblast was actually hit (the cohort is defined by a blackout record); the current blackout size (label side) has only C 0.70 and adds nothing in CV (0.730 against 0.741), and national strike features have C = 0.5.
   What is needed is the object and the damage by oblast (substation / generation / distribution, damaged units, air-raid alerts in the oblast) at issue time.
4. Not a priority: more weather / seasonality (the effect on C is zero or small); new years of data will help mainly the rear (58 % censored, 425 observed).

Risk for the blind test: the key feature `em_days_since_restored` depends on the curation of the file; its distribution should be compared first (share at the cap of 60: 16.7 % on dev, median 2 days front / 10 days rear), and only then should C be interpreted.
