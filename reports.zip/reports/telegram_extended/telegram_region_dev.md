# Oblast restoration forecast: DEV report (rolling-origin CV on train+validation, test period blind)

CV design: expanding window over the validation-period strikes (up to `telegram.region_validation_end`), K = 5 consecutive blocks of scored strikes; every strike is forecast from the earlier strikes only, with their labels as known at its issue time. MAE on observed episodes: mean over folds, SE over folds. LB = censoring-aware lower-bound MAE over all episodes; C = Harrell's C within strikes (0.5 = no ranking skill). Paired p: Wilcoxon on per-strike mean |error| differences vs the baseline. Selection: one-standard-error rule, complexity order baselines < strike < strike_oblast < *_hist < other sets (ridge < aft, larger alpha simpler). No test-period number is computed or shown.

## Window `next_strike`

Dev episodes 1385 (73 observed); strikes scored 88 of 331 (2024-06-20 .. 2024-12-30).

Folds: #0: 18 strikes / 124 episodes / 13 observed; #1: 18 strikes / 142 episodes / 35 observed; #2: 18 strikes / 43 episodes / 9 observed; #3: 17 strikes / 138 episodes / 0 observed; #4: 17 strikes / 113 episodes / 1 observed

Best CV MAE: `ridge_full_a10` 18.9 h (SE 3.6); 1-SE threshold 22.6 h; 15 designs within it. **Selected (simplest within 1 SE): `geo_mean`** (19.7 h).

Ensemble members: `ens_fixed` = geo_mean + ridge_strike_oblast_hist_a100 + ipcw_strike_oblast_hist_a100; `ens_best` = geo_mean + ridge_full_a10 + ipcw_strike_oblast_hist_a100

Top 10 by CV MAE, plus baselines and references:

| design | MAE_cv h | SE | LB_cv h | C_within | C_all | diff vs global_median h | better strikes | p per strike |
|---|---|---|---|---|---|---|---|---|
| ridge_full_a10 | 18.9 | 3.6 | 5.6 | 0.351 | 0.595 | -2.0 | 0.46 | 1.000 |
| ridge_full_no_oblast_a100 | 19.0 | 3.5 | 5.3 | 0.478 | 0.573 | -5.1 | 0.62 | 0.244 |
| ridge_full_a100 | 19.0 | 3.6 | 5.3 | 0.463 | 0.572 | -5.1 | 0.62 | 0.273 |
| ridge_full_no_oblast_a10 | 19.3 | 3.3 | 5.6 | 0.346 | 0.595 | -2.0 | 0.46 | 1.000 |
| ens_best | 19.7 | 3.3 | 5.6 | 0.340 | 0.454 | -3.5 | 0.62 | 0.497 |
| geo_mean | 19.7 | 4.5 | 5.8 | 0.500 | 0.385 | -4.9 | 0.69 | 0.146 |
| ens_fixed | 20.7 | 3.4 | 6.0 | 0.260 | 0.384 | -3.5 | 0.69 | 0.273 |
| ridge_strike_oblast_hist_a100 | 20.9 | 3.4 | 6.2 | 0.249 | 0.388 | -3.9 | 0.62 | 0.340 |
| ridge_full_a1 | 21.3 | 7.6 | 6.5 | 0.284 | 0.591 | 9.4 | 0.46 | 0.542 |
| ipcw_strike_oblast_hist_a100 | 21.4 | 3.1 | 5.9 | 0.277 | 0.387 | -1.7 | 0.54 | 0.893 |
| oblast_median | 24.0 | 6.6 | 7.3 | 0.392 | 0.390 | 1.2 | 0.31 | 0.426 |
| global_median | 24.4 | 6.7 | 7.4 | 0.500 | 0.434 |  |  |  |
| km_global | 444.9 | 96.3 | 66.6 | 0.500 | 0.482 | 408.8 | 0.00 | 0.000 |
| const_30d | 677.8 | 9.8 | 96.4 | 0.500 | 0.500 | 656.5 | 0.00 | 0.000 |

Best design per family (CV MAE): `ridge_full_a10` 18.9 h / C 0.351; `ens_best` 19.7 h / C 0.340; `ipcw_strike_oblast_hist_a100` 21.4 h / C 0.277; `xgbaft_strike_oblast_hist_d2n25` 24.1 h / C 0.670; `aft_strike_oblast_hist_early_a10` 158.1 h / C 0.673

### Binary task: will the restoration take longer than T hours? (primary T = 72 h)

Label as known at issue time / final dev label: long = observed duration > T or still unresolved at an elapsed time > T; short = observed <= T; censored before T = unknown, excluded. Learners: L2 logistic regression on the same feature sets, base rates (`bin_const` training base rate, `bin_oblast` oblast base rate) and the regression designs as scores (predicted hours; AUC only). AUC pooled over the scored episodes (also across strikes, so it is confounded by the drift of the base rate over time: `bin_const` is the reference, not 0.5; AUC within strikes uses pairs of the same strike only); CI = bootstrap over strikes; p AUC>0.5 one-sided bootstrap. Brier skill = 1 - Brier / Brier(bin_const), mean and SE over folds; p = Wilcoxon over per-strike Brier differences vs `bin_const`. Selection: best mean Brier skill, one-SE rule toward the simpler design (bin_const < bin_oblast < logit_strike < _oblast < _hist < other sets, larger alpha simpler).

#### Long-outage task, T = 24 h

Labelled scored episodes 112 in 23 strikes: long (> T h) 89 (79.5%), short 23; unknown (censored before T, excluded) 448.

Best mean Brier skill: `logit_strike_a1` 0.633 (SE 0.251); 1-SE threshold 0.382; 6 designs within. **Selected (simplest within 1 SE): `logit_strike_a10`** (skill 0.515).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_strike_a1 | 0.573 | [0.296, 0.919] | 0.266 | 0.500 [0.500, 0.500] | 1.000 | 0.007 +-  | 0.217 | 0.633 | 0.251 | 0.70 | 0.846 |
| logit_strike_oblast_a1 | 0.554 | [0.308, 0.926] | 0.298 | 0.800 [0.800, 0.800] | 0.002 | 0.019 +-  | 0.219 | 0.608 | 0.247 | 0.70 | 0.823 |
| logit_strike_oblast_hist_a1 | 0.452 | [0.231, 0.940] | 0.600 | 0.800 [0.800, 0.800] | 0.002 | 0.024 +-  | 0.236 | 0.529 | 0.268 | 0.70 | 0.482 |
| logit_strike_a10 | 0.511 | [0.233, 0.919] | 0.419 | 0.500 [0.500, 0.500] | 1.000 | 0.007 +-  | 0.200 | 0.515 | 0.213 | 0.65 | 0.941 |
| logit_strike_oblast_a10 | 0.516 | [0.240, 0.922] | 0.411 | 0.800 [0.800, 0.800] | 0.002 | 0.011 +-  | 0.200 | 0.505 | 0.214 | 0.65 | 0.941 |
| logit_strike_oblast_hist_a10 | 0.471 | [0.224, 0.928] | 0.536 | 0.600 [0.600, 0.600] | 0.002 | 0.027 +-  | 0.206 | 0.496 | 0.213 | 0.70 | 0.823 |
| logit_strike_oblast_hist_early_a10 | 0.431 | [0.185, 0.976] | 0.622 | 1.000 [1.000, 1.000] | 0.002 | 0.098 +-  | 0.207 | 0.370 | 0.215 | 0.65 | 0.754 |
| logit_strike_oblast_early_a10 | 0.444 | [0.215, 0.976] | 0.609 | 1.000 [1.000, 1.000] | 0.002 | 0.101 +-  | 0.198 | 0.356 | 0.303 | 0.65 | 0.520 |
| oblast_median | 0.235 | [0.049, 0.799] | 0.735 | 1.000 [1.000, 1.000] | 0.002 | 0.212 +-  |  |  |  |  |  |
| ridge_strike_oblast_a10 | 0.228 | [0.052, 0.663] | 0.825 | 1.000 [1.000, 1.000] | 0.002 | 0.196 +-  |  |  |  |  |  |
| ridge_strike_oblast_a1 | 0.219 | [0.077, 0.576] | 0.935 | 1.000 [1.000, 1.000] | 0.002 | 0.310 +-  |  |  |  |  |  |
| ridge_strike_oblast_a100 | 0.186 | [0.000, 0.756] | 0.775 | 1.000 [1.000, 1.000] | 0.002 | 0.114 +-  |  |  |  |  |  |
| ridge_full_a100 | 0.545 | [0.335, 0.841] | 0.315 | 1.000 [1.000, 1.000] | 0.002 | 0.492 +-  |  |  |  |  |  |
| ridge_full_no_oblast_a100 | 0.546 | [0.340, 0.839] | 0.309 | 1.000 [1.000, 1.000] | 0.002 | 0.489 +-  |  |  |  |  |  |
| ridge_strike_oblast_early_a100 | 0.353 | [0.146, 0.869] | 0.705 | 1.000 [1.000, 1.000] | 0.002 | 0.427 +-  |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a100 | 0.293 | [0.099, 0.831] | 0.730 | 1.000 [1.000, 1.000] | 0.002 | 0.310 +-  |  |  |  |  |  |
| bin_const | 0.111 | [0.000, 0.662] | 0.857 | 0.500 [0.500, 0.500] | 1.000 | 0.007 +-  | 0.197 | 0.000 | 0.000 |  |  |
| bin_oblast | 0.297 | [0.192, 0.493] | 0.978 | 0.800 [0.800, 0.800] | 0.002 | 0.240 +-  | 0.201 | -2.008 | 1.414 | 0.30 | 0.119 |

#### Long-outage task, T = 72 h (PRIMARY, fixed in advance)

Labelled scored episodes 66 in 15 strikes: long (> T h) 19 (28.8%), short 47; unknown (censored before T, excluded) 494.

Best mean Brier skill: `bin_oblast` 0.071 (SE 0.230); 1-SE threshold -0.159; 10 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| bin_oblast | 0.526 | [0.238, 0.763] | 0.447 | 0.333 [0.200, 1.000] | 0.723 | 0.329 +- 0.188 | 0.475 | 0.071 | 0.230 | 0.33 | 0.421 |
| bin_const | 0.558 | [0.030, 0.867] | 0.395 | 0.500 [0.500, 0.500] | 1.000 | 0.047 +- 0.009 | 0.440 | 0.000 | 0.000 |  |  |
| logit_strike_oblast_hist_a100 | 0.620 | [0.143, 0.913] | 0.279 | 0.500 [0.400, 1.000] | 0.599 | 0.325 +- 0.064 | 0.416 | -0.034 | 0.062 | 0.60 | 0.135 |
| logit_strike_oblast_hist_early_a100 | 0.606 | [0.165, 0.912] | 0.307 | 0.667 [0.600, 1.000] | 0.001 | 0.306 +- 0.051 | 0.423 | -0.036 | 0.049 | 0.67 | 0.121 |
| logit_strike_oblast_a100 | 0.596 | [0.143, 0.906] | 0.325 | 0.333 [0.200, 1.000] | 0.723 | 0.173 +- 0.030 | 0.442 | -0.086 | 0.062 | 0.67 | 0.188 |
| logit_strike_a100 | 0.600 | [0.139, 0.913] | 0.322 | 0.500 [0.500, 0.500] | 1.000 | 0.200 +- 0.046 | 0.442 | -0.088 | 0.063 | 0.67 | 0.208 |
| logit_strike_oblast_early_a100 | 0.607 | [0.158, 0.922] | 0.293 | 0.667 [0.600, 1.000] | 0.001 | 0.259 +- 0.113 | 0.449 | -0.090 | 0.053 | 0.53 | 0.389 |
| logit_full_a100 | 0.541 | [0.189, 0.911] | 0.430 | 0.167 [0.000, 1.000] | 0.727 | 0.227 +- 0.099 | 0.447 | -0.135 | 0.076 | 0.53 | 0.489 |
| xgbaft_strike_oblast_hist_d2n60 | 0.540 | [0.172, 0.773] | 0.404 | 0.833 [0.800, 1.000] | 0.001 | 0.539 +- 0.078 |  |  |  |  |  |
| aft_strike_oblast_hist_early_a100 | 0.810 | [0.307, 0.964] | 0.081 | 0.833 [0.800, 1.000] | 0.001 | 0.476 +- 0.188 |  |  |  |  |  |
| xgbaft_strike_oblast_hist_early_d2n60 | 0.338 | [0.164, 0.549] | 0.951 | 0.750 [0.700, 1.000] | 0.001 | 0.407 +- 0.036 |  |  |  |  |  |
| aft_strike_oblast_hist_early_a10 | 0.800 | [0.600, 0.961] | 0.005 | 0.667 [0.600, 1.000] | 0.001 | 0.596 +- 0.186 |  |  |  |  |  |
| aft_full_no_oblast_a1 | 0.396 | [0.165, 0.844] | 0.690 | 0.667 [0.600, 1.000] | 0.001 | 0.394 +- 0.040 |  |  |  |  |  |
| aft_strike_oblast_hist_a10 | 0.764 | [0.372, 0.945] | 0.128 | 0.667 [0.600, 1.000] | 0.001 | 0.472 +- 0.148 |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a1 | 0.598 | [0.113, 0.891] | 0.293 | 0.667 [0.000, 0.800] | 0.307 | 0.682 +- 0.135 |  |  |  |  |  |
| aft_strike_oblast_hist_a100 | 0.753 | [0.169, 0.943] | 0.161 | 0.667 [0.600, 1.000] | 0.001 | 0.340 +- 0.066 |  |  |  |  |  |

#### Long-outage task, T = 168 h

Labelled scored episodes 58 in 13 strikes: long (> T h) 0 (0.0%), short 58; unknown (censored before T, excluded) 502.

Degenerate threshold: only one class among the scored episodes, no metric is defined.

#### Ranking skill of the regression designs (bootstrap over 88 strikes)

Top 10 by C_within of 74 designs (p-values are NOT corrected for the choice among 74 designs), plus the baselines.

| design | C_within [95% CI] | p (C_within>0.5) | C_all [95% CI] | p (C_all>0.5) |
|---|---|---|---|---|
| xgbaft_strike_oblast_hist_early_d2n60 | 0.787 [0.409, 0.874] | 0.077 | 0.428 [0.329, 0.567] | 0.884 |
| ipcw_strike_oblast_early_a100 | 0.773 [0.198, 0.947] | 0.228 | 0.443 [0.282, 0.737] | 0.605 |
| ridge_full_a100 | 0.760 [0.332, 0.864] | 0.074 | 0.572 [0.389, 0.786] | 0.198 |
| ridge_full_no_oblast_a100 | 0.760 [0.332, 0.909] | 0.067 | 0.573 [0.392, 0.788] | 0.198 |
| xgbaft_strike_oblast_hist_d1n60 | 0.760 [0.438, 0.884] | 0.194 | 0.566 [0.366, 0.710] | 0.258 |
| ipcw_strike_oblast_a100 | 0.747 [0.200, 0.944] | 0.253 | 0.393 [0.180, 0.763] | 0.660 |
| ridge_strike_oblast_a100 | 0.747 [0.250, 0.925] | 0.224 | 0.402 [0.189, 0.787] | 0.650 |
| aft_strike_oblast_hist_a100 | 0.733 [0.419, 0.842] | 0.133 | 0.630 [0.425, 0.847] | 0.085 |
| xgbaft_strike_oblast_hist_early_d1n60 | 0.733 [0.438, 0.840] | 0.154 | 0.447 [0.295, 0.600] | 0.761 |
| ridge_strike_oblast_hist_a1 | 0.733 [0.272, 0.878] | 0.220 | 0.464 [0.288, 0.761] | 0.573 |
| oblast_median | 0.700 [0.309, 0.813] | 0.163 | 0.390 [0.222, 0.693] | 0.652 |
| global_median | 0.500 [0.500, 0.500] | 1.000 | 0.434 [0.195, 0.832] | 0.609 |
| geo_mean | 0.500 [0.500, 0.500] | 1.000 | 0.385 [0.161, 0.765] | 0.668 |

Early-impact features: dev CV for each cut-off K (hours after the strike time; main tables use K = 3). C within strikes, mean over folds (SE); MAE_cv h (SE).

| K h | design | C_within (SE) | MAE_cv h (SE) |
|---|---|---|---|
| 3 | xgbaft_strike_oblast_hist_early_d2n60 | 0.848 (0.067) | 242.3 (45.0) |
| 3 | aft_strike_oblast_hist_early_a100 | 0.692 (0.143) | 188.5 (52.8) |
| 3 | aft_strike_oblast_hist_early_a10 | 0.673 (0.172) | 158.1 (44.2) |
| 3 | xgbaft_strike_oblast_hist_early_d2n25 | 0.670 (0.143) | 24.1 (7.1) |
| 3 | oblast_median | 0.392 (0.201) | 24.0 (6.6) |
| 3 | geo_mean | 0.500 (0.000) | 19.7 (4.5) |
| 6 | xgbaft_strike_oblast_hist_early_d2n60 | 0.781 (0.102) | 245.2 (49.8) |
| 6 | aft_strike_oblast_hist_early_a100 | 0.713 (0.129) | 191.5 (53.7) |
| 6 | aft_strike_oblast_hist_early_a10 | 0.688 (0.156) | 161.0 (51.1) |
| 6 | xgbaft_strike_oblast_hist_early_d2n25 | 0.670 (0.143) | 24.1 (7.0) |
| 6 | oblast_median | 0.392 (0.201) | 24.0 (6.6) |
| 6 | geo_mean | 0.500 (0.000) | 19.7 (4.5) |

Warm-up sensitivity (`region_dev_min_obs` = observed past episodes needed before the first forecast; dev value 15, normal mode 30):

| min_obs | strikes scored | first scored | global_median MAE | geo_mean MAE | best design (MAE, SE) | selected (1 SE) |
|---|---|---|---|---|---|---|
| 15 | 88 of 331 | 2024-06-20 | 24.4 | 19.7 | `ridge_full_a10` (18.9, 3.6) | `geo_mean` |
| 30 | 68 of 331 | 2024-07-26 | 12.6 | 11.5 | `geo_mean` (11.5, 2.7) | `global_median` |

## Window `30d`

Dev episodes 1406 (1149 observed); strikes scored 326 of 338 (2022-10-26 .. 2024-12-30).

Folds: #0: 66 strikes / 363 episodes / 239 observed; #1: 65 strikes / 129 episodes / 113 observed; #2: 65 strikes / 102 episodes / 69 observed; #3: 65 strikes / 359 episodes / 284 observed; #4: 65 strikes / 397 episodes / 393 observed

Best CV MAE: `xgbaft_full_d1n25` 158.8 h (SE 8.3); 1-SE threshold 167.1 h; 8 designs within it. **Selected (simplest within 1 SE): `geo_mean`** (167.1 h).

Ensemble members: `ens_fixed` = geo_mean + ridge_strike_oblast_hist_a100 + ipcw_strike_oblast_hist_a100; `ens_best` = geo_mean + ridge_strike_oblast_a100 + xgbaft_full_d1n25

Top 10 by CV MAE, plus baselines and references:

| design | MAE_cv h | SE | LB_cv h | C_within | C_all | diff vs global_median h | better strikes | p per strike |
|---|---|---|---|---|---|---|---|---|
| xgbaft_full_d1n25 | 158.8 | 8.3 | 229.9 | 0.486 | 0.544 | -6.7 | 0.56 | 0.008 |
| xgbaft_strike_oblast_hist_d1n25 | 159.1 | 8.4 | 230.9 | 0.537 | 0.548 | -6.0 | 0.51 | 0.119 |
| xgbaft_strike_oblast_hist_early_d1n25 | 159.3 | 8.5 | 231.2 | 0.541 | 0.544 | -5.9 | 0.51 | 0.128 |
| xgbaft_full_d2n25 | 162.5 | 11.3 | 232.0 | 0.495 | 0.550 | -4.3 | 0.53 | 0.104 |
| xgbaft_strike_oblast_hist_d2n25 | 162.7 | 10.1 | 234.6 | 0.551 | 0.545 | -3.3 | 0.51 | 0.436 |
| ens_best | 162.9 | 10.4 | 236.3 | 0.481 | 0.501 | -4.0 | 0.51 | 0.210 |
| xgbaft_strike_oblast_hist_early_d2n25 | 163.4 | 10.2 | 235.2 | 0.540 | 0.541 | -2.6 | 0.50 | 0.569 |
| geo_mean | 167.1 | 12.6 | 237.5 | 0.500 | 0.463 | -0.8 | 0.48 | 0.901 |
| ipcw_strike_oblast_a100 | 168.0 | 10.2 | 241.0 | 0.487 | 0.494 | 0.7 | 0.49 | 0.829 |
| ipcw_strike_a100 | 168.2 | 10.4 | 240.7 | 0.500 | 0.492 | 1.3 | 0.46 | 0.980 |
| global_median | 171.6 | 5.5 | 228.6 | 0.500 | 0.511 |  |  |  |
| oblast_median | 180.0 | 4.4 | 239.5 | 0.510 | 0.505 | 6.2 | 0.41 | 0.010 |
| km_global | 243.9 | 15.9 | 255.9 | 0.500 | 0.489 | 64.5 | 0.26 | 0.000 |
| const_30d | 465.6 | 26.2 | 376.4 | 0.500 | 0.500 | 282.8 | 0.13 | 0.000 |

Best design per family (CV MAE): `xgbaft_full_d1n25` 158.8 h / C 0.486; `ens_best` 162.9 h / C 0.481; `ipcw_strike_oblast_a100` 168.0 h / C 0.487; `ridge_strike_oblast_a100` 168.5 h / C 0.493; `aft_strike_oblast_hist_a10` 237.0 h / C 0.547

### Binary task: will the restoration take longer than T hours? (primary T = 72 h)

Label as known at issue time / final dev label: long = observed duration > T or still unresolved at an elapsed time > T; short = observed <= T; censored before T = unknown, excluded. Learners: L2 logistic regression on the same feature sets, base rates (`bin_const` training base rate, `bin_oblast` oblast base rate) and the regression designs as scores (predicted hours; AUC only). AUC pooled over the scored episodes (also across strikes, so it is confounded by the drift of the base rate over time: `bin_const` is the reference, not 0.5; AUC within strikes uses pairs of the same strike only); CI = bootstrap over strikes; p AUC>0.5 one-sided bootstrap. Brier skill = 1 - Brier / Brier(bin_const), mean and SE over folds; p = Wilcoxon over per-strike Brier differences vs `bin_const`. Selection: best mean Brier skill, one-SE rule toward the simpler design (bin_const < bin_oblast < logit_strike < _oblast < _hist < other sets, larger alpha simpler).

#### Long-outage task, T = 24 h

Labelled scored episodes 1350 in 326 strikes: long (> T h) 1284 (95.1%), short 66; unknown (censored before T, excluded) 0.

Best mean Brier skill: `logit_strike_oblast_early_a100` 0.003 (SE 0.005); 1-SE threshold -0.002; 10 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_strike_oblast_early_a100 | 0.516 | [0.307, 0.741] | 0.471 | 0.414 [0.274, 0.629] | 0.823 | 0.423 +- 0.084 | 0.047 | 0.003 | 0.005 | 0.63 | 0.000 |
| logit_strike_oblast_a100 | 0.475 | [0.247, 0.729] | 0.575 | 0.664 [0.497, 0.870] | 0.032 | 0.339 +- 0.119 | 0.047 | 0.003 | 0.004 | 0.62 | 0.002 |
| logit_strike_a100 | 0.474 | [0.247, 0.729] | 0.582 | 0.500 [0.500, 0.500] | 1.000 | 0.334 +- 0.120 | 0.047 | 0.003 | 0.004 | 0.62 | 0.002 |
| logit_strike_oblast_a10 | 0.557 | [0.364, 0.767] | 0.345 | 0.655 [0.493, 0.855] | 0.041 | 0.386 +- 0.106 | 0.047 | 0.002 | 0.011 | 0.66 | 0.000 |
| logit_strike_a10 | 0.551 | [0.355, 0.753] | 0.370 | 0.500 [0.500, 0.500] | 1.000 | 0.367 +- 0.113 | 0.047 | 0.000 | 0.011 | 0.67 | 0.000 |
| bin_const | 0.430 | [0.273, 0.579] | 0.774 | 0.500 [0.500, 0.500] | 1.000 | 0.251 +- 0.084 | 0.047 | 0.000 | 0.000 |  |  |
| logit_strike_oblast_hist_early_a100 | 0.501 | [0.297, 0.723] | 0.516 | 0.414 [0.289, 0.620] | 0.835 | 0.360 +- 0.106 | 0.047 | -0.000 | 0.004 | 0.64 | 0.001 |
| logit_strike_oblast_hist_a100 | 0.473 | [0.254, 0.720] | 0.586 | 0.526 [0.370, 0.695] | 0.404 | 0.332 +- 0.114 | 0.047 | -0.001 | 0.003 | 0.63 | 0.002 |
| ipcw_strike_oblast_hist_a10 | 0.454 | [0.306, 0.614] | 0.656 | 0.733 [0.487, 0.855] | 0.033 | 0.436 +- 0.074 |  |  |  |  |  |
| ridge_strike_oblast_hist_a10 | 0.457 | [0.306, 0.619] | 0.636 | 0.733 [0.487, 0.855] | 0.033 | 0.440 +- 0.075 |  |  |  |  |  |
| ipcw_strike_oblast_hist_a1 | 0.459 | [0.312, 0.639] | 0.623 | 0.733 [0.532, 0.845] | 0.014 | 0.484 +- 0.090 |  |  |  |  |  |
| ridge_strike_oblast_hist_a1 | 0.468 | [0.318, 0.653] | 0.585 | 0.724 [0.532, 0.836] | 0.015 | 0.489 +- 0.097 |  |  |  |  |  |
| oblast_median | 0.550 | [0.467, 0.707] | 0.124 | 0.716 [0.583, 0.857] | 0.003 | 0.576 +- 0.089 |  |  |  |  |  |
| ridge_strike_oblast_a100 | 0.520 | [0.378, 0.631] | 0.377 | 0.698 [0.506, 0.921] | 0.024 | 0.491 +- 0.103 |  |  |  |  |  |
| ridge_strike_oblast_hist_a100 | 0.474 | [0.315, 0.629] | 0.581 | 0.698 [0.500, 0.831] | 0.033 | 0.412 +- 0.113 |  |  |  |  |  |
| ipcw_strike_oblast_a100 | 0.533 | [0.376, 0.638] | 0.300 | 0.698 [0.506, 0.921] | 0.024 | 0.459 +- 0.079 |  |  |  |  |  |
| bin_oblast | 0.530 | [0.430, 0.655] | 0.279 | 0.634 [0.500, 0.783] | 0.030 | 0.518 +- 0.034 | 0.049 | -0.053 | 0.032 | 0.43 | 0.000 |

#### Long-outage task, T = 72 h (PRIMARY, fixed in advance)

Labelled scored episodes 1350 in 326 strikes: long (> T h) 1105 (81.9%), short 245; unknown (censored before T, excluded) 0.

Best mean Brier skill: `logit_strike_oblast_hist_a100` 0.005 (SE 0.005); 1-SE threshold -0.001; 8 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_strike_oblast_hist_a100 | 0.588 | [0.512, 0.664] | 0.012 | 0.597 [0.506, 0.696] | 0.023 | 0.461 +- 0.018 | 0.149 | 0.005 | 0.005 | 0.43 | 0.000 |
| logit_strike_oblast_hist_early_a100 | 0.581 | [0.500, 0.660] | 0.026 | 0.584 [0.494, 0.677] | 0.037 | 0.478 +- 0.029 | 0.149 | 0.004 | 0.006 | 0.45 | 0.000 |
| logit_strike_oblast_a100 | 0.588 | [0.505, 0.672] | 0.020 | 0.552 [0.481, 0.625] | 0.067 | 0.465 +- 0.027 | 0.150 | 0.002 | 0.005 | 0.53 | 0.782 |
| logit_strike_a100 | 0.588 | [0.502, 0.671] | 0.022 | 0.500 [0.500, 0.500] | 1.000 | 0.465 +- 0.030 | 0.150 | 0.001 | 0.005 | 0.53 | 0.981 |
| logit_strike_oblast_early_a100 | 0.585 | [0.498, 0.671] | 0.029 | 0.501 [0.425, 0.587] | 0.510 | 0.489 +- 0.041 | 0.150 | 0.001 | 0.005 | 0.55 | 0.771 |
| logit_full_a100 | 0.574 | [0.479, 0.664] | 0.070 | 0.539 [0.449, 0.624] | 0.201 | 0.477 +- 0.037 | 0.149 | 0.000 | 0.010 | 0.50 | 0.184 |
| bin_const | 0.559 | [0.481, 0.633] | 0.078 | 0.500 [0.500, 0.500] | 1.000 | 0.368 +- 0.039 | 0.150 | 0.000 | 0.000 |  |  |
| logit_full_no_oblast_a100 | 0.572 | [0.477, 0.662] | 0.078 | 0.536 [0.450, 0.621] | 0.224 | 0.472 +- 0.039 | 0.150 | -0.000 | 0.010 | 0.50 | 0.145 |
| ridge_strike_oblast_hist_a1 | 0.477 | [0.411, 0.536] | 0.745 | 0.602 [0.517, 0.686] | 0.012 | 0.477 +- 0.039 |  |  |  |  |  |
| ipcw_strike_oblast_hist_a1 | 0.469 | [0.404, 0.528] | 0.834 | 0.600 [0.513, 0.688] | 0.013 | 0.473 +- 0.036 |  |  |  |  |  |
| ipcw_strike_oblast_hist_a10 | 0.464 | [0.398, 0.528] | 0.872 | 0.600 [0.513, 0.689] | 0.017 | 0.440 +- 0.018 |  |  |  |  |  |
| ridge_strike_oblast_hist_a10 | 0.469 | [0.402, 0.531] | 0.825 | 0.597 [0.509, 0.685] | 0.019 | 0.446 +- 0.021 |  |  |  |  |  |
| ridge_full_a100 | 0.463 | [0.381, 0.538] | 0.823 | 0.594 [0.513, 0.681] | 0.015 | 0.456 +- 0.046 |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a1 | 0.480 | [0.418, 0.536] | 0.738 | 0.592 [0.508, 0.675] | 0.022 | 0.485 +- 0.036 |  |  |  |  |  |
| ipcw_strike_oblast_hist_early_a1 | 0.479 | [0.416, 0.536] | 0.746 | 0.592 [0.510, 0.675] | 0.019 | 0.486 +- 0.036 |  |  |  |  |  |
| ipcw_strike_oblast_hist_early_a100 | 0.491 | [0.424, 0.555] | 0.603 | 0.584 [0.494, 0.680] | 0.036 | 0.439 +- 0.022 |  |  |  |  |  |
| bin_oblast | 0.573 | [0.526, 0.618] | 0.004 | 0.534 [0.470, 0.603] | 0.147 | 0.533 +- 0.031 | 0.154 | -0.038 | 0.031 | 0.43 | 0.003 |

#### Long-outage task, T = 168 h

Labelled scored episodes 1350 in 326 strikes: long (> T h) 869 (64.4%), short 481; unknown (censored before T, excluded) 0.

Best mean Brier skill: `logit_strike_oblast_hist_a100` 0.009 (SE 0.010); 1-SE threshold -0.001; 8 designs within. **Selected (simplest within 1 SE): `bin_const`** (skill 0.000).

| design | AUC pooled | AUC CI95 (strikes) | p AUC>0.5 | AUC within strikes [CI95] | p within>0.5 | AUC folds | Brier | Brier skill (folds) | SE | share better strikes | p Brier vs base rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| logit_strike_oblast_hist_a100 | 0.604 | [0.539, 0.664] | 0.001 | 0.596 [0.535, 0.657] | 0.002 | 0.470 +- 0.041 | 0.232 | 0.009 | 0.010 | 0.48 | 0.395 |
| logit_strike_oblast_hist_early_a100 | 0.607 | [0.545, 0.665] | 0.001 | 0.565 [0.508, 0.621] | 0.016 | 0.481 +- 0.045 | 0.233 | 0.006 | 0.015 | 0.49 | 0.741 |
| logit_strike_oblast_early_a100 | 0.609 | [0.539, 0.671] | 0.001 | 0.512 [0.451, 0.578] | 0.371 | 0.511 +- 0.035 | 0.232 | 0.005 | 0.016 | 0.55 | 0.258 |
| logit_strike_oblast_a100 | 0.607 | [0.538, 0.673] | 0.001 | 0.511 [0.456, 0.572] | 0.365 | 0.504 +- 0.036 | 0.233 | 0.004 | 0.010 | 0.53 | 0.159 |
| logit_full_a100 | 0.599 | [0.530, 0.665] | 0.002 | 0.534 [0.478, 0.585] | 0.125 | 0.510 +- 0.040 | 0.232 | 0.004 | 0.021 | 0.52 | 0.886 |
| logit_strike_a100 | 0.608 | [0.536, 0.675] | 0.001 | 0.500 [0.500, 0.500] | 1.000 | 0.495 +- 0.036 | 0.233 | 0.003 | 0.009 | 0.51 | 0.289 |
| logit_full_no_oblast_a100 | 0.599 | [0.530, 0.665] | 0.001 | 0.515 [0.460, 0.565] | 0.285 | 0.510 +- 0.040 | 0.232 | 0.003 | 0.021 | 0.52 | 0.979 |
| bin_const | 0.565 | [0.498, 0.630] | 0.031 | 0.500 [0.500, 0.500] | 1.000 | 0.362 +- 0.053 | 0.236 | 0.000 | 0.000 |  |  |
| ridge_strike_oblast_hist_a10 | 0.511 | [0.460, 0.565] | 0.333 | 0.616 [0.550, 0.687] | 0.001 | 0.483 +- 0.045 |  |  |  |  |  |
| ipcw_strike_oblast_hist_early_a1 | 0.507 | [0.457, 0.559] | 0.407 | 0.607 [0.538, 0.677] | 0.001 | 0.488 +- 0.036 |  |  |  |  |  |
| ipcw_strike_oblast_hist_a10 | 0.503 | [0.450, 0.557] | 0.456 | 0.607 [0.542, 0.676] | 0.001 | 0.476 +- 0.043 |  |  |  |  |  |
| ipcw_strike_oblast_hist_a1 | 0.503 | [0.455, 0.554] | 0.454 | 0.605 [0.540, 0.674] | 0.001 | 0.487 +- 0.046 |  |  |  |  |  |
| ridge_strike_oblast_hist_a1 | 0.515 | [0.467, 0.566] | 0.266 | 0.605 [0.542, 0.671] | 0.001 | 0.491 +- 0.047 |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a1 | 0.511 | [0.462, 0.563] | 0.333 | 0.600 [0.531, 0.669] | 0.002 | 0.492 +- 0.036 |  |  |  |  |  |
| ipcw_strike_oblast_hist_early_a10 | 0.502 | [0.452, 0.558] | 0.469 | 0.589 [0.520, 0.663] | 0.004 | 0.479 +- 0.037 |  |  |  |  |  |
| ridge_strike_oblast_hist_early_a10 | 0.509 | [0.458, 0.564] | 0.377 | 0.588 [0.518, 0.661] | 0.004 | 0.488 +- 0.039 |  |  |  |  |  |
| bin_oblast | 0.571 | [0.532, 0.614] | 0.002 | 0.546 [0.489, 0.614] | 0.062 | 0.512 +- 0.032 | 0.243 | -0.038 | 0.018 | 0.53 | 0.453 |

#### Ranking skill of the regression designs (bootstrap over 326 strikes)

Top 10 by C_within of 74 designs (p-values are NOT corrected for the choice among 74 designs), plus the baselines.

| design | C_within [95% CI] | p (C_within>0.5) | C_all [95% CI] | p (C_all>0.5) |
|---|---|---|---|---|
| aft_strike_oblast_hist_a100 | 0.560 [0.531, 0.588] | 0.001 | 0.553 [0.519, 0.589] | 0.002 |
| ipcw_strike_oblast_hist_early_a1 | 0.558 [0.523, 0.594] | 0.002 | 0.488 [0.457, 0.520] | 0.764 |
| xgbaft_strike_oblast_hist_early_d2n60 | 0.556 [0.523, 0.588] | 0.001 | 0.564 [0.524, 0.605] | 0.002 |
| xgbaft_strike_oblast_hist_d2n60 | 0.556 [0.522, 0.588] | 0.002 | 0.561 [0.522, 0.604] | 0.003 |
| ridge_strike_oblast_hist_early_a1 | 0.555 [0.520, 0.589] | 0.002 | 0.492 [0.462, 0.523] | 0.694 |
| aft_strike_oblast_hist_early_a100 | 0.549 [0.519, 0.575] | 0.003 | 0.553 [0.519, 0.587] | 0.002 |
| aft_strike_oblast_hist_early_a10 | 0.548 [0.515, 0.578] | 0.003 | 0.568 [0.534, 0.600] | 0.001 |
| xgbaft_strike_oblast_hist_early_d2n25 | 0.547 [0.517, 0.575] | 0.003 | 0.541 [0.498, 0.586] | 0.027 |
| xgbaft_strike_oblast_hist_d2n25 | 0.547 [0.516, 0.577] | 0.002 | 0.545 [0.505, 0.587] | 0.019 |
| ridge_strike_oblast_hist_early_a100 | 0.546 [0.508, 0.584] | 0.006 | 0.489 [0.457, 0.522] | 0.740 |
| global_median | 0.500 [0.500, 0.500] | 1.000 | 0.511 [0.479, 0.542] | 0.228 |
| geo_mean | 0.500 [0.500, 0.500] | 1.000 | 0.463 [0.417, 0.506] | 0.956 |
| oblast_median | 0.496 [0.463, 0.529] | 0.575 | 0.505 [0.486, 0.525] | 0.307 |

Early-impact features: dev CV for each cut-off K (hours after the strike time; main tables use K = 3). C within strikes, mean over folds (SE); MAE_cv h (SE).

| K h | design | C_within (SE) | MAE_cv h (SE) |
|---|---|---|---|
| 3 | xgbaft_strike_oblast_hist_early_d2n60 | 0.562 (0.017) | 225.0 (23.6) |
| 3 | aft_strike_oblast_hist_early_a10 | 0.554 (0.026) | 241.3 (28.7) |
| 3 | ipcw_strike_oblast_hist_early_a1 | 0.547 (0.036) | 182.0 (11.4) |
| 3 | aft_strike_oblast_hist_early_a100 | 0.546 (0.024) | 237.7 (27.9) |
| 3 | oblast_median | 0.510 (0.028) | 180.0 (4.4) |
| 3 | geo_mean | 0.500 (0.000) | 167.1 (12.6) |
| 6 | xgbaft_strike_oblast_hist_early_d2n60 | 0.551 (0.029) | 226.0 (24.2) |
| 6 | aft_strike_oblast_early_a1 | 0.543 (0.013) | 256.5 (24.8) |
| 6 | aft_strike_oblast_hist_early_a100 | 0.540 (0.037) | 236.1 (28.1) |
| 6 | aft_strike_oblast_early_a10 | 0.540 (0.023) | 251.0 (25.3) |
| 6 | oblast_median | 0.510 (0.028) | 180.0 (4.4) |
| 6 | geo_mean | 0.500 (0.000) | 167.1 (12.6) |

Warm-up sensitivity (`region_dev_min_obs` = observed past episodes needed before the first forecast; dev value 15, normal mode 30):

| min_obs | strikes scored | first scored | global_median MAE | geo_mean MAE | best design (MAE, SE) | selected (1 SE) |
|---|---|---|---|---|---|---|
| 15 | 326 of 338 | 2022-10-26 | 171.6 | 167.1 | `xgbaft_full_d1n25` (158.8, 8.3) | `geo_mean` |
| 30 | 323 of 338 | 2022-10-31 | 173.4 | 167.9 | `xgbaft_strike_oblast_hist_d1n25` (159.5, 8.7) | `geo_mean` |
