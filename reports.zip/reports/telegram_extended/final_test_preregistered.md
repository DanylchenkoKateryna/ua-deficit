# Final test under the protocol (docs/preregistration_region.md)

Model chosen in the development mode before the test: `aft_strike_oblast_hist_a100`, 30-day window.
Metric: within-strike C, 268 test strikes (from 2025-01-01), bootstrap over strikes, 2000 resamples, seed 42.

| model | within-strike C | 95 % interval | p (C > 0.5) |
|---|---|---|---|
| aft_strike_oblast_hist_a100 | 0.501 | 0.468 – 0.533 | 0.486 |
| global_median | 0.500 | – | – |
| oblast_median | 0.449 | 0.428 – 0.472 | – |

The success criterion (lower bound > 0.5) is not met. Conclusion: on the test, the ability to rank oblasts within a strike is not confirmed.
"Until the next strike" window: C 0.348, interval 0.115 – 1.000; too few observed episodes, no conclusions are drawn.
The normal `region-restoration` run also returned the models chosen on validation (`ridge_strike_oblast_a100`: C 0.44; `aft_strike_oblast_hist_early_a100`: C 0.49); they are reported as well; MAE of `ridge_strike_oblast_a100` is 194 h against 184 h for `global_median`.
The test period had already been looked at before (see the background in the protocol); this is the fifth look.
