# National restriction-regime duration: DEV report (rolling-origin CV on strikes up to 2024-12-31, test period blind)

Extended strike list (517 dev strikes, 373 with an observed lifting post within 30 days). Strikes with at least 15 observed past durations are scored: 490 strikes (352 observed), 2022-10-31 .. 2024-12-31. CV: expanding window, K = 5 consecutive blocks; every strike is forecast at the end of its day from earlier strikes only, with their labels as known at that instant. MAE on observed strikes (days; mean over folds, SE over folds). LB = censoring-aware lower-bound MAE over all strikes (a censored strike counts max(0, time watched - forecast)); `const_30` shows that LB alone can be gamed. C = Harrell's C over strikes (0.5 = no ranking skill). Paired columns: per-strike |error| difference vs `median_obs` on observed strikes (negative = better), 95% CI by a moving-block bootstrap (blocks of 10 consecutive strikes, 2000 resamples, seed 42), Wilcoxon p. Strikes in a chain share one lifting post, so p-values and CIs are optimistic. Features: strike list (weapons_through for Air Force strikes, gap, strikes in 30 days, heating, temperature) and history of earlier labels as known before 00:00 UTC of the strike day; whole-day counts (n_channels, n_attack_posts) are not features. No test-period number is computed.

Folds: #0: 98 strikes / 77 observed; #1: 98 strikes / 49 observed; #2: 98 strikes / 88 observed; #3: 98 strikes / 41 observed; #4: 98 strikes / 97 observed

Best CV MAE: `median_obs` 7.54 d (SE 0.50); 1-SE threshold 8.04 d; 1 designs within it. **Selected (simplest within 1 SE): `median_obs`** (7.54 d).

| design | MAE_cv d | SE | LB_cv d | C_cv | C_pooled | diff vs median_obs d [CI95] | better strikes | p Wilcoxon | p LB |
|---|---|---|---|---|---|---|---|---|---|
| median_obs | 7.54 | 0.50 | 11.19 | 0.438 | 0.444 |  |  |  |  |
| ipcw_hist_a100 | 8.12 | 0.64 | 12.35 | 0.415 | 0.448 | 0.49 [-0.20, 1.09] | 0.42 | 0.002 | 0.000 |
| ridge_hist_a100 | 8.15 | 0.65 | 12.40 | 0.411 | 0.444 | 0.51 [-0.19, 1.12] | 0.43 | 0.002 | 0.000 |
| ipcw_dmg_a100 | 8.20 | 0.64 | 12.32 | 0.391 | 0.429 | 0.49 [-0.10, 1.12] | 0.42 | 0.002 | 0.000 |
| ridge_dmg_a100 | 8.24 | 0.64 | 12.40 | 0.388 | 0.426 | 0.53 [-0.08, 1.17] | 0.43 | 0.001 | 0.000 |
| xgbaft_strike_hist_dmg_d1n25 | 8.24 | 0.94 | 12.17 | 0.441 | 0.474 | 0.53 [-0.22, 1.38] | 0.42 | 0.009 | 0.000 |
| xgbaft_strike_hist_d1n25 | 8.25 | 0.96 | 12.16 | 0.443 | 0.474 | 0.52 [-0.23, 1.37] | 0.43 | 0.012 | 0.000 |
| ridge_hist_a10 | 8.33 | 0.63 | 12.57 | 0.414 | 0.443 | 0.72 [0.01, 1.34] | 0.41 | 0.000 | 0.000 |
| ipcw_hist_a10 | 8.34 | 0.63 | 12.55 | 0.416 | 0.446 | 0.73 [0.03, 1.35] | 0.42 | 0.000 | 0.000 |
| ipcw_dmg_a10 | 8.34 | 0.63 | 12.36 | 0.404 | 0.442 | 0.62 [0.07, 1.36] | 0.44 | 0.001 | 0.000 |
| km_global | 9.72 | 0.57 | 11.19 | 0.434 | 0.423 | 2.47 [0.83, 4.46] | 0.38 | 0.000 | 0.755 |
| last_episode | 10.87 | 1.01 | 15.49 | 0.454 | 0.436 | 2.90 [1.36, 4.37] | 0.32 | 0.000 | 0.000 |
| prev_strike | 10.87 | 1.01 | 15.49 | 0.454 | 0.436 | 2.90 [1.36, 4.37] | 0.32 | 0.000 | 0.000 |
| const_30 | 18.50 | 1.04 | 13.67 | 0.500 | 0.500 | 11.58 [8.84, 14.60] | 0.20 | 0.000 | 0.000 |

Best design per feature set (CV MAE; `dmg` = damage features: object classes named in the posts of the strike day, repeats, oblasts, queues): hist: `ipcw_hist_a100` 8.12 d (SE 0.64) / C 0.415; dmg: `ipcw_dmg_a100` 8.20 d (SE 0.64) / C 0.391; strike_hist_dmg: `xgbaft_strike_hist_dmg_d1n25` 8.24 d (SE 0.94) / C 0.441; strike_hist: `xgbaft_strike_hist_d1n25` 8.25 d (SE 0.96) / C 0.443; strike: `ipcw_strike_a100` 8.37 d (SE 0.98) / C 0.421; strike_dmg: `ipcw_strike_dmg_a100` 8.63 d (SE 0.92) / C 0.410

Best design per family (CV MAE): `ipcw_hist_a100` 8.12 d / C 0.415; `ridge_hist_a100` 8.15 d / C 0.411; `xgbaft_strike_hist_dmg_d1n25` 8.24 d / C 0.441; `aft_hist_a100` 9.37 d / C 0.414
Highest C_cv: `xgbaft_strike_hist_d2n60` 0.496 (SE 0.013); `aft_strike_a1` 0.496 (SE 0.032); `aft_strike_a10` 0.489 (SE 0.018)

MAE (days, observed strikes, all scored dev strikes pooled) by strike type:

| type | strikes | observed | median_obs |
|---|---|---|---|
| Air Force strikes | 25 | 18 | 6.99 |
| derived strikes | 465 | 334 | 7.47 |

## Verdict (dev only)

The 1-SE rule selects the baseline `median_obs`: no model is distinguishable from the best design within one SE of the CV MAE.
Median baseline: MAE 7.54 d (SE 0.50). Best model `ipcw_hist_a100`: 8.12 d (SE 0.64), per-strike difference +0.49 d, block-bootstrap CI [-0.20, +1.09], Wilcoxon p = 0.002, C 0.415 (SE 0.036).
Designs whose bootstrap CI of the difference to the median lies entirely below 0 and Wilcoxon p < 0.05: 0 of 62 (p-values not corrected for the choice among designs; strikes in a chain are dependent).
